let modal = document.getElementById('modal');
let viewModal = document.getElementById('viewModal');
let delModal = document.getElementById('delModal');
const tbody = document.querySelector('tbody');

let pessoas = [];
let id;

let modal2 = document.getElementById('modal2');
let viewModal2 = document.getElementById('viewModal2');
let delModal2 = document.getElementById('delModal2');
const tbody2 = document.querySelector('#tbody2');

let relacionamentos = [];
let idRel;

document.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('btnPesquisar').addEventListener('click', function() {
    var nomePesquisado = document.getElementById('nomePesquisado').value.toLowerCase();
    var tabela = document.querySelector('.divTable');
    var registros = tabela.getElementsByTagName('tr');

    for (var i = 1; i < registros.length; i++) {
      var celulas = registros[i].getElementsByTagName('td');
      var nome = celulas[0].textContent.toLowerCase();
      var sobrenome = celulas[1].textContent.toLowerCase();
      var nomeCompleto = nome + ' ' + sobrenome;
      if (nomeCompleto.includes(nomePesquisado)) {
        registros[i].classList.remove('hidden');
      } else {
        registros[i].classList.add('hidden');
      }
    }
  });

  document.getElementById('btnPesquisar2').addEventListener('click', function() {
    var nomePesquisado = document.getElementById('nomePesquisado2').value.toLowerCase();
    var tabela = document.querySelector('.divTable3');
    var registros = tabela.getElementsByTagName('tr');

    for (var i = 1; i < registros.length; i++) { 
      var celulas = registros[i].getElementsByTagName('td');
      var nomePessoa1 = celulas[0].textContent.toLowerCase(); 
      var tipoRelacionamento = celulas[1].textContent.toLowerCase();
      var nomePessoa2 = celulas[2].textContent.toLowerCase(); 
      
      if (nomePessoa1.includes(nomePesquisado) || nomePessoa2.includes(nomePesquisado)) {
        registros[i].classList.remove('hidden');
      } else {
        registros[i].classList.add('hidden');
      }
    }
  });
});

const sNome = document.querySelector('#m-nome');
const sSobrenome = document.querySelector('#m-sobrenome');
const sDataNascimento = document.querySelector('#m-data-nascimento');
const sLocalNascimento = document.querySelector('#m-local-nascimento');
const sDataObito = document.querySelector('#m-data-obito');
const sDataMigracao = document.querySelector('#m-data-migracao');
const sDataRegistro = document.querySelector('#m-data-registro');
const sNumLivro = document.querySelector('#m-num-livro');
const sNumPagina = document.querySelector('#m-num-pagina');

const btnSalvar = document.querySelector('#btnSalvar');
const closeViewModal1 = document.querySelector('#closeViewModal1');
const closeDelModal1 = document.querySelector('#closeDelModal1');
const delModal1 = document.querySelector('#delModal1');

const sPessoa = document.querySelector('#m-pessoa');
const sRelacao = document.querySelector('#m-relacao');
const sPessoaRelacionada = document.querySelector('#m-pessoa-relacionada');

const closeDelModal21 = document.querySelector('#closeDelModal21');
const delModal21 = document.querySelector('#delModal21');

function showPopup(popupId) {
  var popup = document.getElementById(popupId);
  popup.style.display = 'block';
  setTimeout(function() {
      popup.style.display = 'none';
  }, 2000); 
}

var closeButtons = document.querySelectorAll('.popup .close');
closeButtons.forEach(function(btn) {
    btn.addEventListener('click', function() {
        var popup = this.closest('.popup');
        popup.style.display = 'none';
    });
});

function showLoader() {
  document.getElementById('loaderContainer').style.display = 'block';
}

function hideLoader() {
  document.getElementById('loaderContainer').style.display = 'none';
}

function formatarDataParaInputDate(data) {
  if (!data) return '';
  
  const dataObj = new Date(data);
  const dia = ('0' + dataObj.getDate()).slice(-2);
  const mes = ('0' + (dataObj.getMonth() + 1)).slice(-2);
  const ano = dataObj.getFullYear();
  
  return `${ano}-${mes}-${dia}`;
}

function openModal(edit = false, idPessoa = 0) {
  modal.classList.add('active');
  const item = pessoas.find(pessoa => pessoa.id_pessoa === idPessoa);
  if (edit) {
    sNome.value = item.nome;
    sSobrenome.value = item.sobrenome;
    sDataNascimento.value = formatarDataParaInputDate(item.dt_nasc);    
    sLocalNascimento.value = item.local_nasc;
    sDataObito.value = formatarDataParaInputDate(item.dt_obito);
    sDataMigracao.value = formatarDataParaInputDate(item.dt_migracao); 
    sDataRegistro.value = formatarDataParaInputDate(item.dt_registro); 
    sNumLivro.value = item.num_livro; 
    sNumPagina.value = item.num_pagina; 
    id = idPessoa;
  } else {
    sNome.value = '';
    sSobrenome.value = '';
    sDataNascimento.value = '';
    sLocalNascimento.value = '';
    sDataObito.value = '';
    sDataMigracao.value = '';
    sDataRegistro.value = '';
    sNumLivro.value = '';
    sNumPagina.value = '';
    id = undefined; 
  }
}

function formatarData(dataISO) {
  if (!dataISO) return '';

  const data = new Date(dataISO);
  const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
  return data.toLocaleDateString('pt-BR', options);
}

function viewItem(idPessoa) {
  const item = pessoas.find(pessoa => pessoa.id_pessoa === idPessoa);

  document.getElementById('v-nome').textContent = item.nome;
  document.getElementById('v-sobrenome').textContent = item.sobrenome;
  document.getElementById('v-data-nascimento').textContent = formatarData(item.dt_nasc);
  document.getElementById('v-local-nascimento').textContent = item.local_nasc;
  document.getElementById('v-data-obito').textContent = item.dt_obito ? formatarData(item.dt_obito) : 'Não informado'; 
  document.getElementById('v-data-migracao').textContent = item.dt_migracao ? formatarData(item.dt_migracao) : 'Não informado'; 
  document.getElementById('v-data-registro').textContent = item.dt_registro ? formatarData(item.dt_registro) : 'Não informado'; 
  document.getElementById('v-num-livro').textContent = item.num_livro ? item.num_livro : 'Não informado';
  document.getElementById('v-num-pagina').textContent = item.num_pagina ? item.num_pagina : 'Não informado';

  viewModal.classList.add('active');
}

function displayPessoas(pessoas) {
  tbody.innerHTML = '';

  const ex = document.getElementById('toggleExcluirColumns');
  if (ex.checked) {
    pessoas.forEach(pessoa => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${pessoa.nome}</td>
        <td>${pessoa.sobrenome}</td>
        <td class="acao"><button onclick="viewItem(${pessoa.id_pessoa})"><i class='bx bx-show'></i></button></td>
        <td class="acao"><button onclick="editItem(${pessoa.id_pessoa})"><i class='bx bx-edit'></i></button></td>
      `;
      tbody.appendChild(tr);
    });

  }
  else {
    pessoas.forEach(pessoa => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${pessoa.nome}</td>
        <td>${pessoa.sobrenome}</td>
        <td class="acao"><button onclick="viewItem(${pessoa.id_pessoa})"><i class='bx bx-show'></i></button></td>
        <td class="acao"><button onclick="editItem(${pessoa.id_pessoa})"><i class='bx bx-edit'></i></button></td>
        <td class="acao"><button onclick="deleteItem(${pessoa.id_pessoa})"><i class='bx bx-trash'></i></button></td>
      `;
      tbody.appendChild(tr);
    });

  }

  
}

function editItem(idPessoa) {
  openModal(true, idPessoa);
}

async function deleteItem(idPessoa) {
  delModal.classList.add('active');
  id = idPessoa;
}

async function confirmaExclusao(idPessoa) {
  try {
    await removerPessoa(idPessoa); 
    await listarPessoas(); 
  } catch (error) {
    console.error('Erro ao deletar pessoa:', error);
  } 
}

async function confirmaExclusaoRel(idRelacionamento) {
  try {
    await removeRelacionamento(idRelacionamento); 
    await listarRelacionamentos(); 
  } catch (error) {
    console.error('Erro ao deletar relacionamento:', error);
  } 
}

closeViewModal1.onclick = function(e) {
  viewModal.classList.remove('active');
};

closeDelModal1.onclick = function(e) {
  delModal.classList.remove('active');
};

delModal1.onclick = function(e) {
  delModal.classList.remove('active');
  confirmaExclusao(id);
};

btnSalvar.onclick = function(e) {
  e.preventDefault();
  try {
    var registro = {
      nome: sNome.value,
      sobrenome: sSobrenome.value,
      dt_nasc: sDataNascimento.value,
      local_nasc: sLocalNascimento.value,
      dt_obito: sDataObito.value,
      dt_migracao: sDataMigracao.value,
      dt_registro: sDataRegistro.value,
      num_livro: sNumLivro.value,
      num_pagina: sNumPagina.value
    };

    if (id !== undefined) {
      alteraPessoa(id, registro);
    } 
    else {
      inserePessoa(registro);
    }

    listarPessoas();
    modal.classList.remove('active');
    id = undefined;

    const ex = document.getElementById('toggleExcluirColumns');
    toggleExcluirColumns(ex.checked);
  } catch (error) {
    console.error('Erro ao salvar alterações:', error);
  }
};

async function inserePessoa(registro) {
  try {
    await inserirPessoa(registro); 
    showPopup('popupincps');
  } catch (error) {
    console.error('Erro ao inserir pessoa:', error);
    showPopup('popupincpf');
  }
}

async function alteraPessoa(id, registro) {
  try {
    await alterarPessoa(id, registro); 
  } catch (error) {
    console.error('Erro ao alterar pessoa:', error);
  }
}

function toggleMenu() {
  const sidebar = document.querySelector('.sidebar');
  const container = document.querySelector('.content');
  sidebar.classList.toggle('expanded');
  container.classList.toggle('expanded');
}

window.onclick = function(event) {
  if (event.target.classList.contains('modal-container')) {
    modal.classList.remove('active');
    viewModal.classList.remove('active');
    modal2.classList.remove('active');
    viewModal2.classList.remove('active');
  }
};

async function openPage(pageName) {
  const pages = document.querySelectorAll('.page');
  if (pageName == 'pessoa') {
    await listarPessoas();
  }
  if (pageName == 'relacionamento') {
    await listarRelacionamentos();
  }

  pages.forEach(page => {
    if (page.id === pageName) {
      page.classList.add('active');
    } else {
      page.classList.remove('active');
    }
  });

  updateActiveMenuItem(pageName);
  
  if (pageName !== 'home') {
    document.body.classList.remove('page-active');
  } else {                                                
    document.body.classList.add('page-active');
  }
}

document.addEventListener('DOMContentLoaded', function () {
  openPage('home');
});

function updateActiveMenuItem(activePageId) {
  const sidebarLinks = document.querySelectorAll('.sidebar a');
  sidebarLinks.forEach(link => {
    const menuName = link.getAttribute('href').substring(1); // Remove o #
    if (menuName === activePageId) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

async function openModal2(edit = false, idRelacionamento = 0) {
  modal2.classList.add('active');
  toggleCamposData();

  if (pessoas.length === 0) {
    await listarPessoas();
  }

  const selectPessoa1 = document.getElementById('m-pessoa');
  const selectPessoa2 = document.getElementById('m-pessoa-relacionada');
  selectPessoa1.innerHTML = '';
  selectPessoa2.innerHTML = '';

  pessoas.forEach(pessoa => {
    const option1 = document.createElement('option');
    option1.value = pessoa.id_pessoa;
    option1.textContent = `${pessoa.nome} ${pessoa.sobrenome}`;
    selectPessoa1.appendChild(option1);

    const option2 = document.createElement('option');
    option2.value = pessoa.id_pessoa;
    option2.textContent = `${pessoa.nome} ${pessoa.sobrenome}`;
    selectPessoa2.appendChild(option2);
  });

  if (edit) {
    const item = relacionamentos.find(relacionamento => relacionamento.id_relacionamento === idRelacionamento);
    
    selectPessoa1.value = item.id_pessoa_1;
    selectPessoa2.value = item.id_pessoa_2;

    sRelacao.value = item.tipo_relacionamento;
    idRel = idRelacionamento;
  } else {
    selectPessoa1.value = '';
    selectPessoa2.value = '';
    sRelacao.value = '';
    idRel = undefined;
  }
}

function closeModal2() {
  modal2.classList.remove('active');
}

async function salvarRelacionamento() {
  const idPessoa1 = document.getElementById('m-pessoa').value;
  const idPessoa2 = document.getElementById('m-pessoa-relacionada').value; 
  const tipoRelacionamento = document.getElementById('m-relacao').value;

  if (idPessoa1 === idPessoa2) {
    console.error('Erro ao salvar relacionamento: Não é possível relacionar uma pessoa a ela mesma.');
    return;
  }

  if (!idPessoa1 || !idPessoa2) {
    console.error('Erro ao salvar relacionamento: Preencha todos os campos obrigatórios.');
    return;
  }

  let dtInicio = null;
  let dtFim = null;

  if (tipoRelacionamento === 'Casado(a)') {
    const dtInicioInput = document.getElementById('m-data-inicio').value;
    const dtFimInput = document.getElementById('m-data-fim').value;

    if (dtInicioInput && dtFimInput) {
      dtInicio = new Date(dtInicioInput);  
      dtFim = new Date(dtFimInput);
    }
  }

  const relacionamento = {
    idPessoa1: idPessoa1,
    idPessoa2: idPessoa2,
    tipoRelacionamento: tipoRelacionamento,
    dtInicio: dtInicio,
    dtFim: dtFim
  };

  try {
    let sucesso;

    if (idRel !== undefined){
      sucesso = await alterarRelacionamento(idRel, relacionamento);
    }else{
      sucesso = await inserirRelacionamento(relacionamento);
    }
    
    if (sucesso) {
      listarRelacionamentos(); 
      closeModal2();
      const ex = document.getElementById('toggleExcluirColumns');
      toggleExcluirColumns(ex.checked);
    } else {
      console.error('Erro ao salvar relacionamento: O relacionamento já existe.');
    }
  } catch (error) {
    console.error('Erro ao salvar relacionamento:', error);
  }
}

function toggleCamposData() {
  const tipoRelacionamento = document.getElementById('m-relacao').value;
  const camposData = document.getElementById('campos-data');

  if (tipoRelacionamento === 'Casado(a)') {
    camposData.style.display = 'block'; 
  } else {
    camposData.style.display = 'none';  
  }
}

// async function viewItem2(idRelacionamento) {
//   const item = relacionamentos.find(relacionamento => relacionamento.id_relacionamento === idRelacionamento);
//   try {
//     // Busca os relacionamentos da pessoa com idPessoa
//     const relacionamentos = await buscarRelacionamento(item.id_pessoa_1);
    
//     // Limpa qualquer conteúdo anterior da árvore genealógica
//     const arvoreGenealogica = document.getElementById('arvoreGenealogica');
//     arvoreGenealogica.innerHTML = '';

//     // Cria um elemento UL para representar a árvore
//     const ul = document.createElement('ul');
//     ul.classList.add('tree');
//     arvoreGenealogica.appendChild(ul);

//     // Cria uma função recursiva para adicionar os relacionamentos à árvore
//     function adicionarRelacionamento(parentNode, relacionamento) {
//       const li = document.createElement('li');
//       li.textContent = `${relacionamento.tipo_relacionamento}: ${relacionamento.nome_pessoa_2} ${relacionamento.sobrenome_pessoa_2}`;

//       if (relacionamento.filhos && relacionamento.filhos.length > 0) {
//         const ulFilhos = document.createElement('ul');
//         li.appendChild(ulFilhos);
//         relacionamento.filhos.forEach(filho => {
//           adicionarRelacionamento(ulFilhos, filho);
//         });
//       }

//       parentNode.appendChild(li);
//     }

//     // Adiciona os relacionamentos principais à árvore
//     relacionamentos.forEach(relacionamento => {
//       adicionarRelacionamento(ul, relacionamento);
//     });

//   } catch (error) {
//     console.error('Erro ao visualizar a árvore genealógica:', error);
//     alert('Erro ao visualizar a árvore genealógica. Verifique o console para mais detalhes.');
//   }
// }

async function displayRelacionamentos(relacionamentos) {
  tbody2.innerHTML = '';

  const ex = document.getElementById('toggleExcluirColumns');
  for (const relacionamento of relacionamentos) {
    try {
      const pessoa1 = await buscarPessoa(relacionamento.id_pessoa_1);
      const pessoa2 = await buscarPessoa(relacionamento.id_pessoa_2);

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${pessoa1.nome} ${pessoa1.sobrenome}</td>
        <td>${relacionamento.tipo_relacionamento}</td>
        <td>${pessoa2.nome} ${pessoa2.sobrenome}</td>
        <td class="acao"><button onclick="viewItem2(${relacionamento.id_relacionamento})"><i class='bx bx-show'></i></button></td>
        <td class="acao"><button onclick="editItem2(${relacionamento.id_relacionamento})"><i class='bx bx-edit'></i></button></td>
        ${!ex.checked ? `<td class="acao"><button onclick="deleteItem2(${relacionamento.id_relacionamento})"><i class='bx bx-trash'></i></button></td>` : ''}
      `;
      tbody2.appendChild(tr);
    } catch (error) {
      console.error('Erro ao buscar pessoa:', error);
    }
  }
}

function editItem2(idRelacionamento) {
  openModal2(true, idRelacionamento);
}

function deleteItem2(idRelacionamento) {
  delModal2.classList.add('active');
  id = idRelacionamento;
}

closeDelModal21.onclick = function(e) {
  delModal2.classList.remove('active');
};

delModal21.onclick = function(e) {
  delModal2.classList.remove('active');
  confirmaExclusaoRel(id);
};

function toggleExcluirColumns(checked) {
  var colExcluir = document.getElementById('colex');                
  if (checked) {
    colExcluir.style.display = 'none'; // Oculta a coluna
  } 
  else {
    colExcluir.style.display = ''; // Exibe a coluna
  }

  var colExcluir2 = document.getElementById('colex2');
  if (checked) {
    colExcluir2.style.display = 'none'; // Oculta a coluna
  } 
  else {
    colExcluir2.style.display = ''; // Exibe a coluna
  }
  

  toggleExcluirColumn(tbody, 4, checked);
  toggleExcluirColumn(tbody2, 6, checked);
}

function toggleExcluirColumn(tableBody, colIndex, checked) {
  const rows = tableBody.querySelectorAll('tr');

  rows.forEach(row => {
    const cells = row.getElementsByTagName('td');
    if (cells[colIndex]) { // Verifica se a célula existe antes de tentar acessar a propriedade style
      cells[colIndex].style.display = checked ? 'none' : 'table-cell';
    }
  });
}


//FUNÇÕES DA API============================================

async function listarPessoas() {
  try {
    showLoader();
    const response = await fetch('/api/pessoa');
    const data = await response.json();
    pessoas = data;
    displayPessoas(data);
  } catch (error) {
    console.error('Erro ao listar pessoas:', error);
  } finally{
    hideLoader();
  }
}

async function buscarPessoa(id) {
  try {
    const response = await fetch(`/api/pessoa/${id}`);
    if (!response.ok) {
      throw new Error('Erro ao buscar pessoa: ' + response.statusText);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao buscar pessoa:', error);
    throw error;
  }
}

async function inserirPessoa(registro) {
  try {
    const response = await fetch('/api/pessoa', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(registro)
    });
    const data = await response.json();
  } catch (error) {
    console.error('Erro ao inserir pessoa:', error);
  }
}

async function alterarPessoa(id, registro) {
  try {
    const response = await fetch(`/api/pessoa/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(registro)
    });
    const data = await response.json();
    showPopup('popupeditps');
  } catch (error) {
    console.error('Erro ao alterar pessoa:', error);
    showPopup('popupeditpf');
  }
}

async function removerPessoa(id) {
  try {
    const response = await fetch(`/api/pessoa/${id}`, {
      method: 'DELETE'
    });
    const data = await response.json();
    showPopup('popupdelps');
  } catch (error) {
    console.error('Erro ao remover pessoa:', error);
    showPopup('popupdelpf');
  }
}

async function buscarPessoaPorNomeSobrenome(nome, sobrenome) {
  try {
    const response = await fetch(`/api/pessoa/nome/${nome}/sobrenome/${sobrenome}`);
    const data = await response.json();
  } catch (error) {
    console.error('Erro ao buscar pessoa por nome e sobrenome:', error);
  }
}

async function listarRelacionamentos() {
  try {
    showLoader();
    const response = await fetch('/api/relacionamento');
    const data = await response.json();
    relacionamentos = data;
    displayRelacionamentos(data);
  } catch (error) {
    console.error('Erro ao listar relacionamentos:', error);
  } finally{
    hideLoader();
  }
}

async function buscarRelacionamento(id) {
  try {
    const response = await fetch(`/api/relacionamento/${id}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao buscar relacionamento:', error);
  }
}

async function inserirRelacionamento(newRecord) {
  try {
    const response = await fetch('/api/relacionamento', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newRecord)
    });

    if (!response.ok) {
      console.error('Erro ao inserir relacionamento:', response.statusText);
      showPopup('popupincrf');
      return false; // Retorna false se houver erro na resposta
    }

    const data = await response.json();
    showPopup('popupincrs'); 
    return true;
  } catch (error) {
    console.error('Erro ao inserir relacionamento:', error);
    showPopup('popupincrf'); 
    return false; 
  }
}

async function alterarRelacionamento(id, updatedRecord) {
  try {
    const response = await fetch(`/api/relacionamento/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(updatedRecord)
    });

    if (!response.ok) {
      console.error('Erro ao alterar relacionamento:', response.statusText);
      showPopup('popupeditrf');
      return false;
    }

    const data = await response.json();
    showPopup('popupeditrs'); 
    return true;
  } catch (error) {
    console.error('Erro ao alterar relacionamento:', error);
    showPopup('popupeditrf'); 
  }
}

async function removeRelacionamento(id) {
  try {
    const response = await fetch(`/api/relacionamento/${id}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      },
    });
    const data = await response.json();
    showPopup('popupdelrs');
  } catch (error) {
    console.error('Erro ao remover relacionamento:', error);
    showPopup('popupdelrf');
  }
}

async function buscarRelacionamentosPorNomeSobrenome(nome, sobrenome) {
  try {
    const response = await fetch(`/api/relacionamento/nome/${nome}/sobrenome/${sobrenome}`);
    const data = await response.json();
  } catch (error) {
    console.error('Erro ao buscar relacionamentos por nome e sobrenome:', error);
  }
}