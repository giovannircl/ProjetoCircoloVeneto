# Projeto Genealogia Italiana

# Feito por: Giovanni Cacioli e Alejandro Brites

# Tecnologias utilizadas: NodeJS, Express, Javascript, HTML, CSS, PostgreSQL, GCloud
