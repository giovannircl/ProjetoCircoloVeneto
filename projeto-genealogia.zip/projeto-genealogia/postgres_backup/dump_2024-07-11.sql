--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: log_transacoes; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA log_transacoes;


ALTER SCHEMA log_transacoes OWNER TO postgres;

--
-- Name: registrar_operacao_log(); Type: FUNCTION; Schema: log_transacoes; Owner: postgres
--

CREATE FUNCTION log_transacoes.registrar_operacao_log() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO LOG_TRANSACOES.tbl_TransacoesRegistradas (
            nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_novos
        ) VALUES (
            TG_TABLE_SCHEMA, TG_TABLE_NAME, 'INSERT', current_user, current_timestamp, row_to_json(NEW)
        );
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO LOG_TRANSACOES.tbl_TransacoesRegistradas (
            nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_antigos, dados_novos
        ) VALUES (
            TG_TABLE_SCHEMA, TG_TABLE_NAME, 'UPDATE', current_user, current_timestamp, row_to_json(OLD), row_to_json(NEW)
        );
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO LOG_TRANSACOES.tbl_TransacoesRegistradas (
            nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_antigos
        ) VALUES (
            TG_TABLE_SCHEMA, TG_TABLE_NAME, 'DELETE', current_user, current_timestamp, row_to_json(OLD)
        );
        RETURN OLD;
    END IF;
END;
$$;


ALTER FUNCTION log_transacoes.registrar_operacao_log() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_transacoesregistradas; Type: TABLE; Schema: log_transacoes; Owner: postgres
--

CREATE TABLE log_transacoes.tbl_transacoesregistradas (
    id_log integer NOT NULL,
    nome_esquema text NOT NULL,
    nome_tabela text NOT NULL,
    operacao text NOT NULL,
    nome_usuario text NOT NULL,
    hora_transacao timestamp without time zone NOT NULL,
    dados_antigos jsonb,
    dados_novos jsonb
);


ALTER TABLE log_transacoes.tbl_transacoesregistradas OWNER TO postgres;

--
-- Name: tbl_transacoesregistradas_id_log_seq; Type: SEQUENCE; Schema: log_transacoes; Owner: postgres
--

CREATE SEQUENCE log_transacoes.tbl_transacoesregistradas_id_log_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE log_transacoes.tbl_transacoesregistradas_id_log_seq OWNER TO postgres;

--
-- Name: tbl_transacoesregistradas_id_log_seq; Type: SEQUENCE OWNED BY; Schema: log_transacoes; Owner: postgres
--

ALTER SEQUENCE log_transacoes.tbl_transacoesregistradas_id_log_seq OWNED BY log_transacoes.tbl_transacoesregistradas.id_log;


--
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa (
    id_pessoa integer NOT NULL,
    nome character varying(100) NOT NULL,
    sobrenome character varying(100) NOT NULL,
    dt_nasc date,
    local_nasc character varying(255),
    dt_obito date,
    dt_migracao date,
    dt_registro date,
    num_pagina integer,
    num_livro integer
);


ALTER TABLE public.pessoa OWNER TO postgres;

--
-- Name: pessoa_id_pessoa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pessoa_id_pessoa_seq
    AS integer
    START WITH 1
    INCREMENT BY 2
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pessoa_id_pessoa_seq OWNER TO postgres;

--
-- Name: pessoa_id_pessoa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pessoa_id_pessoa_seq OWNED BY public.pessoa.id_pessoa;


--
-- Name: relacionamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.relacionamento (
    id_relacionamento integer NOT NULL,
    id_pessoa_1 integer NOT NULL,
    id_pessoa_2 integer NOT NULL,
    dt_inicio date,
    dt_fim date,
    tipo_relacionamento character varying(20) DEFAULT 'Pai'::character varying NOT NULL,
    CONSTRAINT relacionamento_tipo_relacionamento_check CHECK (((tipo_relacionamento)::text = ANY (ARRAY[('Pai'::character varying)::text, ('Mãe'::character varying)::text, ('Filho(a)'::character varying)::text, ('Irmã(o)'::character varying)::text, ('Casado(a)'::character varying)::text])))
);


ALTER TABLE public.relacionamento OWNER TO postgres;

--
-- Name: relacionamento_id_relacionamento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.relacionamento_id_relacionamento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.relacionamento_id_relacionamento_seq OWNER TO postgres;

--
-- Name: relacionamento_id_relacionamento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.relacionamento_id_relacionamento_seq OWNED BY public.relacionamento.id_relacionamento;


--
-- Name: tbl_transacoesregistradas id_log; Type: DEFAULT; Schema: log_transacoes; Owner: postgres
--

ALTER TABLE ONLY log_transacoes.tbl_transacoesregistradas ALTER COLUMN id_log SET DEFAULT nextval('log_transacoes.tbl_transacoesregistradas_id_log_seq'::regclass);


--
-- Name: pessoa id_pessoa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa ALTER COLUMN id_pessoa SET DEFAULT nextval('public.pessoa_id_pessoa_seq'::regclass);


--
-- Name: relacionamento id_relacionamento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento ALTER COLUMN id_relacionamento SET DEFAULT nextval('public.relacionamento_id_relacionamento_seq'::regclass);


--
-- Data for Name: tbl_transacoesregistradas; Type: TABLE DATA; Schema: log_transacoes; Owner: postgres
--

COPY log_transacoes.tbl_transacoesregistradas (id_log, nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_antigos, dados_novos) FROM stdin;
27219	public	relacionamento	DELETE	postgres	2024-07-11 11:57:06.090757	{"dt_fim": null, "dt_inicio": "2010-01-01", "id_pessoa_1": 9, "id_pessoa_2": 8, "id_relacionamento": 20, "tipo_relacionamento": "Filho(a)"}	\N
27220	public	relacionamento	DELETE	postgres	2024-07-11 11:58:09.207647	{"dt_fim": null, "dt_inicio": "2015-01-01", "id_pessoa_1": 9, "id_pessoa_2": 10, "id_relacionamento": 21, "tipo_relacionamento": "Pai"}	\N
27221	public	relacionamento	INSERT	postgres	2024-07-11 12:04:33.442487	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 29, "id_pessoa_2": 10, "id_relacionamento": 112, "tipo_relacionamento": "Filho(a)"}
27222	public	relacionamento	INSERT	postgres	2024-07-11 12:04:33.454006	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 29, "id_relacionamento": 113, "tipo_relacionamento": "Pai"}
27223	public	relacionamento	INSERT	postgres	2024-07-11 12:06:34.309346	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 9, "id_relacionamento": 114, "tipo_relacionamento": "Pai"}
27224	public	relacionamento	INSERT	postgres	2024-07-11 12:06:34.315691	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 9, "id_pessoa_2": 10, "id_relacionamento": 115, "tipo_relacionamento": "Filho(a)"}
27225	public	relacionamento	INSERT	postgres	2024-07-11 12:07:12.82052	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 9, "id_pessoa_2": 10, "id_relacionamento": 116, "tipo_relacionamento": "Pai"}
27226	public	relacionamento	INSERT	postgres	2024-07-11 12:07:12.826999	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 9, "id_relacionamento": 117, "tipo_relacionamento": "Filho(a)"}
27227	public	relacionamento	DELETE	postgres	2024-07-11 12:07:17.519758	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 9, "id_pessoa_2": 10, "id_relacionamento": 116, "tipo_relacionamento": "Pai"}	\N
27228	public	pessoa	UPDATE	postgres	2024-07-11 12:07:42.702788	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveira", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveiraaaa", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}
27229	public	relacionamento	UPDATE	postgres	2024-07-11 12:13:09.229036	{"dt_fim": null, "dt_inicio": "2015-01-01", "id_pessoa_1": 10, "id_pessoa_2": 9, "id_relacionamento": 22, "tipo_relacionamento": "Filho(a)"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 20, "id_pessoa_2": 9, "id_relacionamento": 22, "tipo_relacionamento": "Filho(a)"}
27230	public	relacionamento	UPDATE	postgres	2024-07-11 12:13:58.865411	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 11, "id_pessoa_2": 10, "id_relacionamento": 24, "tipo_relacionamento": "Filho(a)"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 11, "id_pessoa_2": 10, "id_relacionamento": 24, "tipo_relacionamento": "Mãe"}
27231	public	relacionamento	UPDATE	postgres	2024-07-11 12:14:59.728232	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 10, "id_pessoa_2": 11, "id_relacionamento": 23, "tipo_relacionamento": "Pai"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 29, "id_pessoa_2": 11, "id_relacionamento": 23, "tipo_relacionamento": "Pai"}
27232	public	relacionamento	UPDATE	postgres	2024-07-11 12:16:10.40821	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 9, "id_pessoa_2": 12, "id_relacionamento": 57, "tipo_relacionamento": "Mãe"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 9, "id_pessoa_2": 12, "id_relacionamento": 57, "tipo_relacionamento": "Filho(a)"}
27233	public	relacionamento	DELETE	postgres	2024-07-11 12:17:18.935587	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 12, "id_pessoa_2": 11, "id_relacionamento": 26, "tipo_relacionamento": "Filho(a)"}	\N
27234	public	pessoa	UPDATE	postgres	2024-07-11 13:25:49.78701	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveiraaaa", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveiraa", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}
27235	public	pessoa	UPDATE	postgres	2024-07-11 13:27:00.86851	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveiraa", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveiraaaaa", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}
27236	public	relacionamento	UPDATE	postgres	2024-07-11 13:27:27.519278	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 11, "id_pessoa_2": 12, "id_relacionamento": 25, "tipo_relacionamento": "Pai"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 20, "id_pessoa_2": 12, "id_relacionamento": 25, "tipo_relacionamento": "Pai"}
27237	public	pessoa	UPDATE	postgres	2024-07-11 13:28:29.970892	{"nome": "Antônio", "dt_nasc": "1986-04-14", "dt_obito": null, "id_pessoa": 20, "num_livro": 1, "sobrenome": "Barbosa", "local_nasc": "Campo Grande", "num_pagina": 1, "dt_migracao": "2024-03-01", "dt_registro": "2024-03-02"}	{"nome": "Antônio", "dt_nasc": "1986-04-18", "dt_obito": null, "id_pessoa": 20, "num_livro": 1, "sobrenome": "Barbosa", "local_nasc": "Campo Grande", "num_pagina": 1, "dt_migracao": "2024-03-01", "dt_registro": "2024-03-02"}
27238	public	pessoa	INSERT	postgres	2024-07-11 13:28:47.505665	\N	{"nome": "teste", "dt_nasc": "2024-07-25", "dt_obito": null, "id_pessoa": 28043, "num_livro": null, "sobrenome": "teste", "local_nasc": "", "num_pagina": null, "dt_migracao": null, "dt_registro": null}
27239	public	relacionamento	DELETE	postgres	2024-07-11 13:28:58.350198	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 12, "id_pessoa_2": 9, "id_relacionamento": 58, "tipo_relacionamento": "Filho(a)"}	\N
27240	public	relacionamento	DELETE	postgres	2024-07-11 13:28:58.351739	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 9, "id_relacionamento": 114, "tipo_relacionamento": "Pai"}	\N
27241	public	relacionamento	DELETE	postgres	2024-07-11 13:28:58.352496	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 9, "id_pessoa_2": 10, "id_relacionamento": 115, "tipo_relacionamento": "Filho(a)"}	\N
27242	public	relacionamento	DELETE	postgres	2024-07-11 13:28:58.353428	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 9, "id_relacionamento": 117, "tipo_relacionamento": "Filho(a)"}	\N
27243	public	relacionamento	DELETE	postgres	2024-07-11 13:28:58.355158	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 20, "id_pessoa_2": 9, "id_relacionamento": 22, "tipo_relacionamento": "Filho(a)"}	\N
27244	public	relacionamento	DELETE	postgres	2024-07-11 13:28:58.35607	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 9, "id_pessoa_2": 12, "id_relacionamento": 57, "tipo_relacionamento": "Filho(a)"}	\N
27245	public	pessoa	DELETE	postgres	2024-07-11 13:28:58.356698	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveiraaaaa", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}	\N
27246	public	pessoa	UPDATE	postgres	2024-07-11 13:29:06.284066	{"nome": "Carlos", "dt_nasc": "1982-07-08", "dt_obito": null, "id_pessoa": 10, "num_livro": 1, "sobrenome": "Ferreira", "local_nasc": "Porto Alegre", "num_pagina": 1, "dt_migracao": "2023-05-01", "dt_registro": "2023-05-02"}	{"nome": "Carlos", "dt_nasc": "1982-07-30", "dt_obito": null, "id_pessoa": 10, "num_livro": 1, "sobrenome": "Ferreira", "local_nasc": "Porto Alegre", "num_pagina": 1, "dt_migracao": "2023-05-01", "dt_registro": "2023-05-02"}
27247	public	relacionamento	UPDATE	postgres	2024-07-11 13:29:25.399698	{"dt_fim": null, "dt_inicio": "2040-01-01", "id_pessoa_1": 14, "id_pessoa_2": 15, "id_relacionamento": 31, "tipo_relacionamento": "Pai"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 34, "id_pessoa_2": 15, "id_relacionamento": 31, "tipo_relacionamento": "Pai"}
27248	public	relacionamento	INSERT	postgres	2024-07-11 13:29:34.043447	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 27067, "id_pessoa_2": 26039, "id_relacionamento": 118, "tipo_relacionamento": "Casado(a)"}
27249	public	relacionamento	INSERT	postgres	2024-07-11 13:29:34.051768	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 26039, "id_pessoa_2": 27067, "id_relacionamento": 119, "tipo_relacionamento": "Casado(a)"}
27250	public	relacionamento	DELETE	postgres	2024-07-11 13:29:39.382769	{"dt_fim": null, "dt_inicio": "2040-01-01", "id_pessoa_1": 15, "id_pessoa_2": 14, "id_relacionamento": 32, "tipo_relacionamento": "Filho(a)"}	\N
27251	public	relacionamento	DELETE	postgres	2024-07-11 13:30:16.381361	{"dt_fim": null, "dt_inicio": "2045-01-01", "id_pessoa_1": 15, "id_pessoa_2": 16, "id_relacionamento": 33, "tipo_relacionamento": "Pai"}	\N
27252	public	relacionamento	DELETE	postgres	2024-07-11 13:35:04.930077	{"dt_fim": null, "dt_inicio": "2045-01-01", "id_pessoa_1": 16, "id_pessoa_2": 15, "id_relacionamento": 34, "tipo_relacionamento": "Filho(a)"}	\N
27253	public	relacionamento	DELETE	postgres	2024-07-11 13:35:08.676901	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 16, "id_pessoa_2": 17, "id_relacionamento": 35, "tipo_relacionamento": "Pai"}	\N
27254	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.314055	{"dt_fim": null, "dt_inicio": "2065-01-01", "id_pessoa_1": 19, "id_pessoa_2": 20, "id_relacionamento": 41, "tipo_relacionamento": "Pai"}	\N
27255	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.326377	{"dt_fim": null, "dt_inicio": "2065-01-01", "id_pessoa_1": 20, "id_pessoa_2": 19, "id_relacionamento": 42, "tipo_relacionamento": "Filho(a)"}	\N
27256	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.327069	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 20, "id_pessoa_2": 21, "id_relacionamento": 43, "tipo_relacionamento": "Pai"}	\N
27257	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.327636	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 21, "id_pessoa_2": 20, "id_relacionamento": 44, "tipo_relacionamento": "Filho(a)"}	\N
27258	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.328095	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 20, "id_pessoa_2": 23, "id_relacionamento": 67, "tipo_relacionamento": "Mãe"}	\N
27259	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.328604	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 23, "id_pessoa_2": 20, "id_relacionamento": 68, "tipo_relacionamento": "Filho(a)"}	\N
27260	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.329074	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 20, "id_pessoa_2": 21, "id_relacionamento": 81, "tipo_relacionamento": "Irmã(o)"}	\N
27261	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.329518	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 21, "id_pessoa_2": 20, "id_relacionamento": 82, "tipo_relacionamento": "Irmã(o)"}	\N
27262	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.329998	{"dt_fim": "2024-07-11", "dt_inicio": "2024-07-11", "id_pessoa_1": 20, "id_pessoa_2": 31, "id_relacionamento": 94, "tipo_relacionamento": "Casado(a)"}	\N
27263	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.330431	{"dt_fim": "2024-07-11", "dt_inicio": "2024-07-11", "id_pessoa_1": 31, "id_pessoa_2": 20, "id_relacionamento": 95, "tipo_relacionamento": "Casado(a)"}	\N
27264	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.330864	{"dt_fim": "2024-07-12", "dt_inicio": "2024-07-10", "id_pessoa_1": 20, "id_pessoa_2": 27375, "id_relacionamento": 98, "tipo_relacionamento": "Casado(a)"}	\N
27265	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.331291	{"dt_fim": "2024-07-12", "dt_inicio": "2024-07-10", "id_pessoa_1": 27375, "id_pessoa_2": 20, "id_relacionamento": 99, "tipo_relacionamento": "Casado(a)"}	\N
27266	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.331737	{"dt_fim": "2024-07-12", "dt_inicio": "2024-07-10", "id_pessoa_1": 20, "id_pessoa_2": 27375, "id_relacionamento": 100, "tipo_relacionamento": "Casado(a)"}	\N
27267	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.332124	{"dt_fim": "2024-07-12", "dt_inicio": "2024-07-10", "id_pessoa_1": 27375, "id_pessoa_2": 20, "id_relacionamento": 101, "tipo_relacionamento": "Casado(a)"}	\N
27268	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.332602	{"dt_fim": "2024-07-11", "dt_inicio": "2024-07-11", "id_pessoa_1": 20, "id_pessoa_2": 21, "id_relacionamento": 106, "tipo_relacionamento": "Casado(a)"}	\N
27269	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.333039	{"dt_fim": "2024-07-11", "dt_inicio": "2024-07-11", "id_pessoa_1": 21, "id_pessoa_2": 20, "id_relacionamento": 107, "tipo_relacionamento": "Casado(a)"}	\N
27270	public	relacionamento	DELETE	postgres	2024-07-11 13:43:31.333458	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 20, "id_pessoa_2": 12, "id_relacionamento": 25, "tipo_relacionamento": "Pai"}	\N
27271	public	pessoa	DELETE	postgres	2024-07-11 13:43:31.333912	{"nome": "Antônio", "dt_nasc": "1986-04-18", "dt_obito": null, "id_pessoa": 20, "num_livro": 1, "sobrenome": "Barbosa", "local_nasc": "Campo Grande", "num_pagina": 1, "dt_migracao": "2024-03-01", "dt_registro": "2024-03-02"}	\N
27272	public	relacionamento	DELETE	postgres	2024-07-11 13:44:10.275932	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 17, "id_pessoa_2": 16, "id_relacionamento": 36, "tipo_relacionamento": "Filho(a)"}	\N
27273	public	relacionamento	UPDATE	postgres	2024-07-11 13:44:15.217959	{"dt_fim": null, "dt_inicio": "2055-01-01", "id_pessoa_1": 17, "id_pessoa_2": 18, "id_relacionamento": 37, "tipo_relacionamento": "Pai"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 17, "id_pessoa_2": 18, "id_relacionamento": 37, "tipo_relacionamento": "Irmã(o)"}
27274	public	relacionamento	UPDATE	postgres	2024-07-11 13:44:18.933698	{"dt_fim": null, "dt_inicio": "2060-01-01", "id_pessoa_1": 18, "id_pessoa_2": 19, "id_relacionamento": 39, "tipo_relacionamento": "Pai"}	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 18, "id_pessoa_2": 26233, "id_relacionamento": 39, "tipo_relacionamento": "Pai"}
27275	public	pessoa	UPDATE	postgres	2024-07-11 13:45:24.305044	{"nome": "Carlos", "dt_nasc": "1982-07-30", "dt_obito": null, "id_pessoa": 10, "num_livro": 1, "sobrenome": "Ferreira", "local_nasc": "Porto Alegre", "num_pagina": 1, "dt_migracao": "2023-05-01", "dt_registro": "2023-05-02"}	{"nome": "Carlosssss", "dt_nasc": "1982-07-30", "dt_obito": null, "id_pessoa": 10, "num_livro": 1, "sobrenome": "Ferreira", "local_nasc": "Porto Alegre", "num_pagina": 1, "dt_migracao": "2023-05-01", "dt_registro": "2023-05-02"}
27276	public	pessoa	INSERT	postgres	2024-07-11 13:45:30.996901	\N	{"nome": "test", "dt_nasc": null, "dt_obito": null, "id_pessoa": 28045, "num_livro": null, "sobrenome": "asdasdasdasd", "local_nasc": "", "num_pagina": null, "dt_migracao": null, "dt_registro": null}
27277	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.764421	{"dt_fim": null, "dt_inicio": "2005-01-01", "id_pessoa_1": 7, "id_pessoa_2": 10, "id_relacionamento": 53, "tipo_relacionamento": "Mãe"}	\N
27278	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.767457	{"dt_fim": null, "dt_inicio": "2005-01-01", "id_pessoa_1": 10, "id_pessoa_2": 7, "id_relacionamento": 54, "tipo_relacionamento": "Filho(a)"}	\N
27279	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.768672	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 10, "id_pessoa_2": 11, "id_relacionamento": 71, "tipo_relacionamento": "Irmã(o)"}	\N
27280	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.770132	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 11, "id_pessoa_2": 10, "id_relacionamento": 72, "tipo_relacionamento": "Irmã(o)"}	\N
27281	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.770888	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 21, "id_relacionamento": 108, "tipo_relacionamento": "Pai"}	\N
27282	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.771682	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 21, "id_pessoa_2": 10, "id_relacionamento": 109, "tipo_relacionamento": "Filho(a)"}	\N
27283	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.77222	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 21, "id_relacionamento": 110, "tipo_relacionamento": "Pai"}	\N
27284	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.772761	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 21, "id_pessoa_2": 10, "id_relacionamento": 111, "tipo_relacionamento": "Filho(a)"}	\N
27285	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.77338	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 29, "id_pessoa_2": 10, "id_relacionamento": 112, "tipo_relacionamento": "Filho(a)"}	\N
27286	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.773851	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 10, "id_pessoa_2": 29, "id_relacionamento": 113, "tipo_relacionamento": "Pai"}	\N
27287	public	relacionamento	DELETE	postgres	2024-07-11 13:45:33.774323	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 11, "id_pessoa_2": 10, "id_relacionamento": 24, "tipo_relacionamento": "Mãe"}	\N
27288	public	pessoa	DELETE	postgres	2024-07-11 13:45:33.774799	{"nome": "Carlosssss", "dt_nasc": "1982-07-30", "dt_obito": null, "id_pessoa": 10, "num_livro": 1, "sobrenome": "Ferreira", "local_nasc": "Porto Alegre", "num_pagina": 1, "dt_migracao": "2023-05-01", "dt_registro": "2023-05-02"}	\N
27289	public	relacionamento	INSERT	postgres	2024-07-11 13:45:58.93448	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 30, "id_pessoa_2": 27039, "id_relacionamento": 120, "tipo_relacionamento": "Irmã(o)"}
27290	public	relacionamento	INSERT	postgres	2024-07-11 13:45:58.936464	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 27039, "id_pessoa_2": 30, "id_relacionamento": 121, "tipo_relacionamento": "Irmã(o)"}
27291	public	relacionamento	DELETE	postgres	2024-07-11 13:46:05.702274	{"dt_fim": null, "dt_inicio": "2055-01-01", "id_pessoa_1": 18, "id_pessoa_2": 17, "id_relacionamento": 38, "tipo_relacionamento": "Filho(a)"}	\N
\.


--
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pessoa (id_pessoa, nome, sobrenome, dt_nasc, local_nasc, dt_obito, dt_migracao, dt_registro, num_pagina, num_livro) FROM stdin;
7	Maria	Santos	1985-08-20	Rio de Janeiro	\N	2023-02-01	2023-02-02	1	1
11	Mariana	Costa	1992-01-30	Curitiba	\N	2023-06-01	2023-06-02	1	1
12	José	Rodrigues	1987-09-18	Recife	\N	2023-07-01	2023-07-02	1	1
14	Fernando	Gomes	1975-04-05	Belém	\N	2023-09-01	2023-09-02	1	1
15	Isabela	Martins	1998-11-03	Florianópolis	\N	2023-10-01	2023-10-02	1	1
16	Rafael	Rocha	1989-02-28	Natal	\N	2023-11-01	2023-11-02	1	1
17	Luciana	Pereira	1983-10-17	Fortaleza	\N	2023-12-01	2023-12-02	1	1
18	Marcos	Lima	1993-07-07	Vitória	\N	2024-01-01	2024-01-02	1	1
19	Sandra	Ramos	1979-09-22	João Pessoa	\N	2024-02-01	2024-02-02	1	1
21	Patrícia	Cavalcanti	1991-08-08	Teresina	\N	2024-04-01	2024-04-02	1	1
22	Paulo	Freitas	1977-12-01	Cuiabá	\N	2024-05-01	2024-05-02	1	1
23	Juliana	Nunes	1984-05-19	Porto Velho	\N	2024-06-01	2024-06-02	1	1
24	Gustavo	Mendes	1996-03-09	Macapá	\N	2024-07-01	2024-07-02	1	1
25	Cristina	Dias	1981-11-11	Boa Vista	\N	2024-08-01	2024-08-02	1	1
26	Ricardo	Silva	1980-05-15	São Paulo	\N	\N	2024-07-10	10	1
28	Felipe	Oliveira	1975-03-10	Belo Horizonte	\N	\N	2024-07-10	12	1
29	Carolina	Martins	1990-07-28	Porto Alegre	\N	\N	2024-07-10	13	1
30	Gustavo	Pereira	1987-01-12	Curitiba	\N	\N	2024-07-10	14	1
31	Mariana	Gomes	1984-06-30	Salvador	\N	\N	2024-07-10	15	1
32	Rodrigo	Almeida	1978-11-05	Fortaleza	\N	\N	2024-07-10	16	1
33	Vanessa	Ferreira	1983-04-17	Recife	\N	\N	2024-07-10	17	1
34	Fernando	Mendes	1995-08-25	Brasília	\N	\N	2024-07-10	18	1
8	PedroTESTE	Souza	1978-03-10	Brasília	\N	2023-03-01	2023-03-02	1	1
37	TESTE	TESTE	2003-08-02	SP	\N	\N	\N	1	1
27039	Pessoa1	Sobrenome1	2024-07-10	Local de Nascimento 1	\N	\N	2024-07-11	1	1
27041	Pessoa2	Sobrenome2	2024-07-09	Local de Nascimento 2	\N	\N	2024-07-11	2	2
27043	Pessoa3	Sobrenome3	2024-07-08	Local de Nascimento 3	\N	\N	2024-07-11	3	3
27045	Pessoa4	Sobrenome4	2024-07-07	Local de Nascimento 4	\N	\N	2024-07-11	4	4
27047	Pessoa5	Sobrenome5	2024-07-06	Local de Nascimento 5	\N	\N	2024-07-11	5	5
27049	Pessoa6	Sobrenome6	2024-07-05	Local de Nascimento 6	\N	\N	2024-07-11	6	6
27051	Pessoa7	Sobrenome7	2024-07-04	Local de Nascimento 7	\N	\N	2024-07-11	7	7
27053	Pessoa8	Sobrenome8	2024-07-03	Local de Nascimento 8	\N	\N	2024-07-11	8	8
27055	Pessoa9	Sobrenome9	2024-07-02	Local de Nascimento 9	\N	\N	2024-07-11	9	9
27057	Pessoa10	Sobrenome10	2024-07-01	Local de Nascimento 10	\N	\N	2024-07-11	10	10
27059	Pessoa11	Sobrenome11	2024-06-30	Local de Nascimento 11	\N	\N	2024-07-11	11	11
27061	Pessoa12	Sobrenome12	2024-06-29	Local de Nascimento 12	\N	\N	2024-07-11	12	12
27063	Pessoa13	Sobrenome13	2024-06-28	Local de Nascimento 13	\N	\N	2024-07-11	13	13
27065	Pessoa14	Sobrenome14	2024-06-27	Local de Nascimento 14	\N	\N	2024-07-11	14	14
27067	Pessoa15	Sobrenome15	2024-06-26	Local de Nascimento 15	\N	\N	2024-07-11	15	15
27069	Pessoa16	Sobrenome16	2024-06-25	Local de Nascimento 16	\N	\N	2024-07-11	16	16
27071	Pessoa17	Sobrenome17	2024-06-24	Local de Nascimento 17	\N	\N	2024-07-11	17	17
27073	Pessoa18	Sobrenome18	2024-06-23	Local de Nascimento 18	\N	\N	2024-07-11	18	18
27075	Pessoa19	Sobrenome19	2024-06-22	Local de Nascimento 19	\N	\N	2024-07-11	19	19
27077	Pessoa20	Sobrenome20	2024-06-21	Local de Nascimento 20	\N	\N	2024-07-11	20	20
27079	Pessoa21	Sobrenome21	2024-06-20	Local de Nascimento 21	\N	\N	2024-07-11	21	21
27081	Pessoa22	Sobrenome22	2024-06-19	Local de Nascimento 22	\N	\N	2024-07-11	22	22
27083	Pessoa23	Sobrenome23	2024-06-18	Local de Nascimento 23	\N	\N	2024-07-11	23	23
27085	Pessoa24	Sobrenome24	2024-06-17	Local de Nascimento 24	\N	\N	2024-07-11	24	24
27087	Pessoa25	Sobrenome25	2024-06-16	Local de Nascimento 25	\N	\N	2024-07-11	25	25
27089	Pessoa26	Sobrenome26	2024-06-15	Local de Nascimento 26	\N	\N	2024-07-11	26	26
27091	Pessoa27	Sobrenome27	2024-06-14	Local de Nascimento 27	\N	\N	2024-07-11	27	27
27093	Pessoa28	Sobrenome28	2024-06-13	Local de Nascimento 28	\N	\N	2024-07-11	28	28
27095	Pessoa29	Sobrenome29	2024-06-12	Local de Nascimento 29	\N	\N	2024-07-11	29	29
27097	Pessoa30	Sobrenome30	2024-06-11	Local de Nascimento 30	\N	\N	2024-07-11	30	30
27099	Pessoa31	Sobrenome31	2024-06-10	Local de Nascimento 31	\N	\N	2024-07-11	31	31
27101	Pessoa32	Sobrenome32	2024-06-09	Local de Nascimento 32	\N	\N	2024-07-11	32	32
27103	Pessoa33	Sobrenome33	2024-06-08	Local de Nascimento 33	\N	\N	2024-07-11	33	33
27105	Pessoa34	Sobrenome34	2024-06-07	Local de Nascimento 34	\N	\N	2024-07-11	34	34
27107	Pessoa35	Sobrenome35	2024-06-06	Local de Nascimento 35	\N	\N	2024-07-11	35	35
27109	Pessoa36	Sobrenome36	2024-06-05	Local de Nascimento 36	\N	\N	2024-07-11	36	36
27111	Pessoa37	Sobrenome37	2024-06-04	Local de Nascimento 37	\N	\N	2024-07-11	37	37
27113	Pessoa38	Sobrenome38	2024-06-03	Local de Nascimento 38	\N	\N	2024-07-11	38	38
27115	Pessoa39	Sobrenome39	2024-06-02	Local de Nascimento 39	\N	\N	2024-07-11	39	39
27117	Pessoa40	Sobrenome40	2024-06-01	Local de Nascimento 40	\N	\N	2024-07-11	40	40
27119	Pessoa41	Sobrenome41	2024-05-31	Local de Nascimento 41	\N	\N	2024-07-11	41	41
27121	Pessoa42	Sobrenome42	2024-05-30	Local de Nascimento 42	\N	\N	2024-07-11	42	42
27123	Pessoa43	Sobrenome43	2024-05-29	Local de Nascimento 43	\N	\N	2024-07-11	43	43
27125	Pessoa44	Sobrenome44	2024-05-28	Local de Nascimento 44	\N	\N	2024-07-11	44	44
27127	Pessoa45	Sobrenome45	2024-05-27	Local de Nascimento 45	\N	\N	2024-07-11	45	45
27129	Pessoa46	Sobrenome46	2024-05-26	Local de Nascimento 46	\N	\N	2024-07-11	46	46
27131	Pessoa47	Sobrenome47	2024-05-25	Local de Nascimento 47	\N	\N	2024-07-11	47	47
27133	Pessoa48	Sobrenome48	2024-05-24	Local de Nascimento 48	\N	\N	2024-07-11	48	48
27135	Pessoa49	Sobrenome49	2024-05-23	Local de Nascimento 49	\N	\N	2024-07-11	49	49
27137	Pessoa50	Sobrenome50	2024-05-22	Local de Nascimento 50	\N	\N	2024-07-11	50	50
27139	Pessoa51	Sobrenome51	2024-05-21	Local de Nascimento 51	\N	\N	2024-07-11	51	51
27141	Pessoa52	Sobrenome52	2024-05-20	Local de Nascimento 52	\N	\N	2024-07-11	52	52
27143	Pessoa53	Sobrenome53	2024-05-19	Local de Nascimento 53	\N	\N	2024-07-11	53	53
27145	Pessoa54	Sobrenome54	2024-05-18	Local de Nascimento 54	\N	\N	2024-07-11	54	54
27147	Pessoa55	Sobrenome55	2024-05-17	Local de Nascimento 55	\N	\N	2024-07-11	55	55
27149	Pessoa56	Sobrenome56	2024-05-16	Local de Nascimento 56	\N	\N	2024-07-11	56	56
27151	Pessoa57	Sobrenome57	2024-05-15	Local de Nascimento 57	\N	\N	2024-07-11	57	57
27153	Pessoa58	Sobrenome58	2024-05-14	Local de Nascimento 58	\N	\N	2024-07-11	58	58
27155	Pessoa59	Sobrenome59	2024-05-13	Local de Nascimento 59	\N	\N	2024-07-11	59	59
27157	Pessoa60	Sobrenome60	2024-05-12	Local de Nascimento 60	\N	\N	2024-07-11	60	60
27159	Pessoa61	Sobrenome61	2024-05-11	Local de Nascimento 61	\N	\N	2024-07-11	61	61
27161	Pessoa62	Sobrenome62	2024-05-10	Local de Nascimento 62	\N	\N	2024-07-11	62	62
27163	Pessoa63	Sobrenome63	2024-05-09	Local de Nascimento 63	\N	\N	2024-07-11	63	63
27165	Pessoa64	Sobrenome64	2024-05-08	Local de Nascimento 64	\N	\N	2024-07-11	64	64
27167	Pessoa65	Sobrenome65	2024-05-07	Local de Nascimento 65	\N	\N	2024-07-11	65	65
27169	Pessoa66	Sobrenome66	2024-05-06	Local de Nascimento 66	\N	\N	2024-07-11	66	66
27171	Pessoa67	Sobrenome67	2024-05-05	Local de Nascimento 67	\N	\N	2024-07-11	67	67
27173	Pessoa68	Sobrenome68	2024-05-04	Local de Nascimento 68	\N	\N	2024-07-11	68	68
27175	Pessoa69	Sobrenome69	2024-05-03	Local de Nascimento 69	\N	\N	2024-07-11	69	69
27177	Pessoa70	Sobrenome70	2024-05-02	Local de Nascimento 70	\N	\N	2024-07-11	70	70
27179	Pessoa71	Sobrenome71	2024-05-01	Local de Nascimento 71	\N	\N	2024-07-11	71	71
27181	Pessoa72	Sobrenome72	2024-04-30	Local de Nascimento 72	\N	\N	2024-07-11	72	72
27183	Pessoa73	Sobrenome73	2024-04-29	Local de Nascimento 73	\N	\N	2024-07-11	73	73
27185	Pessoa74	Sobrenome74	2024-04-28	Local de Nascimento 74	\N	\N	2024-07-11	74	74
27187	Pessoa75	Sobrenome75	2024-04-27	Local de Nascimento 75	\N	\N	2024-07-11	75	75
27189	Pessoa76	Sobrenome76	2024-04-26	Local de Nascimento 76	\N	\N	2024-07-11	76	76
27191	Pessoa77	Sobrenome77	2024-04-25	Local de Nascimento 77	\N	\N	2024-07-11	77	77
27193	Pessoa78	Sobrenome78	2024-04-24	Local de Nascimento 78	\N	\N	2024-07-11	78	78
27195	Pessoa79	Sobrenome79	2024-04-23	Local de Nascimento 79	\N	\N	2024-07-11	79	79
27197	Pessoa80	Sobrenome80	2024-04-22	Local de Nascimento 80	\N	\N	2024-07-11	80	80
27199	Pessoa81	Sobrenome81	2024-04-21	Local de Nascimento 81	\N	\N	2024-07-11	81	81
27201	Pessoa82	Sobrenome82	2024-04-20	Local de Nascimento 82	\N	\N	2024-07-11	82	82
27203	Pessoa83	Sobrenome83	2024-04-19	Local de Nascimento 83	\N	\N	2024-07-11	83	83
27205	Pessoa84	Sobrenome84	2024-04-18	Local de Nascimento 84	\N	\N	2024-07-11	84	84
27207	Pessoa85	Sobrenome85	2024-04-17	Local de Nascimento 85	\N	\N	2024-07-11	85	85
27209	Pessoa86	Sobrenome86	2024-04-16	Local de Nascimento 86	\N	\N	2024-07-11	86	86
27211	Pessoa87	Sobrenome87	2024-04-15	Local de Nascimento 87	\N	\N	2024-07-11	87	87
27213	Pessoa88	Sobrenome88	2024-04-14	Local de Nascimento 88	\N	\N	2024-07-11	88	88
27215	Pessoa89	Sobrenome89	2024-04-13	Local de Nascimento 89	\N	\N	2024-07-11	89	89
27217	Pessoa90	Sobrenome90	2024-04-12	Local de Nascimento 90	\N	\N	2024-07-11	90	90
27219	Pessoa91	Sobrenome91	2024-04-11	Local de Nascimento 91	\N	\N	2024-07-11	91	91
27221	Pessoa92	Sobrenome92	2024-04-10	Local de Nascimento 92	\N	\N	2024-07-11	92	92
27223	Pessoa93	Sobrenome93	2024-04-09	Local de Nascimento 93	\N	\N	2024-07-11	93	93
27225	Pessoa94	Sobrenome94	2024-04-08	Local de Nascimento 94	\N	\N	2024-07-11	94	94
27227	Pessoa95	Sobrenome95	2024-04-07	Local de Nascimento 95	\N	\N	2024-07-11	95	95
27229	Pessoa96	Sobrenome96	2024-04-06	Local de Nascimento 96	\N	\N	2024-07-11	96	96
27231	Pessoa97	Sobrenome97	2024-04-05	Local de Nascimento 97	\N	\N	2024-07-11	97	97
27233	Pessoa98	Sobrenome98	2024-04-04	Local de Nascimento 98	\N	\N	2024-07-11	98	98
27235	Pessoa99	Sobrenome99	2024-04-03	Local de Nascimento 99	\N	\N	2024-07-11	99	99
27237	Pessoa100	Sobrenome100	2024-04-02	Local de Nascimento 100	\N	\N	2024-07-11	100	100
27239	Pessoa101	Sobrenome101	2024-04-01	Local de Nascimento 101	\N	\N	2024-07-11	101	101
27241	Pessoa102	Sobrenome102	2024-03-31	Local de Nascimento 102	\N	\N	2024-07-11	102	102
27243	Pessoa103	Sobrenome103	2024-03-30	Local de Nascimento 103	\N	\N	2024-07-11	103	103
27245	Pessoa104	Sobrenome104	2024-03-29	Local de Nascimento 104	\N	\N	2024-07-11	104	104
27247	Pessoa105	Sobrenome105	2024-03-28	Local de Nascimento 105	\N	\N	2024-07-11	105	105
27249	Pessoa106	Sobrenome106	2024-03-27	Local de Nascimento 106	\N	\N	2024-07-11	106	106
27251	Pessoa107	Sobrenome107	2024-03-26	Local de Nascimento 107	\N	\N	2024-07-11	107	107
27253	Pessoa108	Sobrenome108	2024-03-25	Local de Nascimento 108	\N	\N	2024-07-11	108	108
27255	Pessoa109	Sobrenome109	2024-03-24	Local de Nascimento 109	\N	\N	2024-07-11	109	109
27257	Pessoa110	Sobrenome110	2024-03-23	Local de Nascimento 110	\N	\N	2024-07-11	110	110
27259	Pessoa111	Sobrenome111	2024-03-22	Local de Nascimento 111	\N	\N	2024-07-11	111	111
27261	Pessoa112	Sobrenome112	2024-03-21	Local de Nascimento 112	\N	\N	2024-07-11	112	112
27263	Pessoa113	Sobrenome113	2024-03-20	Local de Nascimento 113	\N	\N	2024-07-11	113	113
27265	Pessoa114	Sobrenome114	2024-03-19	Local de Nascimento 114	\N	\N	2024-07-11	114	114
27267	Pessoa115	Sobrenome115	2024-03-18	Local de Nascimento 115	\N	\N	2024-07-11	115	115
27269	Pessoa116	Sobrenome116	2024-03-17	Local de Nascimento 116	\N	\N	2024-07-11	116	116
27271	Pessoa117	Sobrenome117	2024-03-16	Local de Nascimento 117	\N	\N	2024-07-11	117	117
27273	Pessoa118	Sobrenome118	2024-03-15	Local de Nascimento 118	\N	\N	2024-07-11	118	118
27275	Pessoa119	Sobrenome119	2024-03-14	Local de Nascimento 119	\N	\N	2024-07-11	119	119
27277	Pessoa120	Sobrenome120	2024-03-13	Local de Nascimento 120	\N	\N	2024-07-11	120	120
27279	Pessoa121	Sobrenome121	2024-03-12	Local de Nascimento 121	\N	\N	2024-07-11	121	121
27281	Pessoa122	Sobrenome122	2024-03-11	Local de Nascimento 122	\N	\N	2024-07-11	122	122
27283	Pessoa123	Sobrenome123	2024-03-10	Local de Nascimento 123	\N	\N	2024-07-11	123	123
27285	Pessoa124	Sobrenome124	2024-03-09	Local de Nascimento 124	\N	\N	2024-07-11	124	124
27287	Pessoa125	Sobrenome125	2024-03-08	Local de Nascimento 125	\N	\N	2024-07-11	125	125
27289	Pessoa126	Sobrenome126	2024-03-07	Local de Nascimento 126	\N	\N	2024-07-11	126	126
27291	Pessoa127	Sobrenome127	2024-03-06	Local de Nascimento 127	\N	\N	2024-07-11	127	127
27293	Pessoa128	Sobrenome128	2024-03-05	Local de Nascimento 128	\N	\N	2024-07-11	128	128
27295	Pessoa129	Sobrenome129	2024-03-04	Local de Nascimento 129	\N	\N	2024-07-11	129	129
27297	Pessoa130	Sobrenome130	2024-03-03	Local de Nascimento 130	\N	\N	2024-07-11	130	130
27299	Pessoa131	Sobrenome131	2024-03-02	Local de Nascimento 131	\N	\N	2024-07-11	131	131
27301	Pessoa132	Sobrenome132	2024-03-01	Local de Nascimento 132	\N	\N	2024-07-11	132	132
27303	Pessoa133	Sobrenome133	2024-02-29	Local de Nascimento 133	\N	\N	2024-07-11	133	133
27305	Pessoa134	Sobrenome134	2024-02-28	Local de Nascimento 134	\N	\N	2024-07-11	134	134
27307	Pessoa135	Sobrenome135	2024-02-27	Local de Nascimento 135	\N	\N	2024-07-11	135	135
27309	Pessoa136	Sobrenome136	2024-02-26	Local de Nascimento 136	\N	\N	2024-07-11	136	136
27311	Pessoa137	Sobrenome137	2024-02-25	Local de Nascimento 137	\N	\N	2024-07-11	137	137
27313	Pessoa138	Sobrenome138	2024-02-24	Local de Nascimento 138	\N	\N	2024-07-11	138	138
27315	Pessoa139	Sobrenome139	2024-02-23	Local de Nascimento 139	\N	\N	2024-07-11	139	139
27317	Pessoa140	Sobrenome140	2024-02-22	Local de Nascimento 140	\N	\N	2024-07-11	140	140
27319	Pessoa141	Sobrenome141	2024-02-21	Local de Nascimento 141	\N	\N	2024-07-11	141	141
27321	Pessoa142	Sobrenome142	2024-02-20	Local de Nascimento 142	\N	\N	2024-07-11	142	142
27323	Pessoa143	Sobrenome143	2024-02-19	Local de Nascimento 143	\N	\N	2024-07-11	143	143
27325	Pessoa144	Sobrenome144	2024-02-18	Local de Nascimento 144	\N	\N	2024-07-11	144	144
27327	Pessoa145	Sobrenome145	2024-02-17	Local de Nascimento 145	\N	\N	2024-07-11	145	145
27329	Pessoa146	Sobrenome146	2024-02-16	Local de Nascimento 146	\N	\N	2024-07-11	146	146
27331	Pessoa147	Sobrenome147	2024-02-15	Local de Nascimento 147	\N	\N	2024-07-11	147	147
27333	Pessoa148	Sobrenome148	2024-02-14	Local de Nascimento 148	\N	\N	2024-07-11	148	148
27335	Pessoa149	Sobrenome149	2024-02-13	Local de Nascimento 149	\N	\N	2024-07-11	149	149
27337	Pessoa150	Sobrenome150	2024-02-12	Local de Nascimento 150	\N	\N	2024-07-11	150	150
27339	Pessoa151	Sobrenome151	2024-02-11	Local de Nascimento 151	\N	\N	2024-07-11	151	151
27341	Pessoa152	Sobrenome152	2024-02-10	Local de Nascimento 152	\N	\N	2024-07-11	152	152
27343	Pessoa153	Sobrenome153	2024-02-09	Local de Nascimento 153	\N	\N	2024-07-11	153	153
27345	Pessoa154	Sobrenome154	2024-02-08	Local de Nascimento 154	\N	\N	2024-07-11	154	154
27347	Pessoa155	Sobrenome155	2024-02-07	Local de Nascimento 155	\N	\N	2024-07-11	155	155
27349	Pessoa156	Sobrenome156	2024-02-06	Local de Nascimento 156	\N	\N	2024-07-11	156	156
27351	Pessoa157	Sobrenome157	2024-02-05	Local de Nascimento 157	\N	\N	2024-07-11	157	157
27353	Pessoa158	Sobrenome158	2024-02-04	Local de Nascimento 158	\N	\N	2024-07-11	158	158
27355	Pessoa159	Sobrenome159	2024-02-03	Local de Nascimento 159	\N	\N	2024-07-11	159	159
27357	Pessoa160	Sobrenome160	2024-02-02	Local de Nascimento 160	\N	\N	2024-07-11	160	160
27359	Pessoa161	Sobrenome161	2024-02-01	Local de Nascimento 161	\N	\N	2024-07-11	161	161
27361	Pessoa162	Sobrenome162	2024-01-31	Local de Nascimento 162	\N	\N	2024-07-11	162	162
27363	Pessoa163	Sobrenome163	2024-01-30	Local de Nascimento 163	\N	\N	2024-07-11	163	163
27365	Pessoa164	Sobrenome164	2024-01-29	Local de Nascimento 164	\N	\N	2024-07-11	164	164
27367	Pessoa165	Sobrenome165	2024-01-28	Local de Nascimento 165	\N	\N	2024-07-11	165	165
27369	Pessoa166	Sobrenome166	2024-01-27	Local de Nascimento 166	\N	\N	2024-07-11	166	166
27371	Pessoa167	Sobrenome167	2024-01-26	Local de Nascimento 167	\N	\N	2024-07-11	167	167
27373	Pessoa168	Sobrenome168	2024-01-25	Local de Nascimento 168	\N	\N	2024-07-11	168	168
27375	Pessoa169	Sobrenome169	2024-01-24	Local de Nascimento 169	\N	\N	2024-07-11	169	169
27377	Pessoa170	Sobrenome170	2024-01-23	Local de Nascimento 170	\N	\N	2024-07-11	170	170
27379	Pessoa171	Sobrenome171	2024-01-22	Local de Nascimento 171	\N	\N	2024-07-11	171	171
27381	Pessoa172	Sobrenome172	2024-01-21	Local de Nascimento 172	\N	\N	2024-07-11	172	172
27383	Pessoa173	Sobrenome173	2024-01-20	Local de Nascimento 173	\N	\N	2024-07-11	173	173
27385	Pessoa174	Sobrenome174	2024-01-19	Local de Nascimento 174	\N	\N	2024-07-11	174	174
27387	Pessoa175	Sobrenome175	2024-01-18	Local de Nascimento 175	\N	\N	2024-07-11	175	175
27389	Pessoa176	Sobrenome176	2024-01-17	Local de Nascimento 176	\N	\N	2024-07-11	176	176
27391	Pessoa177	Sobrenome177	2024-01-16	Local de Nascimento 177	\N	\N	2024-07-11	177	177
27393	Pessoa178	Sobrenome178	2024-01-15	Local de Nascimento 178	\N	\N	2024-07-11	178	178
27395	Pessoa179	Sobrenome179	2024-01-14	Local de Nascimento 179	\N	\N	2024-07-11	179	179
27397	Pessoa180	Sobrenome180	2024-01-13	Local de Nascimento 180	\N	\N	2024-07-11	180	180
27399	Pessoa181	Sobrenome181	2024-01-12	Local de Nascimento 181	\N	\N	2024-07-11	181	181
27401	Pessoa182	Sobrenome182	2024-01-11	Local de Nascimento 182	\N	\N	2024-07-11	182	182
27403	Pessoa183	Sobrenome183	2024-01-10	Local de Nascimento 183	\N	\N	2024-07-11	183	183
27405	Pessoa184	Sobrenome184	2024-01-09	Local de Nascimento 184	\N	\N	2024-07-11	184	184
27407	Pessoa185	Sobrenome185	2024-01-08	Local de Nascimento 185	\N	\N	2024-07-11	185	185
27409	Pessoa186	Sobrenome186	2024-01-07	Local de Nascimento 186	\N	\N	2024-07-11	186	186
27411	Pessoa187	Sobrenome187	2024-01-06	Local de Nascimento 187	\N	\N	2024-07-11	187	187
27413	Pessoa188	Sobrenome188	2024-01-05	Local de Nascimento 188	\N	\N	2024-07-11	188	188
27415	Pessoa189	Sobrenome189	2024-01-04	Local de Nascimento 189	\N	\N	2024-07-11	189	189
27417	Pessoa190	Sobrenome190	2024-01-03	Local de Nascimento 190	\N	\N	2024-07-11	190	190
27419	Pessoa191	Sobrenome191	2024-01-02	Local de Nascimento 191	\N	\N	2024-07-11	191	191
27421	Pessoa192	Sobrenome192	2024-01-01	Local de Nascimento 192	\N	\N	2024-07-11	192	192
27423	Pessoa193	Sobrenome193	2023-12-31	Local de Nascimento 193	\N	\N	2024-07-11	193	193
27425	Pessoa194	Sobrenome194	2023-12-30	Local de Nascimento 194	\N	\N	2024-07-11	194	194
27427	Pessoa195	Sobrenome195	2023-12-29	Local de Nascimento 195	\N	\N	2024-07-11	195	195
27429	Pessoa196	Sobrenome196	2023-12-28	Local de Nascimento 196	\N	\N	2024-07-11	196	196
27431	Pessoa197	Sobrenome197	2023-12-27	Local de Nascimento 197	\N	\N	2024-07-11	197	197
27433	Pessoa198	Sobrenome198	2023-12-26	Local de Nascimento 198	\N	\N	2024-07-11	198	198
27435	Pessoa199	Sobrenome199	2023-12-25	Local de Nascimento 199	\N	\N	2024-07-11	199	199
27437	Pessoa200	Sobrenome200	2023-12-24	Local de Nascimento 200	\N	\N	2024-07-11	200	200
27439	Pessoa201	Sobrenome201	2023-12-23	Local de Nascimento 201	\N	\N	2024-07-11	201	201
27441	Pessoa202	Sobrenome202	2023-12-22	Local de Nascimento 202	\N	\N	2024-07-11	202	202
27443	Pessoa203	Sobrenome203	2023-12-21	Local de Nascimento 203	\N	\N	2024-07-11	203	203
27445	Pessoa204	Sobrenome204	2023-12-20	Local de Nascimento 204	\N	\N	2024-07-11	204	204
27447	Pessoa205	Sobrenome205	2023-12-19	Local de Nascimento 205	\N	\N	2024-07-11	205	205
27449	Pessoa206	Sobrenome206	2023-12-18	Local de Nascimento 206	\N	\N	2024-07-11	206	206
27451	Pessoa207	Sobrenome207	2023-12-17	Local de Nascimento 207	\N	\N	2024-07-11	207	207
27453	Pessoa208	Sobrenome208	2023-12-16	Local de Nascimento 208	\N	\N	2024-07-11	208	208
27455	Pessoa209	Sobrenome209	2023-12-15	Local de Nascimento 209	\N	\N	2024-07-11	209	209
27457	Pessoa210	Sobrenome210	2023-12-14	Local de Nascimento 210	\N	\N	2024-07-11	210	210
27459	Pessoa211	Sobrenome211	2023-12-13	Local de Nascimento 211	\N	\N	2024-07-11	211	211
27461	Pessoa212	Sobrenome212	2023-12-12	Local de Nascimento 212	\N	\N	2024-07-11	212	212
27463	Pessoa213	Sobrenome213	2023-12-11	Local de Nascimento 213	\N	\N	2024-07-11	213	213
27465	Pessoa214	Sobrenome214	2023-12-10	Local de Nascimento 214	\N	\N	2024-07-11	214	214
27467	Pessoa215	Sobrenome215	2023-12-09	Local de Nascimento 215	\N	\N	2024-07-11	215	215
27469	Pessoa216	Sobrenome216	2023-12-08	Local de Nascimento 216	\N	\N	2024-07-11	216	216
27471	Pessoa217	Sobrenome217	2023-12-07	Local de Nascimento 217	\N	\N	2024-07-11	217	217
27473	Pessoa218	Sobrenome218	2023-12-06	Local de Nascimento 218	\N	\N	2024-07-11	218	218
27475	Pessoa219	Sobrenome219	2023-12-05	Local de Nascimento 219	\N	\N	2024-07-11	219	219
27477	Pessoa220	Sobrenome220	2023-12-04	Local de Nascimento 220	\N	\N	2024-07-11	220	220
27479	Pessoa221	Sobrenome221	2023-12-03	Local de Nascimento 221	\N	\N	2024-07-11	221	221
27481	Pessoa222	Sobrenome222	2023-12-02	Local de Nascimento 222	\N	\N	2024-07-11	222	222
27483	Pessoa223	Sobrenome223	2023-12-01	Local de Nascimento 223	\N	\N	2024-07-11	223	223
27485	Pessoa224	Sobrenome224	2023-11-30	Local de Nascimento 224	\N	\N	2024-07-11	224	224
27487	Pessoa225	Sobrenome225	2023-11-29	Local de Nascimento 225	\N	\N	2024-07-11	225	225
27489	Pessoa226	Sobrenome226	2023-11-28	Local de Nascimento 226	\N	\N	2024-07-11	226	226
27491	Pessoa227	Sobrenome227	2023-11-27	Local de Nascimento 227	\N	\N	2024-07-11	227	227
27493	Pessoa228	Sobrenome228	2023-11-26	Local de Nascimento 228	\N	\N	2024-07-11	228	228
27495	Pessoa229	Sobrenome229	2023-11-25	Local de Nascimento 229	\N	\N	2024-07-11	229	229
27497	Pessoa230	Sobrenome230	2023-11-24	Local de Nascimento 230	\N	\N	2024-07-11	230	230
27499	Pessoa231	Sobrenome231	2023-11-23	Local de Nascimento 231	\N	\N	2024-07-11	231	231
27501	Pessoa232	Sobrenome232	2023-11-22	Local de Nascimento 232	\N	\N	2024-07-11	232	232
27503	Pessoa233	Sobrenome233	2023-11-21	Local de Nascimento 233	\N	\N	2024-07-11	233	233
27505	Pessoa234	Sobrenome234	2023-11-20	Local de Nascimento 234	\N	\N	2024-07-11	234	234
27507	Pessoa235	Sobrenome235	2023-11-19	Local de Nascimento 235	\N	\N	2024-07-11	235	235
27509	Pessoa236	Sobrenome236	2023-11-18	Local de Nascimento 236	\N	\N	2024-07-11	236	236
27511	Pessoa237	Sobrenome237	2023-11-17	Local de Nascimento 237	\N	\N	2024-07-11	237	237
27513	Pessoa238	Sobrenome238	2023-11-16	Local de Nascimento 238	\N	\N	2024-07-11	238	238
27515	Pessoa239	Sobrenome239	2023-11-15	Local de Nascimento 239	\N	\N	2024-07-11	239	239
27517	Pessoa240	Sobrenome240	2023-11-14	Local de Nascimento 240	\N	\N	2024-07-11	240	240
27519	Pessoa241	Sobrenome241	2023-11-13	Local de Nascimento 241	\N	\N	2024-07-11	241	241
27521	Pessoa242	Sobrenome242	2023-11-12	Local de Nascimento 242	\N	\N	2024-07-11	242	242
27523	Pessoa243	Sobrenome243	2023-11-11	Local de Nascimento 243	\N	\N	2024-07-11	243	243
27525	Pessoa244	Sobrenome244	2023-11-10	Local de Nascimento 244	\N	\N	2024-07-11	244	244
27527	Pessoa245	Sobrenome245	2023-11-09	Local de Nascimento 245	\N	\N	2024-07-11	245	245
27529	Pessoa246	Sobrenome246	2023-11-08	Local de Nascimento 246	\N	\N	2024-07-11	246	246
27531	Pessoa247	Sobrenome247	2023-11-07	Local de Nascimento 247	\N	\N	2024-07-11	247	247
27533	Pessoa248	Sobrenome248	2023-11-06	Local de Nascimento 248	\N	\N	2024-07-11	248	248
27535	Pessoa249	Sobrenome249	2023-11-05	Local de Nascimento 249	\N	\N	2024-07-11	249	249
27537	Pessoa250	Sobrenome250	2023-11-04	Local de Nascimento 250	\N	\N	2024-07-11	250	250
27539	Pessoa251	Sobrenome251	2023-11-03	Local de Nascimento 251	\N	\N	2024-07-11	251	251
27541	Pessoa252	Sobrenome252	2023-11-02	Local de Nascimento 252	\N	\N	2024-07-11	252	252
27543	Pessoa253	Sobrenome253	2023-11-01	Local de Nascimento 253	\N	\N	2024-07-11	253	253
27545	Pessoa254	Sobrenome254	2023-10-31	Local de Nascimento 254	\N	\N	2024-07-11	254	254
27547	Pessoa255	Sobrenome255	2023-10-30	Local de Nascimento 255	\N	\N	2024-07-11	255	255
27549	Pessoa256	Sobrenome256	2023-10-29	Local de Nascimento 256	\N	\N	2024-07-11	256	256
27551	Pessoa257	Sobrenome257	2023-10-28	Local de Nascimento 257	\N	\N	2024-07-11	257	257
27553	Pessoa258	Sobrenome258	2023-10-27	Local de Nascimento 258	\N	\N	2024-07-11	258	258
27555	Pessoa259	Sobrenome259	2023-10-26	Local de Nascimento 259	\N	\N	2024-07-11	259	259
27557	Pessoa260	Sobrenome260	2023-10-25	Local de Nascimento 260	\N	\N	2024-07-11	260	260
27559	Pessoa261	Sobrenome261	2023-10-24	Local de Nascimento 261	\N	\N	2024-07-11	261	261
27561	Pessoa262	Sobrenome262	2023-10-23	Local de Nascimento 262	\N	\N	2024-07-11	262	262
27563	Pessoa263	Sobrenome263	2023-10-22	Local de Nascimento 263	\N	\N	2024-07-11	263	263
27565	Pessoa264	Sobrenome264	2023-10-21	Local de Nascimento 264	\N	\N	2024-07-11	264	264
27567	Pessoa265	Sobrenome265	2023-10-20	Local de Nascimento 265	\N	\N	2024-07-11	265	265
27569	Pessoa266	Sobrenome266	2023-10-19	Local de Nascimento 266	\N	\N	2024-07-11	266	266
27571	Pessoa267	Sobrenome267	2023-10-18	Local de Nascimento 267	\N	\N	2024-07-11	267	267
27573	Pessoa268	Sobrenome268	2023-10-17	Local de Nascimento 268	\N	\N	2024-07-11	268	268
27575	Pessoa269	Sobrenome269	2023-10-16	Local de Nascimento 269	\N	\N	2024-07-11	269	269
27577	Pessoa270	Sobrenome270	2023-10-15	Local de Nascimento 270	\N	\N	2024-07-11	270	270
27579	Pessoa271	Sobrenome271	2023-10-14	Local de Nascimento 271	\N	\N	2024-07-11	271	271
27581	Pessoa272	Sobrenome272	2023-10-13	Local de Nascimento 272	\N	\N	2024-07-11	272	272
27583	Pessoa273	Sobrenome273	2023-10-12	Local de Nascimento 273	\N	\N	2024-07-11	273	273
27585	Pessoa274	Sobrenome274	2023-10-11	Local de Nascimento 274	\N	\N	2024-07-11	274	274
27587	Pessoa275	Sobrenome275	2023-10-10	Local de Nascimento 275	\N	\N	2024-07-11	275	275
27589	Pessoa276	Sobrenome276	2023-10-09	Local de Nascimento 276	\N	\N	2024-07-11	276	276
27591	Pessoa277	Sobrenome277	2023-10-08	Local de Nascimento 277	\N	\N	2024-07-11	277	277
27593	Pessoa278	Sobrenome278	2023-10-07	Local de Nascimento 278	\N	\N	2024-07-11	278	278
27595	Pessoa279	Sobrenome279	2023-10-06	Local de Nascimento 279	\N	\N	2024-07-11	279	279
27597	Pessoa280	Sobrenome280	2023-10-05	Local de Nascimento 280	\N	\N	2024-07-11	280	280
27599	Pessoa281	Sobrenome281	2023-10-04	Local de Nascimento 281	\N	\N	2024-07-11	281	281
27601	Pessoa282	Sobrenome282	2023-10-03	Local de Nascimento 282	\N	\N	2024-07-11	282	282
27603	Pessoa283	Sobrenome283	2023-10-02	Local de Nascimento 283	\N	\N	2024-07-11	283	283
27605	Pessoa284	Sobrenome284	2023-10-01	Local de Nascimento 284	\N	\N	2024-07-11	284	284
27607	Pessoa285	Sobrenome285	2023-09-30	Local de Nascimento 285	\N	\N	2024-07-11	285	285
27609	Pessoa286	Sobrenome286	2023-09-29	Local de Nascimento 286	\N	\N	2024-07-11	286	286
27611	Pessoa287	Sobrenome287	2023-09-28	Local de Nascimento 287	\N	\N	2024-07-11	287	287
27613	Pessoa288	Sobrenome288	2023-09-27	Local de Nascimento 288	\N	\N	2024-07-11	288	288
27615	Pessoa289	Sobrenome289	2023-09-26	Local de Nascimento 289	\N	\N	2024-07-11	289	289
27617	Pessoa290	Sobrenome290	2023-09-25	Local de Nascimento 290	\N	\N	2024-07-11	290	290
27619	Pessoa291	Sobrenome291	2023-09-24	Local de Nascimento 291	\N	\N	2024-07-11	291	291
27621	Pessoa292	Sobrenome292	2023-09-23	Local de Nascimento 292	\N	\N	2024-07-11	292	292
27623	Pessoa293	Sobrenome293	2023-09-22	Local de Nascimento 293	\N	\N	2024-07-11	293	293
27625	Pessoa294	Sobrenome294	2023-09-21	Local de Nascimento 294	\N	\N	2024-07-11	294	294
27627	Pessoa295	Sobrenome295	2023-09-20	Local de Nascimento 295	\N	\N	2024-07-11	295	295
27629	Pessoa296	Sobrenome296	2023-09-19	Local de Nascimento 296	\N	\N	2024-07-11	296	296
27631	Pessoa297	Sobrenome297	2023-09-18	Local de Nascimento 297	\N	\N	2024-07-11	297	297
27633	Pessoa298	Sobrenome298	2023-09-17	Local de Nascimento 298	\N	\N	2024-07-11	298	298
27635	Pessoa299	Sobrenome299	2023-09-16	Local de Nascimento 299	\N	\N	2024-07-11	299	299
27637	Pessoa300	Sobrenome300	2023-09-15	Local de Nascimento 300	\N	\N	2024-07-11	300	300
27639	Pessoa301	Sobrenome301	2023-09-14	Local de Nascimento 301	\N	\N	2024-07-11	301	301
27641	Pessoa302	Sobrenome302	2023-09-13	Local de Nascimento 302	\N	\N	2024-07-11	302	302
27643	Pessoa303	Sobrenome303	2023-09-12	Local de Nascimento 303	\N	\N	2024-07-11	303	303
27645	Pessoa304	Sobrenome304	2023-09-11	Local de Nascimento 304	\N	\N	2024-07-11	304	304
27647	Pessoa305	Sobrenome305	2023-09-10	Local de Nascimento 305	\N	\N	2024-07-11	305	305
27649	Pessoa306	Sobrenome306	2023-09-09	Local de Nascimento 306	\N	\N	2024-07-11	306	306
27651	Pessoa307	Sobrenome307	2023-09-08	Local de Nascimento 307	\N	\N	2024-07-11	307	307
27653	Pessoa308	Sobrenome308	2023-09-07	Local de Nascimento 308	\N	\N	2024-07-11	308	308
27655	Pessoa309	Sobrenome309	2023-09-06	Local de Nascimento 309	\N	\N	2024-07-11	309	309
27657	Pessoa310	Sobrenome310	2023-09-05	Local de Nascimento 310	\N	\N	2024-07-11	310	310
27659	Pessoa311	Sobrenome311	2023-09-04	Local de Nascimento 311	\N	\N	2024-07-11	311	311
27661	Pessoa312	Sobrenome312	2023-09-03	Local de Nascimento 312	\N	\N	2024-07-11	312	312
27663	Pessoa313	Sobrenome313	2023-09-02	Local de Nascimento 313	\N	\N	2024-07-11	313	313
27665	Pessoa314	Sobrenome314	2023-09-01	Local de Nascimento 314	\N	\N	2024-07-11	314	314
27667	Pessoa315	Sobrenome315	2023-08-31	Local de Nascimento 315	\N	\N	2024-07-11	315	315
27669	Pessoa316	Sobrenome316	2023-08-30	Local de Nascimento 316	\N	\N	2024-07-11	316	316
27671	Pessoa317	Sobrenome317	2023-08-29	Local de Nascimento 317	\N	\N	2024-07-11	317	317
27673	Pessoa318	Sobrenome318	2023-08-28	Local de Nascimento 318	\N	\N	2024-07-11	318	318
27675	Pessoa319	Sobrenome319	2023-08-27	Local de Nascimento 319	\N	\N	2024-07-11	319	319
27677	Pessoa320	Sobrenome320	2023-08-26	Local de Nascimento 320	\N	\N	2024-07-11	320	320
27679	Pessoa321	Sobrenome321	2023-08-25	Local de Nascimento 321	\N	\N	2024-07-11	321	321
27681	Pessoa322	Sobrenome322	2023-08-24	Local de Nascimento 322	\N	\N	2024-07-11	322	322
27683	Pessoa323	Sobrenome323	2023-08-23	Local de Nascimento 323	\N	\N	2024-07-11	323	323
27685	Pessoa324	Sobrenome324	2023-08-22	Local de Nascimento 324	\N	\N	2024-07-11	324	324
27687	Pessoa325	Sobrenome325	2023-08-21	Local de Nascimento 325	\N	\N	2024-07-11	325	325
27689	Pessoa326	Sobrenome326	2023-08-20	Local de Nascimento 326	\N	\N	2024-07-11	326	326
27691	Pessoa327	Sobrenome327	2023-08-19	Local de Nascimento 327	\N	\N	2024-07-11	327	327
27693	Pessoa328	Sobrenome328	2023-08-18	Local de Nascimento 328	\N	\N	2024-07-11	328	328
27695	Pessoa329	Sobrenome329	2023-08-17	Local de Nascimento 329	\N	\N	2024-07-11	329	329
27697	Pessoa330	Sobrenome330	2023-08-16	Local de Nascimento 330	\N	\N	2024-07-11	330	330
27699	Pessoa331	Sobrenome331	2023-08-15	Local de Nascimento 331	\N	\N	2024-07-11	331	331
27701	Pessoa332	Sobrenome332	2023-08-14	Local de Nascimento 332	\N	\N	2024-07-11	332	332
27703	Pessoa333	Sobrenome333	2023-08-13	Local de Nascimento 333	\N	\N	2024-07-11	333	333
27705	Pessoa334	Sobrenome334	2023-08-12	Local de Nascimento 334	\N	\N	2024-07-11	334	334
27707	Pessoa335	Sobrenome335	2023-08-11	Local de Nascimento 335	\N	\N	2024-07-11	335	335
27709	Pessoa336	Sobrenome336	2023-08-10	Local de Nascimento 336	\N	\N	2024-07-11	336	336
27711	Pessoa337	Sobrenome337	2023-08-09	Local de Nascimento 337	\N	\N	2024-07-11	337	337
27713	Pessoa338	Sobrenome338	2023-08-08	Local de Nascimento 338	\N	\N	2024-07-11	338	338
27715	Pessoa339	Sobrenome339	2023-08-07	Local de Nascimento 339	\N	\N	2024-07-11	339	339
27717	Pessoa340	Sobrenome340	2023-08-06	Local de Nascimento 340	\N	\N	2024-07-11	340	340
27719	Pessoa341	Sobrenome341	2023-08-05	Local de Nascimento 341	\N	\N	2024-07-11	341	341
27721	Pessoa342	Sobrenome342	2023-08-04	Local de Nascimento 342	\N	\N	2024-07-11	342	342
27723	Pessoa343	Sobrenome343	2023-08-03	Local de Nascimento 343	\N	\N	2024-07-11	343	343
27725	Pessoa344	Sobrenome344	2023-08-02	Local de Nascimento 344	\N	\N	2024-07-11	344	344
27727	Pessoa345	Sobrenome345	2023-08-01	Local de Nascimento 345	\N	\N	2024-07-11	345	345
27729	Pessoa346	Sobrenome346	2023-07-31	Local de Nascimento 346	\N	\N	2024-07-11	346	346
27731	Pessoa347	Sobrenome347	2023-07-30	Local de Nascimento 347	\N	\N	2024-07-11	347	347
27733	Pessoa348	Sobrenome348	2023-07-29	Local de Nascimento 348	\N	\N	2024-07-11	348	348
27735	Pessoa349	Sobrenome349	2023-07-28	Local de Nascimento 349	\N	\N	2024-07-11	349	349
27737	Pessoa350	Sobrenome350	2023-07-27	Local de Nascimento 350	\N	\N	2024-07-11	350	350
27739	Pessoa351	Sobrenome351	2023-07-26	Local de Nascimento 351	\N	\N	2024-07-11	351	351
27741	Pessoa352	Sobrenome352	2023-07-25	Local de Nascimento 352	\N	\N	2024-07-11	352	352
27743	Pessoa353	Sobrenome353	2023-07-24	Local de Nascimento 353	\N	\N	2024-07-11	353	353
27745	Pessoa354	Sobrenome354	2023-07-23	Local de Nascimento 354	\N	\N	2024-07-11	354	354
27747	Pessoa355	Sobrenome355	2023-07-22	Local de Nascimento 355	\N	\N	2024-07-11	355	355
27749	Pessoa356	Sobrenome356	2023-07-21	Local de Nascimento 356	\N	\N	2024-07-11	356	356
27751	Pessoa357	Sobrenome357	2023-07-20	Local de Nascimento 357	\N	\N	2024-07-11	357	357
27753	Pessoa358	Sobrenome358	2023-07-19	Local de Nascimento 358	\N	\N	2024-07-11	358	358
27755	Pessoa359	Sobrenome359	2023-07-18	Local de Nascimento 359	\N	\N	2024-07-11	359	359
27757	Pessoa360	Sobrenome360	2023-07-17	Local de Nascimento 360	\N	\N	2024-07-11	360	360
27759	Pessoa361	Sobrenome361	2023-07-16	Local de Nascimento 361	\N	\N	2024-07-11	361	361
27761	Pessoa362	Sobrenome362	2023-07-15	Local de Nascimento 362	\N	\N	2024-07-11	362	362
27763	Pessoa363	Sobrenome363	2023-07-14	Local de Nascimento 363	\N	\N	2024-07-11	363	363
27765	Pessoa364	Sobrenome364	2023-07-13	Local de Nascimento 364	\N	\N	2024-07-11	364	364
27767	Pessoa365	Sobrenome365	2023-07-12	Local de Nascimento 365	\N	\N	2024-07-11	365	365
27769	Pessoa366	Sobrenome366	2023-07-11	Local de Nascimento 366	\N	\N	2024-07-11	366	366
27771	Pessoa367	Sobrenome367	2023-07-10	Local de Nascimento 367	\N	\N	2024-07-11	367	367
27773	Pessoa368	Sobrenome368	2023-07-09	Local de Nascimento 368	\N	\N	2024-07-11	368	368
27775	Pessoa369	Sobrenome369	2023-07-08	Local de Nascimento 369	\N	\N	2024-07-11	369	369
27777	Pessoa370	Sobrenome370	2023-07-07	Local de Nascimento 370	\N	\N	2024-07-11	370	370
27779	Pessoa371	Sobrenome371	2023-07-06	Local de Nascimento 371	\N	\N	2024-07-11	371	371
27781	Pessoa372	Sobrenome372	2023-07-05	Local de Nascimento 372	\N	\N	2024-07-11	372	372
27783	Pessoa373	Sobrenome373	2023-07-04	Local de Nascimento 373	\N	\N	2024-07-11	373	373
27785	Pessoa374	Sobrenome374	2023-07-03	Local de Nascimento 374	\N	\N	2024-07-11	374	374
27787	Pessoa375	Sobrenome375	2023-07-02	Local de Nascimento 375	\N	\N	2024-07-11	375	375
27789	Pessoa376	Sobrenome376	2023-07-01	Local de Nascimento 376	\N	\N	2024-07-11	376	376
27791	Pessoa377	Sobrenome377	2023-06-30	Local de Nascimento 377	\N	\N	2024-07-11	377	377
27793	Pessoa378	Sobrenome378	2023-06-29	Local de Nascimento 378	\N	\N	2024-07-11	378	378
27795	Pessoa379	Sobrenome379	2023-06-28	Local de Nascimento 379	\N	\N	2024-07-11	379	379
27797	Pessoa380	Sobrenome380	2023-06-27	Local de Nascimento 380	\N	\N	2024-07-11	380	380
27799	Pessoa381	Sobrenome381	2023-06-26	Local de Nascimento 381	\N	\N	2024-07-11	381	381
27801	Pessoa382	Sobrenome382	2023-06-25	Local de Nascimento 382	\N	\N	2024-07-11	382	382
27803	Pessoa383	Sobrenome383	2023-06-24	Local de Nascimento 383	\N	\N	2024-07-11	383	383
27805	Pessoa384	Sobrenome384	2023-06-23	Local de Nascimento 384	\N	\N	2024-07-11	384	384
27807	Pessoa385	Sobrenome385	2023-06-22	Local de Nascimento 385	\N	\N	2024-07-11	385	385
27809	Pessoa386	Sobrenome386	2023-06-21	Local de Nascimento 386	\N	\N	2024-07-11	386	386
27811	Pessoa387	Sobrenome387	2023-06-20	Local de Nascimento 387	\N	\N	2024-07-11	387	387
27813	Pessoa388	Sobrenome388	2023-06-19	Local de Nascimento 388	\N	\N	2024-07-11	388	388
27815	Pessoa389	Sobrenome389	2023-06-18	Local de Nascimento 389	\N	\N	2024-07-11	389	389
27817	Pessoa390	Sobrenome390	2023-06-17	Local de Nascimento 390	\N	\N	2024-07-11	390	390
27819	Pessoa391	Sobrenome391	2023-06-16	Local de Nascimento 391	\N	\N	2024-07-11	391	391
27821	Pessoa392	Sobrenome392	2023-06-15	Local de Nascimento 392	\N	\N	2024-07-11	392	392
27823	Pessoa393	Sobrenome393	2023-06-14	Local de Nascimento 393	\N	\N	2024-07-11	393	393
27825	Pessoa394	Sobrenome394	2023-06-13	Local de Nascimento 394	\N	\N	2024-07-11	394	394
27827	Pessoa395	Sobrenome395	2023-06-12	Local de Nascimento 395	\N	\N	2024-07-11	395	395
27829	Pessoa396	Sobrenome396	2023-06-11	Local de Nascimento 396	\N	\N	2024-07-11	396	396
27831	Pessoa397	Sobrenome397	2023-06-10	Local de Nascimento 397	\N	\N	2024-07-11	397	397
27833	Pessoa398	Sobrenome398	2023-06-09	Local de Nascimento 398	\N	\N	2024-07-11	398	398
27835	Pessoa399	Sobrenome399	2023-06-08	Local de Nascimento 399	\N	\N	2024-07-11	399	399
27837	Pessoa400	Sobrenome400	2023-06-07	Local de Nascimento 400	\N	\N	2024-07-11	400	400
27839	Pessoa401	Sobrenome401	2023-06-06	Local de Nascimento 401	\N	\N	2024-07-11	401	401
27841	Pessoa402	Sobrenome402	2023-06-05	Local de Nascimento 402	\N	\N	2024-07-11	402	402
27843	Pessoa403	Sobrenome403	2023-06-04	Local de Nascimento 403	\N	\N	2024-07-11	403	403
27845	Pessoa404	Sobrenome404	2023-06-03	Local de Nascimento 404	\N	\N	2024-07-11	404	404
27847	Pessoa405	Sobrenome405	2023-06-02	Local de Nascimento 405	\N	\N	2024-07-11	405	405
27849	Pessoa406	Sobrenome406	2023-06-01	Local de Nascimento 406	\N	\N	2024-07-11	406	406
27851	Pessoa407	Sobrenome407	2023-05-31	Local de Nascimento 407	\N	\N	2024-07-11	407	407
27853	Pessoa408	Sobrenome408	2023-05-30	Local de Nascimento 408	\N	\N	2024-07-11	408	408
27855	Pessoa409	Sobrenome409	2023-05-29	Local de Nascimento 409	\N	\N	2024-07-11	409	409
27857	Pessoa410	Sobrenome410	2023-05-28	Local de Nascimento 410	\N	\N	2024-07-11	410	410
27859	Pessoa411	Sobrenome411	2023-05-27	Local de Nascimento 411	\N	\N	2024-07-11	411	411
27861	Pessoa412	Sobrenome412	2023-05-26	Local de Nascimento 412	\N	\N	2024-07-11	412	412
27863	Pessoa413	Sobrenome413	2023-05-25	Local de Nascimento 413	\N	\N	2024-07-11	413	413
27865	Pessoa414	Sobrenome414	2023-05-24	Local de Nascimento 414	\N	\N	2024-07-11	414	414
27867	Pessoa415	Sobrenome415	2023-05-23	Local de Nascimento 415	\N	\N	2024-07-11	415	415
27869	Pessoa416	Sobrenome416	2023-05-22	Local de Nascimento 416	\N	\N	2024-07-11	416	416
27871	Pessoa417	Sobrenome417	2023-05-21	Local de Nascimento 417	\N	\N	2024-07-11	417	417
27873	Pessoa418	Sobrenome418	2023-05-20	Local de Nascimento 418	\N	\N	2024-07-11	418	418
27875	Pessoa419	Sobrenome419	2023-05-19	Local de Nascimento 419	\N	\N	2024-07-11	419	419
27877	Pessoa420	Sobrenome420	2023-05-18	Local de Nascimento 420	\N	\N	2024-07-11	420	420
27879	Pessoa421	Sobrenome421	2023-05-17	Local de Nascimento 421	\N	\N	2024-07-11	421	421
27881	Pessoa422	Sobrenome422	2023-05-16	Local de Nascimento 422	\N	\N	2024-07-11	422	422
27883	Pessoa423	Sobrenome423	2023-05-15	Local de Nascimento 423	\N	\N	2024-07-11	423	423
27885	Pessoa424	Sobrenome424	2023-05-14	Local de Nascimento 424	\N	\N	2024-07-11	424	424
27887	Pessoa425	Sobrenome425	2023-05-13	Local de Nascimento 425	\N	\N	2024-07-11	425	425
27889	Pessoa426	Sobrenome426	2023-05-12	Local de Nascimento 426	\N	\N	2024-07-11	426	426
27891	Pessoa427	Sobrenome427	2023-05-11	Local de Nascimento 427	\N	\N	2024-07-11	427	427
27893	Pessoa428	Sobrenome428	2023-05-10	Local de Nascimento 428	\N	\N	2024-07-11	428	428
27895	Pessoa429	Sobrenome429	2023-05-09	Local de Nascimento 429	\N	\N	2024-07-11	429	429
27897	Pessoa430	Sobrenome430	2023-05-08	Local de Nascimento 430	\N	\N	2024-07-11	430	430
27899	Pessoa431	Sobrenome431	2023-05-07	Local de Nascimento 431	\N	\N	2024-07-11	431	431
27901	Pessoa432	Sobrenome432	2023-05-06	Local de Nascimento 432	\N	\N	2024-07-11	432	432
27903	Pessoa433	Sobrenome433	2023-05-05	Local de Nascimento 433	\N	\N	2024-07-11	433	433
27905	Pessoa434	Sobrenome434	2023-05-04	Local de Nascimento 434	\N	\N	2024-07-11	434	434
27907	Pessoa435	Sobrenome435	2023-05-03	Local de Nascimento 435	\N	\N	2024-07-11	435	435
27909	Pessoa436	Sobrenome436	2023-05-02	Local de Nascimento 436	\N	\N	2024-07-11	436	436
27911	Pessoa437	Sobrenome437	2023-05-01	Local de Nascimento 437	\N	\N	2024-07-11	437	437
27913	Pessoa438	Sobrenome438	2023-04-30	Local de Nascimento 438	\N	\N	2024-07-11	438	438
27915	Pessoa439	Sobrenome439	2023-04-29	Local de Nascimento 439	\N	\N	2024-07-11	439	439
27917	Pessoa440	Sobrenome440	2023-04-28	Local de Nascimento 440	\N	\N	2024-07-11	440	440
27919	Pessoa441	Sobrenome441	2023-04-27	Local de Nascimento 441	\N	\N	2024-07-11	441	441
27921	Pessoa442	Sobrenome442	2023-04-26	Local de Nascimento 442	\N	\N	2024-07-11	442	442
27923	Pessoa443	Sobrenome443	2023-04-25	Local de Nascimento 443	\N	\N	2024-07-11	443	443
27925	Pessoa444	Sobrenome444	2023-04-24	Local de Nascimento 444	\N	\N	2024-07-11	444	444
27927	Pessoa445	Sobrenome445	2023-04-23	Local de Nascimento 445	\N	\N	2024-07-11	445	445
27929	Pessoa446	Sobrenome446	2023-04-22	Local de Nascimento 446	\N	\N	2024-07-11	446	446
27931	Pessoa447	Sobrenome447	2023-04-21	Local de Nascimento 447	\N	\N	2024-07-11	447	447
27933	Pessoa448	Sobrenome448	2023-04-20	Local de Nascimento 448	\N	\N	2024-07-11	448	448
27935	Pessoa449	Sobrenome449	2023-04-19	Local de Nascimento 449	\N	\N	2024-07-11	449	449
27937	Pessoa450	Sobrenome450	2023-04-18	Local de Nascimento 450	\N	\N	2024-07-11	450	450
27939	Pessoa451	Sobrenome451	2023-04-17	Local de Nascimento 451	\N	\N	2024-07-11	451	451
27941	Pessoa452	Sobrenome452	2023-04-16	Local de Nascimento 452	\N	\N	2024-07-11	452	452
27943	Pessoa453	Sobrenome453	2023-04-15	Local de Nascimento 453	\N	\N	2024-07-11	453	453
27945	Pessoa454	Sobrenome454	2023-04-14	Local de Nascimento 454	\N	\N	2024-07-11	454	454
27947	Pessoa455	Sobrenome455	2023-04-13	Local de Nascimento 455	\N	\N	2024-07-11	455	455
27949	Pessoa456	Sobrenome456	2023-04-12	Local de Nascimento 456	\N	\N	2024-07-11	456	456
27951	Pessoa457	Sobrenome457	2023-04-11	Local de Nascimento 457	\N	\N	2024-07-11	457	457
27953	Pessoa458	Sobrenome458	2023-04-10	Local de Nascimento 458	\N	\N	2024-07-11	458	458
27955	Pessoa459	Sobrenome459	2023-04-09	Local de Nascimento 459	\N	\N	2024-07-11	459	459
27957	Pessoa460	Sobrenome460	2023-04-08	Local de Nascimento 460	\N	\N	2024-07-11	460	460
27959	Pessoa461	Sobrenome461	2023-04-07	Local de Nascimento 461	\N	\N	2024-07-11	461	461
27961	Pessoa462	Sobrenome462	2023-04-06	Local de Nascimento 462	\N	\N	2024-07-11	462	462
27963	Pessoa463	Sobrenome463	2023-04-05	Local de Nascimento 463	\N	\N	2024-07-11	463	463
27965	Pessoa464	Sobrenome464	2023-04-04	Local de Nascimento 464	\N	\N	2024-07-11	464	464
27967	Pessoa465	Sobrenome465	2023-04-03	Local de Nascimento 465	\N	\N	2024-07-11	465	465
27969	Pessoa466	Sobrenome466	2023-04-02	Local de Nascimento 466	\N	\N	2024-07-11	466	466
27971	Pessoa467	Sobrenome467	2023-04-01	Local de Nascimento 467	\N	\N	2024-07-11	467	467
27973	Pessoa468	Sobrenome468	2023-03-31	Local de Nascimento 468	\N	\N	2024-07-11	468	468
27975	Pessoa469	Sobrenome469	2023-03-30	Local de Nascimento 469	\N	\N	2024-07-11	469	469
27977	Pessoa470	Sobrenome470	2023-03-29	Local de Nascimento 470	\N	\N	2024-07-11	470	470
27979	Pessoa471	Sobrenome471	2023-03-28	Local de Nascimento 471	\N	\N	2024-07-11	471	471
27981	Pessoa472	Sobrenome472	2023-03-27	Local de Nascimento 472	\N	\N	2024-07-11	472	472
27983	Pessoa473	Sobrenome473	2023-03-26	Local de Nascimento 473	\N	\N	2024-07-11	473	473
27985	Pessoa474	Sobrenome474	2023-03-25	Local de Nascimento 474	\N	\N	2024-07-11	474	474
27987	Pessoa475	Sobrenome475	2023-03-24	Local de Nascimento 475	\N	\N	2024-07-11	475	475
27989	Pessoa476	Sobrenome476	2023-03-23	Local de Nascimento 476	\N	\N	2024-07-11	476	476
27991	Pessoa477	Sobrenome477	2023-03-22	Local de Nascimento 477	\N	\N	2024-07-11	477	477
27993	Pessoa478	Sobrenome478	2023-03-21	Local de Nascimento 478	\N	\N	2024-07-11	478	478
27995	Pessoa479	Sobrenome479	2023-03-20	Local de Nascimento 479	\N	\N	2024-07-11	479	479
27997	Pessoa480	Sobrenome480	2023-03-19	Local de Nascimento 480	\N	\N	2024-07-11	480	480
27999	Pessoa481	Sobrenome481	2023-03-18	Local de Nascimento 481	\N	\N	2024-07-11	481	481
28001	Pessoa482	Sobrenome482	2023-03-17	Local de Nascimento 482	\N	\N	2024-07-11	482	482
28003	Pessoa483	Sobrenome483	2023-03-16	Local de Nascimento 483	\N	\N	2024-07-11	483	483
28005	Pessoa484	Sobrenome484	2023-03-15	Local de Nascimento 484	\N	\N	2024-07-11	484	484
28007	Pessoa485	Sobrenome485	2023-03-14	Local de Nascimento 485	\N	\N	2024-07-11	485	485
28009	Pessoa486	Sobrenome486	2023-03-13	Local de Nascimento 486	\N	\N	2024-07-11	486	486
28011	Pessoa487	Sobrenome487	2023-03-12	Local de Nascimento 487	\N	\N	2024-07-11	487	487
28013	Pessoa488	Sobrenome488	2023-03-11	Local de Nascimento 488	\N	\N	2024-07-11	488	488
28015	Pessoa489	Sobrenome489	2023-03-10	Local de Nascimento 489	\N	\N	2024-07-11	489	489
28017	Pessoa490	Sobrenome490	2023-03-09	Local de Nascimento 490	\N	\N	2024-07-11	490	490
28019	Pessoa491	Sobrenome491	2023-03-08	Local de Nascimento 491	\N	\N	2024-07-11	491	491
28021	Pessoa492	Sobrenome492	2023-03-07	Local de Nascimento 492	\N	\N	2024-07-11	492	492
28023	Pessoa493	Sobrenome493	2023-03-06	Local de Nascimento 493	\N	\N	2024-07-11	493	493
28025	Pessoa494	Sobrenome494	2023-03-05	Local de Nascimento 494	\N	\N	2024-07-11	494	494
28027	Pessoa495	Sobrenome495	2023-03-04	Local de Nascimento 495	\N	\N	2024-07-11	495	495
28029	Pessoa496	Sobrenome496	2023-03-03	Local de Nascimento 496	\N	\N	2024-07-11	496	496
28031	Pessoa497	Sobrenome497	2023-03-02	Local de Nascimento 497	\N	\N	2024-07-11	497	497
28033	Pessoa498	Sobrenome498	2023-03-01	Local de Nascimento 498	\N	\N	2024-07-11	498	498
28035	Pessoa499	Sobrenome499	2023-02-28	Local de Nascimento 499	\N	\N	2024-07-11	499	499
28037	Pessoa500	Sobrenome500	2023-02-27	Local de Nascimento 500	\N	\N	2024-07-11	500	500
28039	giovanni	silva	2003-08-02	teste	2024-07-12	2024-07-12	2024-07-13	1	1
28043	teste	teste	2024-07-25		\N	\N	\N	\N	\N
28045	test	asdasdasdasd	\N		\N	\N	\N	\N	\N
26039	Pessoa1	Sobrenome1	2024-07-10	Local de Nascimento 1	\N	\N	2024-07-11	1	1
26041	Pessoa2	Sobrenome2	2024-07-09	Local de Nascimento 2	\N	\N	2024-07-11	2	2
26043	Pessoa3	Sobrenome3	2024-07-08	Local de Nascimento 3	\N	\N	2024-07-11	3	3
26045	Pessoa4	Sobrenome4	2024-07-07	Local de Nascimento 4	\N	\N	2024-07-11	4	4
26047	Pessoa5	Sobrenome5	2024-07-06	Local de Nascimento 5	\N	\N	2024-07-11	5	5
26049	Pessoa6	Sobrenome6	2024-07-05	Local de Nascimento 6	\N	\N	2024-07-11	6	6
26051	Pessoa7	Sobrenome7	2024-07-04	Local de Nascimento 7	\N	\N	2024-07-11	7	7
26053	Pessoa8	Sobrenome8	2024-07-03	Local de Nascimento 8	\N	\N	2024-07-11	8	8
26055	Pessoa9	Sobrenome9	2024-07-02	Local de Nascimento 9	\N	\N	2024-07-11	9	9
26057	Pessoa10	Sobrenome10	2024-07-01	Local de Nascimento 10	\N	\N	2024-07-11	10	10
26059	Pessoa11	Sobrenome11	2024-06-30	Local de Nascimento 11	\N	\N	2024-07-11	11	11
26061	Pessoa12	Sobrenome12	2024-06-29	Local de Nascimento 12	\N	\N	2024-07-11	12	12
26063	Pessoa13	Sobrenome13	2024-06-28	Local de Nascimento 13	\N	\N	2024-07-11	13	13
26065	Pessoa14	Sobrenome14	2024-06-27	Local de Nascimento 14	\N	\N	2024-07-11	14	14
26067	Pessoa15	Sobrenome15	2024-06-26	Local de Nascimento 15	\N	\N	2024-07-11	15	15
26069	Pessoa16	Sobrenome16	2024-06-25	Local de Nascimento 16	\N	\N	2024-07-11	16	16
26071	Pessoa17	Sobrenome17	2024-06-24	Local de Nascimento 17	\N	\N	2024-07-11	17	17
26073	Pessoa18	Sobrenome18	2024-06-23	Local de Nascimento 18	\N	\N	2024-07-11	18	18
26075	Pessoa19	Sobrenome19	2024-06-22	Local de Nascimento 19	\N	\N	2024-07-11	19	19
26077	Pessoa20	Sobrenome20	2024-06-21	Local de Nascimento 20	\N	\N	2024-07-11	20	20
26079	Pessoa21	Sobrenome21	2024-06-20	Local de Nascimento 21	\N	\N	2024-07-11	21	21
26081	Pessoa22	Sobrenome22	2024-06-19	Local de Nascimento 22	\N	\N	2024-07-11	22	22
26083	Pessoa23	Sobrenome23	2024-06-18	Local de Nascimento 23	\N	\N	2024-07-11	23	23
26085	Pessoa24	Sobrenome24	2024-06-17	Local de Nascimento 24	\N	\N	2024-07-11	24	24
26087	Pessoa25	Sobrenome25	2024-06-16	Local de Nascimento 25	\N	\N	2024-07-11	25	25
26089	Pessoa26	Sobrenome26	2024-06-15	Local de Nascimento 26	\N	\N	2024-07-11	26	26
26091	Pessoa27	Sobrenome27	2024-06-14	Local de Nascimento 27	\N	\N	2024-07-11	27	27
26093	Pessoa28	Sobrenome28	2024-06-13	Local de Nascimento 28	\N	\N	2024-07-11	28	28
26095	Pessoa29	Sobrenome29	2024-06-12	Local de Nascimento 29	\N	\N	2024-07-11	29	29
26097	Pessoa30	Sobrenome30	2024-06-11	Local de Nascimento 30	\N	\N	2024-07-11	30	30
26099	Pessoa31	Sobrenome31	2024-06-10	Local de Nascimento 31	\N	\N	2024-07-11	31	31
26101	Pessoa32	Sobrenome32	2024-06-09	Local de Nascimento 32	\N	\N	2024-07-11	32	32
26103	Pessoa33	Sobrenome33	2024-06-08	Local de Nascimento 33	\N	\N	2024-07-11	33	33
26105	Pessoa34	Sobrenome34	2024-06-07	Local de Nascimento 34	\N	\N	2024-07-11	34	34
26107	Pessoa35	Sobrenome35	2024-06-06	Local de Nascimento 35	\N	\N	2024-07-11	35	35
26109	Pessoa36	Sobrenome36	2024-06-05	Local de Nascimento 36	\N	\N	2024-07-11	36	36
26111	Pessoa37	Sobrenome37	2024-06-04	Local de Nascimento 37	\N	\N	2024-07-11	37	37
26113	Pessoa38	Sobrenome38	2024-06-03	Local de Nascimento 38	\N	\N	2024-07-11	38	38
26115	Pessoa39	Sobrenome39	2024-06-02	Local de Nascimento 39	\N	\N	2024-07-11	39	39
26117	Pessoa40	Sobrenome40	2024-06-01	Local de Nascimento 40	\N	\N	2024-07-11	40	40
26119	Pessoa41	Sobrenome41	2024-05-31	Local de Nascimento 41	\N	\N	2024-07-11	41	41
26121	Pessoa42	Sobrenome42	2024-05-30	Local de Nascimento 42	\N	\N	2024-07-11	42	42
26123	Pessoa43	Sobrenome43	2024-05-29	Local de Nascimento 43	\N	\N	2024-07-11	43	43
26125	Pessoa44	Sobrenome44	2024-05-28	Local de Nascimento 44	\N	\N	2024-07-11	44	44
26127	Pessoa45	Sobrenome45	2024-05-27	Local de Nascimento 45	\N	\N	2024-07-11	45	45
26129	Pessoa46	Sobrenome46	2024-05-26	Local de Nascimento 46	\N	\N	2024-07-11	46	46
26131	Pessoa47	Sobrenome47	2024-05-25	Local de Nascimento 47	\N	\N	2024-07-11	47	47
26133	Pessoa48	Sobrenome48	2024-05-24	Local de Nascimento 48	\N	\N	2024-07-11	48	48
26135	Pessoa49	Sobrenome49	2024-05-23	Local de Nascimento 49	\N	\N	2024-07-11	49	49
26137	Pessoa50	Sobrenome50	2024-05-22	Local de Nascimento 50	\N	\N	2024-07-11	50	50
26139	Pessoa51	Sobrenome51	2024-05-21	Local de Nascimento 51	\N	\N	2024-07-11	51	51
26141	Pessoa52	Sobrenome52	2024-05-20	Local de Nascimento 52	\N	\N	2024-07-11	52	52
26143	Pessoa53	Sobrenome53	2024-05-19	Local de Nascimento 53	\N	\N	2024-07-11	53	53
26145	Pessoa54	Sobrenome54	2024-05-18	Local de Nascimento 54	\N	\N	2024-07-11	54	54
26147	Pessoa55	Sobrenome55	2024-05-17	Local de Nascimento 55	\N	\N	2024-07-11	55	55
26149	Pessoa56	Sobrenome56	2024-05-16	Local de Nascimento 56	\N	\N	2024-07-11	56	56
26151	Pessoa57	Sobrenome57	2024-05-15	Local de Nascimento 57	\N	\N	2024-07-11	57	57
26153	Pessoa58	Sobrenome58	2024-05-14	Local de Nascimento 58	\N	\N	2024-07-11	58	58
26155	Pessoa59	Sobrenome59	2024-05-13	Local de Nascimento 59	\N	\N	2024-07-11	59	59
26157	Pessoa60	Sobrenome60	2024-05-12	Local de Nascimento 60	\N	\N	2024-07-11	60	60
26159	Pessoa61	Sobrenome61	2024-05-11	Local de Nascimento 61	\N	\N	2024-07-11	61	61
26161	Pessoa62	Sobrenome62	2024-05-10	Local de Nascimento 62	\N	\N	2024-07-11	62	62
26163	Pessoa63	Sobrenome63	2024-05-09	Local de Nascimento 63	\N	\N	2024-07-11	63	63
26165	Pessoa64	Sobrenome64	2024-05-08	Local de Nascimento 64	\N	\N	2024-07-11	64	64
26167	Pessoa65	Sobrenome65	2024-05-07	Local de Nascimento 65	\N	\N	2024-07-11	65	65
26169	Pessoa66	Sobrenome66	2024-05-06	Local de Nascimento 66	\N	\N	2024-07-11	66	66
26171	Pessoa67	Sobrenome67	2024-05-05	Local de Nascimento 67	\N	\N	2024-07-11	67	67
26173	Pessoa68	Sobrenome68	2024-05-04	Local de Nascimento 68	\N	\N	2024-07-11	68	68
26175	Pessoa69	Sobrenome69	2024-05-03	Local de Nascimento 69	\N	\N	2024-07-11	69	69
26177	Pessoa70	Sobrenome70	2024-05-02	Local de Nascimento 70	\N	\N	2024-07-11	70	70
26179	Pessoa71	Sobrenome71	2024-05-01	Local de Nascimento 71	\N	\N	2024-07-11	71	71
26181	Pessoa72	Sobrenome72	2024-04-30	Local de Nascimento 72	\N	\N	2024-07-11	72	72
26183	Pessoa73	Sobrenome73	2024-04-29	Local de Nascimento 73	\N	\N	2024-07-11	73	73
26185	Pessoa74	Sobrenome74	2024-04-28	Local de Nascimento 74	\N	\N	2024-07-11	74	74
26187	Pessoa75	Sobrenome75	2024-04-27	Local de Nascimento 75	\N	\N	2024-07-11	75	75
26189	Pessoa76	Sobrenome76	2024-04-26	Local de Nascimento 76	\N	\N	2024-07-11	76	76
26191	Pessoa77	Sobrenome77	2024-04-25	Local de Nascimento 77	\N	\N	2024-07-11	77	77
26193	Pessoa78	Sobrenome78	2024-04-24	Local de Nascimento 78	\N	\N	2024-07-11	78	78
26195	Pessoa79	Sobrenome79	2024-04-23	Local de Nascimento 79	\N	\N	2024-07-11	79	79
26197	Pessoa80	Sobrenome80	2024-04-22	Local de Nascimento 80	\N	\N	2024-07-11	80	80
26199	Pessoa81	Sobrenome81	2024-04-21	Local de Nascimento 81	\N	\N	2024-07-11	81	81
26201	Pessoa82	Sobrenome82	2024-04-20	Local de Nascimento 82	\N	\N	2024-07-11	82	82
26203	Pessoa83	Sobrenome83	2024-04-19	Local de Nascimento 83	\N	\N	2024-07-11	83	83
26205	Pessoa84	Sobrenome84	2024-04-18	Local de Nascimento 84	\N	\N	2024-07-11	84	84
26207	Pessoa85	Sobrenome85	2024-04-17	Local de Nascimento 85	\N	\N	2024-07-11	85	85
26209	Pessoa86	Sobrenome86	2024-04-16	Local de Nascimento 86	\N	\N	2024-07-11	86	86
26211	Pessoa87	Sobrenome87	2024-04-15	Local de Nascimento 87	\N	\N	2024-07-11	87	87
26213	Pessoa88	Sobrenome88	2024-04-14	Local de Nascimento 88	\N	\N	2024-07-11	88	88
26215	Pessoa89	Sobrenome89	2024-04-13	Local de Nascimento 89	\N	\N	2024-07-11	89	89
26217	Pessoa90	Sobrenome90	2024-04-12	Local de Nascimento 90	\N	\N	2024-07-11	90	90
26219	Pessoa91	Sobrenome91	2024-04-11	Local de Nascimento 91	\N	\N	2024-07-11	91	91
26221	Pessoa92	Sobrenome92	2024-04-10	Local de Nascimento 92	\N	\N	2024-07-11	92	92
26223	Pessoa93	Sobrenome93	2024-04-09	Local de Nascimento 93	\N	\N	2024-07-11	93	93
26225	Pessoa94	Sobrenome94	2024-04-08	Local de Nascimento 94	\N	\N	2024-07-11	94	94
26227	Pessoa95	Sobrenome95	2024-04-07	Local de Nascimento 95	\N	\N	2024-07-11	95	95
26229	Pessoa96	Sobrenome96	2024-04-06	Local de Nascimento 96	\N	\N	2024-07-11	96	96
26231	Pessoa97	Sobrenome97	2024-04-05	Local de Nascimento 97	\N	\N	2024-07-11	97	97
26233	Pessoa98	Sobrenome98	2024-04-04	Local de Nascimento 98	\N	\N	2024-07-11	98	98
26235	Pessoa99	Sobrenome99	2024-04-03	Local de Nascimento 99	\N	\N	2024-07-11	99	99
26237	Pessoa100	Sobrenome100	2024-04-02	Local de Nascimento 100	\N	\N	2024-07-11	100	100
26239	Pessoa101	Sobrenome101	2024-04-01	Local de Nascimento 101	\N	\N	2024-07-11	101	101
26241	Pessoa102	Sobrenome102	2024-03-31	Local de Nascimento 102	\N	\N	2024-07-11	102	102
26243	Pessoa103	Sobrenome103	2024-03-30	Local de Nascimento 103	\N	\N	2024-07-11	103	103
26245	Pessoa104	Sobrenome104	2024-03-29	Local de Nascimento 104	\N	\N	2024-07-11	104	104
26247	Pessoa105	Sobrenome105	2024-03-28	Local de Nascimento 105	\N	\N	2024-07-11	105	105
26249	Pessoa106	Sobrenome106	2024-03-27	Local de Nascimento 106	\N	\N	2024-07-11	106	106
26251	Pessoa107	Sobrenome107	2024-03-26	Local de Nascimento 107	\N	\N	2024-07-11	107	107
26253	Pessoa108	Sobrenome108	2024-03-25	Local de Nascimento 108	\N	\N	2024-07-11	108	108
26255	Pessoa109	Sobrenome109	2024-03-24	Local de Nascimento 109	\N	\N	2024-07-11	109	109
26257	Pessoa110	Sobrenome110	2024-03-23	Local de Nascimento 110	\N	\N	2024-07-11	110	110
26259	Pessoa111	Sobrenome111	2024-03-22	Local de Nascimento 111	\N	\N	2024-07-11	111	111
26261	Pessoa112	Sobrenome112	2024-03-21	Local de Nascimento 112	\N	\N	2024-07-11	112	112
26263	Pessoa113	Sobrenome113	2024-03-20	Local de Nascimento 113	\N	\N	2024-07-11	113	113
26265	Pessoa114	Sobrenome114	2024-03-19	Local de Nascimento 114	\N	\N	2024-07-11	114	114
26267	Pessoa115	Sobrenome115	2024-03-18	Local de Nascimento 115	\N	\N	2024-07-11	115	115
26269	Pessoa116	Sobrenome116	2024-03-17	Local de Nascimento 116	\N	\N	2024-07-11	116	116
26271	Pessoa117	Sobrenome117	2024-03-16	Local de Nascimento 117	\N	\N	2024-07-11	117	117
26273	Pessoa118	Sobrenome118	2024-03-15	Local de Nascimento 118	\N	\N	2024-07-11	118	118
26275	Pessoa119	Sobrenome119	2024-03-14	Local de Nascimento 119	\N	\N	2024-07-11	119	119
26277	Pessoa120	Sobrenome120	2024-03-13	Local de Nascimento 120	\N	\N	2024-07-11	120	120
26279	Pessoa121	Sobrenome121	2024-03-12	Local de Nascimento 121	\N	\N	2024-07-11	121	121
26281	Pessoa122	Sobrenome122	2024-03-11	Local de Nascimento 122	\N	\N	2024-07-11	122	122
26283	Pessoa123	Sobrenome123	2024-03-10	Local de Nascimento 123	\N	\N	2024-07-11	123	123
26285	Pessoa124	Sobrenome124	2024-03-09	Local de Nascimento 124	\N	\N	2024-07-11	124	124
26287	Pessoa125	Sobrenome125	2024-03-08	Local de Nascimento 125	\N	\N	2024-07-11	125	125
26289	Pessoa126	Sobrenome126	2024-03-07	Local de Nascimento 126	\N	\N	2024-07-11	126	126
26291	Pessoa127	Sobrenome127	2024-03-06	Local de Nascimento 127	\N	\N	2024-07-11	127	127
26293	Pessoa128	Sobrenome128	2024-03-05	Local de Nascimento 128	\N	\N	2024-07-11	128	128
26295	Pessoa129	Sobrenome129	2024-03-04	Local de Nascimento 129	\N	\N	2024-07-11	129	129
26297	Pessoa130	Sobrenome130	2024-03-03	Local de Nascimento 130	\N	\N	2024-07-11	130	130
26299	Pessoa131	Sobrenome131	2024-03-02	Local de Nascimento 131	\N	\N	2024-07-11	131	131
26301	Pessoa132	Sobrenome132	2024-03-01	Local de Nascimento 132	\N	\N	2024-07-11	132	132
26303	Pessoa133	Sobrenome133	2024-02-29	Local de Nascimento 133	\N	\N	2024-07-11	133	133
26305	Pessoa134	Sobrenome134	2024-02-28	Local de Nascimento 134	\N	\N	2024-07-11	134	134
26307	Pessoa135	Sobrenome135	2024-02-27	Local de Nascimento 135	\N	\N	2024-07-11	135	135
26309	Pessoa136	Sobrenome136	2024-02-26	Local de Nascimento 136	\N	\N	2024-07-11	136	136
26311	Pessoa137	Sobrenome137	2024-02-25	Local de Nascimento 137	\N	\N	2024-07-11	137	137
26313	Pessoa138	Sobrenome138	2024-02-24	Local de Nascimento 138	\N	\N	2024-07-11	138	138
26315	Pessoa139	Sobrenome139	2024-02-23	Local de Nascimento 139	\N	\N	2024-07-11	139	139
26317	Pessoa140	Sobrenome140	2024-02-22	Local de Nascimento 140	\N	\N	2024-07-11	140	140
26319	Pessoa141	Sobrenome141	2024-02-21	Local de Nascimento 141	\N	\N	2024-07-11	141	141
26321	Pessoa142	Sobrenome142	2024-02-20	Local de Nascimento 142	\N	\N	2024-07-11	142	142
26323	Pessoa143	Sobrenome143	2024-02-19	Local de Nascimento 143	\N	\N	2024-07-11	143	143
26325	Pessoa144	Sobrenome144	2024-02-18	Local de Nascimento 144	\N	\N	2024-07-11	144	144
26327	Pessoa145	Sobrenome145	2024-02-17	Local de Nascimento 145	\N	\N	2024-07-11	145	145
26329	Pessoa146	Sobrenome146	2024-02-16	Local de Nascimento 146	\N	\N	2024-07-11	146	146
26331	Pessoa147	Sobrenome147	2024-02-15	Local de Nascimento 147	\N	\N	2024-07-11	147	147
26333	Pessoa148	Sobrenome148	2024-02-14	Local de Nascimento 148	\N	\N	2024-07-11	148	148
26335	Pessoa149	Sobrenome149	2024-02-13	Local de Nascimento 149	\N	\N	2024-07-11	149	149
26337	Pessoa150	Sobrenome150	2024-02-12	Local de Nascimento 150	\N	\N	2024-07-11	150	150
26339	Pessoa151	Sobrenome151	2024-02-11	Local de Nascimento 151	\N	\N	2024-07-11	151	151
26341	Pessoa152	Sobrenome152	2024-02-10	Local de Nascimento 152	\N	\N	2024-07-11	152	152
26343	Pessoa153	Sobrenome153	2024-02-09	Local de Nascimento 153	\N	\N	2024-07-11	153	153
26345	Pessoa154	Sobrenome154	2024-02-08	Local de Nascimento 154	\N	\N	2024-07-11	154	154
26347	Pessoa155	Sobrenome155	2024-02-07	Local de Nascimento 155	\N	\N	2024-07-11	155	155
26349	Pessoa156	Sobrenome156	2024-02-06	Local de Nascimento 156	\N	\N	2024-07-11	156	156
26351	Pessoa157	Sobrenome157	2024-02-05	Local de Nascimento 157	\N	\N	2024-07-11	157	157
26353	Pessoa158	Sobrenome158	2024-02-04	Local de Nascimento 158	\N	\N	2024-07-11	158	158
26355	Pessoa159	Sobrenome159	2024-02-03	Local de Nascimento 159	\N	\N	2024-07-11	159	159
26357	Pessoa160	Sobrenome160	2024-02-02	Local de Nascimento 160	\N	\N	2024-07-11	160	160
26359	Pessoa161	Sobrenome161	2024-02-01	Local de Nascimento 161	\N	\N	2024-07-11	161	161
26361	Pessoa162	Sobrenome162	2024-01-31	Local de Nascimento 162	\N	\N	2024-07-11	162	162
26363	Pessoa163	Sobrenome163	2024-01-30	Local de Nascimento 163	\N	\N	2024-07-11	163	163
26365	Pessoa164	Sobrenome164	2024-01-29	Local de Nascimento 164	\N	\N	2024-07-11	164	164
26367	Pessoa165	Sobrenome165	2024-01-28	Local de Nascimento 165	\N	\N	2024-07-11	165	165
26369	Pessoa166	Sobrenome166	2024-01-27	Local de Nascimento 166	\N	\N	2024-07-11	166	166
26371	Pessoa167	Sobrenome167	2024-01-26	Local de Nascimento 167	\N	\N	2024-07-11	167	167
26373	Pessoa168	Sobrenome168	2024-01-25	Local de Nascimento 168	\N	\N	2024-07-11	168	168
26375	Pessoa169	Sobrenome169	2024-01-24	Local de Nascimento 169	\N	\N	2024-07-11	169	169
26377	Pessoa170	Sobrenome170	2024-01-23	Local de Nascimento 170	\N	\N	2024-07-11	170	170
26379	Pessoa171	Sobrenome171	2024-01-22	Local de Nascimento 171	\N	\N	2024-07-11	171	171
26381	Pessoa172	Sobrenome172	2024-01-21	Local de Nascimento 172	\N	\N	2024-07-11	172	172
26383	Pessoa173	Sobrenome173	2024-01-20	Local de Nascimento 173	\N	\N	2024-07-11	173	173
26385	Pessoa174	Sobrenome174	2024-01-19	Local de Nascimento 174	\N	\N	2024-07-11	174	174
26387	Pessoa175	Sobrenome175	2024-01-18	Local de Nascimento 175	\N	\N	2024-07-11	175	175
26389	Pessoa176	Sobrenome176	2024-01-17	Local de Nascimento 176	\N	\N	2024-07-11	176	176
26391	Pessoa177	Sobrenome177	2024-01-16	Local de Nascimento 177	\N	\N	2024-07-11	177	177
26393	Pessoa178	Sobrenome178	2024-01-15	Local de Nascimento 178	\N	\N	2024-07-11	178	178
26395	Pessoa179	Sobrenome179	2024-01-14	Local de Nascimento 179	\N	\N	2024-07-11	179	179
26397	Pessoa180	Sobrenome180	2024-01-13	Local de Nascimento 180	\N	\N	2024-07-11	180	180
26399	Pessoa181	Sobrenome181	2024-01-12	Local de Nascimento 181	\N	\N	2024-07-11	181	181
26401	Pessoa182	Sobrenome182	2024-01-11	Local de Nascimento 182	\N	\N	2024-07-11	182	182
26403	Pessoa183	Sobrenome183	2024-01-10	Local de Nascimento 183	\N	\N	2024-07-11	183	183
26405	Pessoa184	Sobrenome184	2024-01-09	Local de Nascimento 184	\N	\N	2024-07-11	184	184
26407	Pessoa185	Sobrenome185	2024-01-08	Local de Nascimento 185	\N	\N	2024-07-11	185	185
26409	Pessoa186	Sobrenome186	2024-01-07	Local de Nascimento 186	\N	\N	2024-07-11	186	186
26411	Pessoa187	Sobrenome187	2024-01-06	Local de Nascimento 187	\N	\N	2024-07-11	187	187
26413	Pessoa188	Sobrenome188	2024-01-05	Local de Nascimento 188	\N	\N	2024-07-11	188	188
26415	Pessoa189	Sobrenome189	2024-01-04	Local de Nascimento 189	\N	\N	2024-07-11	189	189
26417	Pessoa190	Sobrenome190	2024-01-03	Local de Nascimento 190	\N	\N	2024-07-11	190	190
26419	Pessoa191	Sobrenome191	2024-01-02	Local de Nascimento 191	\N	\N	2024-07-11	191	191
26421	Pessoa192	Sobrenome192	2024-01-01	Local de Nascimento 192	\N	\N	2024-07-11	192	192
26423	Pessoa193	Sobrenome193	2023-12-31	Local de Nascimento 193	\N	\N	2024-07-11	193	193
26425	Pessoa194	Sobrenome194	2023-12-30	Local de Nascimento 194	\N	\N	2024-07-11	194	194
26427	Pessoa195	Sobrenome195	2023-12-29	Local de Nascimento 195	\N	\N	2024-07-11	195	195
26429	Pessoa196	Sobrenome196	2023-12-28	Local de Nascimento 196	\N	\N	2024-07-11	196	196
26431	Pessoa197	Sobrenome197	2023-12-27	Local de Nascimento 197	\N	\N	2024-07-11	197	197
26433	Pessoa198	Sobrenome198	2023-12-26	Local de Nascimento 198	\N	\N	2024-07-11	198	198
26435	Pessoa199	Sobrenome199	2023-12-25	Local de Nascimento 199	\N	\N	2024-07-11	199	199
26437	Pessoa200	Sobrenome200	2023-12-24	Local de Nascimento 200	\N	\N	2024-07-11	200	200
26439	Pessoa201	Sobrenome201	2023-12-23	Local de Nascimento 201	\N	\N	2024-07-11	201	201
26441	Pessoa202	Sobrenome202	2023-12-22	Local de Nascimento 202	\N	\N	2024-07-11	202	202
26443	Pessoa203	Sobrenome203	2023-12-21	Local de Nascimento 203	\N	\N	2024-07-11	203	203
26445	Pessoa204	Sobrenome204	2023-12-20	Local de Nascimento 204	\N	\N	2024-07-11	204	204
26447	Pessoa205	Sobrenome205	2023-12-19	Local de Nascimento 205	\N	\N	2024-07-11	205	205
26449	Pessoa206	Sobrenome206	2023-12-18	Local de Nascimento 206	\N	\N	2024-07-11	206	206
26451	Pessoa207	Sobrenome207	2023-12-17	Local de Nascimento 207	\N	\N	2024-07-11	207	207
26453	Pessoa208	Sobrenome208	2023-12-16	Local de Nascimento 208	\N	\N	2024-07-11	208	208
26455	Pessoa209	Sobrenome209	2023-12-15	Local de Nascimento 209	\N	\N	2024-07-11	209	209
26457	Pessoa210	Sobrenome210	2023-12-14	Local de Nascimento 210	\N	\N	2024-07-11	210	210
26459	Pessoa211	Sobrenome211	2023-12-13	Local de Nascimento 211	\N	\N	2024-07-11	211	211
26461	Pessoa212	Sobrenome212	2023-12-12	Local de Nascimento 212	\N	\N	2024-07-11	212	212
26463	Pessoa213	Sobrenome213	2023-12-11	Local de Nascimento 213	\N	\N	2024-07-11	213	213
26465	Pessoa214	Sobrenome214	2023-12-10	Local de Nascimento 214	\N	\N	2024-07-11	214	214
26467	Pessoa215	Sobrenome215	2023-12-09	Local de Nascimento 215	\N	\N	2024-07-11	215	215
26469	Pessoa216	Sobrenome216	2023-12-08	Local de Nascimento 216	\N	\N	2024-07-11	216	216
26471	Pessoa217	Sobrenome217	2023-12-07	Local de Nascimento 217	\N	\N	2024-07-11	217	217
26473	Pessoa218	Sobrenome218	2023-12-06	Local de Nascimento 218	\N	\N	2024-07-11	218	218
26475	Pessoa219	Sobrenome219	2023-12-05	Local de Nascimento 219	\N	\N	2024-07-11	219	219
26477	Pessoa220	Sobrenome220	2023-12-04	Local de Nascimento 220	\N	\N	2024-07-11	220	220
26479	Pessoa221	Sobrenome221	2023-12-03	Local de Nascimento 221	\N	\N	2024-07-11	221	221
26481	Pessoa222	Sobrenome222	2023-12-02	Local de Nascimento 222	\N	\N	2024-07-11	222	222
26483	Pessoa223	Sobrenome223	2023-12-01	Local de Nascimento 223	\N	\N	2024-07-11	223	223
26485	Pessoa224	Sobrenome224	2023-11-30	Local de Nascimento 224	\N	\N	2024-07-11	224	224
26487	Pessoa225	Sobrenome225	2023-11-29	Local de Nascimento 225	\N	\N	2024-07-11	225	225
26489	Pessoa226	Sobrenome226	2023-11-28	Local de Nascimento 226	\N	\N	2024-07-11	226	226
26491	Pessoa227	Sobrenome227	2023-11-27	Local de Nascimento 227	\N	\N	2024-07-11	227	227
26493	Pessoa228	Sobrenome228	2023-11-26	Local de Nascimento 228	\N	\N	2024-07-11	228	228
26495	Pessoa229	Sobrenome229	2023-11-25	Local de Nascimento 229	\N	\N	2024-07-11	229	229
26497	Pessoa230	Sobrenome230	2023-11-24	Local de Nascimento 230	\N	\N	2024-07-11	230	230
26499	Pessoa231	Sobrenome231	2023-11-23	Local de Nascimento 231	\N	\N	2024-07-11	231	231
26501	Pessoa232	Sobrenome232	2023-11-22	Local de Nascimento 232	\N	\N	2024-07-11	232	232
26503	Pessoa233	Sobrenome233	2023-11-21	Local de Nascimento 233	\N	\N	2024-07-11	233	233
26505	Pessoa234	Sobrenome234	2023-11-20	Local de Nascimento 234	\N	\N	2024-07-11	234	234
26507	Pessoa235	Sobrenome235	2023-11-19	Local de Nascimento 235	\N	\N	2024-07-11	235	235
26509	Pessoa236	Sobrenome236	2023-11-18	Local de Nascimento 236	\N	\N	2024-07-11	236	236
26511	Pessoa237	Sobrenome237	2023-11-17	Local de Nascimento 237	\N	\N	2024-07-11	237	237
26513	Pessoa238	Sobrenome238	2023-11-16	Local de Nascimento 238	\N	\N	2024-07-11	238	238
26515	Pessoa239	Sobrenome239	2023-11-15	Local de Nascimento 239	\N	\N	2024-07-11	239	239
26517	Pessoa240	Sobrenome240	2023-11-14	Local de Nascimento 240	\N	\N	2024-07-11	240	240
26519	Pessoa241	Sobrenome241	2023-11-13	Local de Nascimento 241	\N	\N	2024-07-11	241	241
26521	Pessoa242	Sobrenome242	2023-11-12	Local de Nascimento 242	\N	\N	2024-07-11	242	242
26523	Pessoa243	Sobrenome243	2023-11-11	Local de Nascimento 243	\N	\N	2024-07-11	243	243
26525	Pessoa244	Sobrenome244	2023-11-10	Local de Nascimento 244	\N	\N	2024-07-11	244	244
26527	Pessoa245	Sobrenome245	2023-11-09	Local de Nascimento 245	\N	\N	2024-07-11	245	245
26529	Pessoa246	Sobrenome246	2023-11-08	Local de Nascimento 246	\N	\N	2024-07-11	246	246
26531	Pessoa247	Sobrenome247	2023-11-07	Local de Nascimento 247	\N	\N	2024-07-11	247	247
26533	Pessoa248	Sobrenome248	2023-11-06	Local de Nascimento 248	\N	\N	2024-07-11	248	248
26535	Pessoa249	Sobrenome249	2023-11-05	Local de Nascimento 249	\N	\N	2024-07-11	249	249
26537	Pessoa250	Sobrenome250	2023-11-04	Local de Nascimento 250	\N	\N	2024-07-11	250	250
26539	Pessoa251	Sobrenome251	2023-11-03	Local de Nascimento 251	\N	\N	2024-07-11	251	251
26541	Pessoa252	Sobrenome252	2023-11-02	Local de Nascimento 252	\N	\N	2024-07-11	252	252
26543	Pessoa253	Sobrenome253	2023-11-01	Local de Nascimento 253	\N	\N	2024-07-11	253	253
26545	Pessoa254	Sobrenome254	2023-10-31	Local de Nascimento 254	\N	\N	2024-07-11	254	254
26547	Pessoa255	Sobrenome255	2023-10-30	Local de Nascimento 255	\N	\N	2024-07-11	255	255
26549	Pessoa256	Sobrenome256	2023-10-29	Local de Nascimento 256	\N	\N	2024-07-11	256	256
26551	Pessoa257	Sobrenome257	2023-10-28	Local de Nascimento 257	\N	\N	2024-07-11	257	257
26553	Pessoa258	Sobrenome258	2023-10-27	Local de Nascimento 258	\N	\N	2024-07-11	258	258
26555	Pessoa259	Sobrenome259	2023-10-26	Local de Nascimento 259	\N	\N	2024-07-11	259	259
26557	Pessoa260	Sobrenome260	2023-10-25	Local de Nascimento 260	\N	\N	2024-07-11	260	260
26559	Pessoa261	Sobrenome261	2023-10-24	Local de Nascimento 261	\N	\N	2024-07-11	261	261
26561	Pessoa262	Sobrenome262	2023-10-23	Local de Nascimento 262	\N	\N	2024-07-11	262	262
26563	Pessoa263	Sobrenome263	2023-10-22	Local de Nascimento 263	\N	\N	2024-07-11	263	263
26565	Pessoa264	Sobrenome264	2023-10-21	Local de Nascimento 264	\N	\N	2024-07-11	264	264
26567	Pessoa265	Sobrenome265	2023-10-20	Local de Nascimento 265	\N	\N	2024-07-11	265	265
26569	Pessoa266	Sobrenome266	2023-10-19	Local de Nascimento 266	\N	\N	2024-07-11	266	266
26571	Pessoa267	Sobrenome267	2023-10-18	Local de Nascimento 267	\N	\N	2024-07-11	267	267
26573	Pessoa268	Sobrenome268	2023-10-17	Local de Nascimento 268	\N	\N	2024-07-11	268	268
26575	Pessoa269	Sobrenome269	2023-10-16	Local de Nascimento 269	\N	\N	2024-07-11	269	269
26577	Pessoa270	Sobrenome270	2023-10-15	Local de Nascimento 270	\N	\N	2024-07-11	270	270
26579	Pessoa271	Sobrenome271	2023-10-14	Local de Nascimento 271	\N	\N	2024-07-11	271	271
26581	Pessoa272	Sobrenome272	2023-10-13	Local de Nascimento 272	\N	\N	2024-07-11	272	272
26583	Pessoa273	Sobrenome273	2023-10-12	Local de Nascimento 273	\N	\N	2024-07-11	273	273
26585	Pessoa274	Sobrenome274	2023-10-11	Local de Nascimento 274	\N	\N	2024-07-11	274	274
26587	Pessoa275	Sobrenome275	2023-10-10	Local de Nascimento 275	\N	\N	2024-07-11	275	275
26589	Pessoa276	Sobrenome276	2023-10-09	Local de Nascimento 276	\N	\N	2024-07-11	276	276
26591	Pessoa277	Sobrenome277	2023-10-08	Local de Nascimento 277	\N	\N	2024-07-11	277	277
26593	Pessoa278	Sobrenome278	2023-10-07	Local de Nascimento 278	\N	\N	2024-07-11	278	278
26595	Pessoa279	Sobrenome279	2023-10-06	Local de Nascimento 279	\N	\N	2024-07-11	279	279
26597	Pessoa280	Sobrenome280	2023-10-05	Local de Nascimento 280	\N	\N	2024-07-11	280	280
26599	Pessoa281	Sobrenome281	2023-10-04	Local de Nascimento 281	\N	\N	2024-07-11	281	281
26601	Pessoa282	Sobrenome282	2023-10-03	Local de Nascimento 282	\N	\N	2024-07-11	282	282
26603	Pessoa283	Sobrenome283	2023-10-02	Local de Nascimento 283	\N	\N	2024-07-11	283	283
26605	Pessoa284	Sobrenome284	2023-10-01	Local de Nascimento 284	\N	\N	2024-07-11	284	284
26607	Pessoa285	Sobrenome285	2023-09-30	Local de Nascimento 285	\N	\N	2024-07-11	285	285
26609	Pessoa286	Sobrenome286	2023-09-29	Local de Nascimento 286	\N	\N	2024-07-11	286	286
26611	Pessoa287	Sobrenome287	2023-09-28	Local de Nascimento 287	\N	\N	2024-07-11	287	287
26613	Pessoa288	Sobrenome288	2023-09-27	Local de Nascimento 288	\N	\N	2024-07-11	288	288
26615	Pessoa289	Sobrenome289	2023-09-26	Local de Nascimento 289	\N	\N	2024-07-11	289	289
26617	Pessoa290	Sobrenome290	2023-09-25	Local de Nascimento 290	\N	\N	2024-07-11	290	290
26619	Pessoa291	Sobrenome291	2023-09-24	Local de Nascimento 291	\N	\N	2024-07-11	291	291
26621	Pessoa292	Sobrenome292	2023-09-23	Local de Nascimento 292	\N	\N	2024-07-11	292	292
26623	Pessoa293	Sobrenome293	2023-09-22	Local de Nascimento 293	\N	\N	2024-07-11	293	293
26625	Pessoa294	Sobrenome294	2023-09-21	Local de Nascimento 294	\N	\N	2024-07-11	294	294
26627	Pessoa295	Sobrenome295	2023-09-20	Local de Nascimento 295	\N	\N	2024-07-11	295	295
26629	Pessoa296	Sobrenome296	2023-09-19	Local de Nascimento 296	\N	\N	2024-07-11	296	296
26631	Pessoa297	Sobrenome297	2023-09-18	Local de Nascimento 297	\N	\N	2024-07-11	297	297
26633	Pessoa298	Sobrenome298	2023-09-17	Local de Nascimento 298	\N	\N	2024-07-11	298	298
26635	Pessoa299	Sobrenome299	2023-09-16	Local de Nascimento 299	\N	\N	2024-07-11	299	299
26637	Pessoa300	Sobrenome300	2023-09-15	Local de Nascimento 300	\N	\N	2024-07-11	300	300
26639	Pessoa301	Sobrenome301	2023-09-14	Local de Nascimento 301	\N	\N	2024-07-11	301	301
26641	Pessoa302	Sobrenome302	2023-09-13	Local de Nascimento 302	\N	\N	2024-07-11	302	302
26643	Pessoa303	Sobrenome303	2023-09-12	Local de Nascimento 303	\N	\N	2024-07-11	303	303
26645	Pessoa304	Sobrenome304	2023-09-11	Local de Nascimento 304	\N	\N	2024-07-11	304	304
26647	Pessoa305	Sobrenome305	2023-09-10	Local de Nascimento 305	\N	\N	2024-07-11	305	305
26649	Pessoa306	Sobrenome306	2023-09-09	Local de Nascimento 306	\N	\N	2024-07-11	306	306
26651	Pessoa307	Sobrenome307	2023-09-08	Local de Nascimento 307	\N	\N	2024-07-11	307	307
26653	Pessoa308	Sobrenome308	2023-09-07	Local de Nascimento 308	\N	\N	2024-07-11	308	308
26655	Pessoa309	Sobrenome309	2023-09-06	Local de Nascimento 309	\N	\N	2024-07-11	309	309
26657	Pessoa310	Sobrenome310	2023-09-05	Local de Nascimento 310	\N	\N	2024-07-11	310	310
26659	Pessoa311	Sobrenome311	2023-09-04	Local de Nascimento 311	\N	\N	2024-07-11	311	311
26661	Pessoa312	Sobrenome312	2023-09-03	Local de Nascimento 312	\N	\N	2024-07-11	312	312
26663	Pessoa313	Sobrenome313	2023-09-02	Local de Nascimento 313	\N	\N	2024-07-11	313	313
26665	Pessoa314	Sobrenome314	2023-09-01	Local de Nascimento 314	\N	\N	2024-07-11	314	314
26667	Pessoa315	Sobrenome315	2023-08-31	Local de Nascimento 315	\N	\N	2024-07-11	315	315
26669	Pessoa316	Sobrenome316	2023-08-30	Local de Nascimento 316	\N	\N	2024-07-11	316	316
26671	Pessoa317	Sobrenome317	2023-08-29	Local de Nascimento 317	\N	\N	2024-07-11	317	317
26673	Pessoa318	Sobrenome318	2023-08-28	Local de Nascimento 318	\N	\N	2024-07-11	318	318
26675	Pessoa319	Sobrenome319	2023-08-27	Local de Nascimento 319	\N	\N	2024-07-11	319	319
26677	Pessoa320	Sobrenome320	2023-08-26	Local de Nascimento 320	\N	\N	2024-07-11	320	320
26679	Pessoa321	Sobrenome321	2023-08-25	Local de Nascimento 321	\N	\N	2024-07-11	321	321
26681	Pessoa322	Sobrenome322	2023-08-24	Local de Nascimento 322	\N	\N	2024-07-11	322	322
26683	Pessoa323	Sobrenome323	2023-08-23	Local de Nascimento 323	\N	\N	2024-07-11	323	323
26685	Pessoa324	Sobrenome324	2023-08-22	Local de Nascimento 324	\N	\N	2024-07-11	324	324
26687	Pessoa325	Sobrenome325	2023-08-21	Local de Nascimento 325	\N	\N	2024-07-11	325	325
26689	Pessoa326	Sobrenome326	2023-08-20	Local de Nascimento 326	\N	\N	2024-07-11	326	326
26691	Pessoa327	Sobrenome327	2023-08-19	Local de Nascimento 327	\N	\N	2024-07-11	327	327
26693	Pessoa328	Sobrenome328	2023-08-18	Local de Nascimento 328	\N	\N	2024-07-11	328	328
26695	Pessoa329	Sobrenome329	2023-08-17	Local de Nascimento 329	\N	\N	2024-07-11	329	329
26697	Pessoa330	Sobrenome330	2023-08-16	Local de Nascimento 330	\N	\N	2024-07-11	330	330
26699	Pessoa331	Sobrenome331	2023-08-15	Local de Nascimento 331	\N	\N	2024-07-11	331	331
26701	Pessoa332	Sobrenome332	2023-08-14	Local de Nascimento 332	\N	\N	2024-07-11	332	332
26703	Pessoa333	Sobrenome333	2023-08-13	Local de Nascimento 333	\N	\N	2024-07-11	333	333
26705	Pessoa334	Sobrenome334	2023-08-12	Local de Nascimento 334	\N	\N	2024-07-11	334	334
26707	Pessoa335	Sobrenome335	2023-08-11	Local de Nascimento 335	\N	\N	2024-07-11	335	335
26709	Pessoa336	Sobrenome336	2023-08-10	Local de Nascimento 336	\N	\N	2024-07-11	336	336
26711	Pessoa337	Sobrenome337	2023-08-09	Local de Nascimento 337	\N	\N	2024-07-11	337	337
26713	Pessoa338	Sobrenome338	2023-08-08	Local de Nascimento 338	\N	\N	2024-07-11	338	338
26715	Pessoa339	Sobrenome339	2023-08-07	Local de Nascimento 339	\N	\N	2024-07-11	339	339
26717	Pessoa340	Sobrenome340	2023-08-06	Local de Nascimento 340	\N	\N	2024-07-11	340	340
26719	Pessoa341	Sobrenome341	2023-08-05	Local de Nascimento 341	\N	\N	2024-07-11	341	341
26721	Pessoa342	Sobrenome342	2023-08-04	Local de Nascimento 342	\N	\N	2024-07-11	342	342
26723	Pessoa343	Sobrenome343	2023-08-03	Local de Nascimento 343	\N	\N	2024-07-11	343	343
26725	Pessoa344	Sobrenome344	2023-08-02	Local de Nascimento 344	\N	\N	2024-07-11	344	344
26727	Pessoa345	Sobrenome345	2023-08-01	Local de Nascimento 345	\N	\N	2024-07-11	345	345
26729	Pessoa346	Sobrenome346	2023-07-31	Local de Nascimento 346	\N	\N	2024-07-11	346	346
26731	Pessoa347	Sobrenome347	2023-07-30	Local de Nascimento 347	\N	\N	2024-07-11	347	347
26733	Pessoa348	Sobrenome348	2023-07-29	Local de Nascimento 348	\N	\N	2024-07-11	348	348
26735	Pessoa349	Sobrenome349	2023-07-28	Local de Nascimento 349	\N	\N	2024-07-11	349	349
26737	Pessoa350	Sobrenome350	2023-07-27	Local de Nascimento 350	\N	\N	2024-07-11	350	350
26739	Pessoa351	Sobrenome351	2023-07-26	Local de Nascimento 351	\N	\N	2024-07-11	351	351
26741	Pessoa352	Sobrenome352	2023-07-25	Local de Nascimento 352	\N	\N	2024-07-11	352	352
26743	Pessoa353	Sobrenome353	2023-07-24	Local de Nascimento 353	\N	\N	2024-07-11	353	353
26745	Pessoa354	Sobrenome354	2023-07-23	Local de Nascimento 354	\N	\N	2024-07-11	354	354
26747	Pessoa355	Sobrenome355	2023-07-22	Local de Nascimento 355	\N	\N	2024-07-11	355	355
26749	Pessoa356	Sobrenome356	2023-07-21	Local de Nascimento 356	\N	\N	2024-07-11	356	356
26751	Pessoa357	Sobrenome357	2023-07-20	Local de Nascimento 357	\N	\N	2024-07-11	357	357
26753	Pessoa358	Sobrenome358	2023-07-19	Local de Nascimento 358	\N	\N	2024-07-11	358	358
26755	Pessoa359	Sobrenome359	2023-07-18	Local de Nascimento 359	\N	\N	2024-07-11	359	359
26757	Pessoa360	Sobrenome360	2023-07-17	Local de Nascimento 360	\N	\N	2024-07-11	360	360
26759	Pessoa361	Sobrenome361	2023-07-16	Local de Nascimento 361	\N	\N	2024-07-11	361	361
26761	Pessoa362	Sobrenome362	2023-07-15	Local de Nascimento 362	\N	\N	2024-07-11	362	362
26763	Pessoa363	Sobrenome363	2023-07-14	Local de Nascimento 363	\N	\N	2024-07-11	363	363
26765	Pessoa364	Sobrenome364	2023-07-13	Local de Nascimento 364	\N	\N	2024-07-11	364	364
26767	Pessoa365	Sobrenome365	2023-07-12	Local de Nascimento 365	\N	\N	2024-07-11	365	365
26769	Pessoa366	Sobrenome366	2023-07-11	Local de Nascimento 366	\N	\N	2024-07-11	366	366
26771	Pessoa367	Sobrenome367	2023-07-10	Local de Nascimento 367	\N	\N	2024-07-11	367	367
26773	Pessoa368	Sobrenome368	2023-07-09	Local de Nascimento 368	\N	\N	2024-07-11	368	368
26775	Pessoa369	Sobrenome369	2023-07-08	Local de Nascimento 369	\N	\N	2024-07-11	369	369
26777	Pessoa370	Sobrenome370	2023-07-07	Local de Nascimento 370	\N	\N	2024-07-11	370	370
26779	Pessoa371	Sobrenome371	2023-07-06	Local de Nascimento 371	\N	\N	2024-07-11	371	371
26781	Pessoa372	Sobrenome372	2023-07-05	Local de Nascimento 372	\N	\N	2024-07-11	372	372
26783	Pessoa373	Sobrenome373	2023-07-04	Local de Nascimento 373	\N	\N	2024-07-11	373	373
26785	Pessoa374	Sobrenome374	2023-07-03	Local de Nascimento 374	\N	\N	2024-07-11	374	374
26787	Pessoa375	Sobrenome375	2023-07-02	Local de Nascimento 375	\N	\N	2024-07-11	375	375
26789	Pessoa376	Sobrenome376	2023-07-01	Local de Nascimento 376	\N	\N	2024-07-11	376	376
26791	Pessoa377	Sobrenome377	2023-06-30	Local de Nascimento 377	\N	\N	2024-07-11	377	377
26793	Pessoa378	Sobrenome378	2023-06-29	Local de Nascimento 378	\N	\N	2024-07-11	378	378
26795	Pessoa379	Sobrenome379	2023-06-28	Local de Nascimento 379	\N	\N	2024-07-11	379	379
26797	Pessoa380	Sobrenome380	2023-06-27	Local de Nascimento 380	\N	\N	2024-07-11	380	380
26799	Pessoa381	Sobrenome381	2023-06-26	Local de Nascimento 381	\N	\N	2024-07-11	381	381
26801	Pessoa382	Sobrenome382	2023-06-25	Local de Nascimento 382	\N	\N	2024-07-11	382	382
26803	Pessoa383	Sobrenome383	2023-06-24	Local de Nascimento 383	\N	\N	2024-07-11	383	383
26805	Pessoa384	Sobrenome384	2023-06-23	Local de Nascimento 384	\N	\N	2024-07-11	384	384
26807	Pessoa385	Sobrenome385	2023-06-22	Local de Nascimento 385	\N	\N	2024-07-11	385	385
26809	Pessoa386	Sobrenome386	2023-06-21	Local de Nascimento 386	\N	\N	2024-07-11	386	386
26811	Pessoa387	Sobrenome387	2023-06-20	Local de Nascimento 387	\N	\N	2024-07-11	387	387
26813	Pessoa388	Sobrenome388	2023-06-19	Local de Nascimento 388	\N	\N	2024-07-11	388	388
26815	Pessoa389	Sobrenome389	2023-06-18	Local de Nascimento 389	\N	\N	2024-07-11	389	389
26817	Pessoa390	Sobrenome390	2023-06-17	Local de Nascimento 390	\N	\N	2024-07-11	390	390
26819	Pessoa391	Sobrenome391	2023-06-16	Local de Nascimento 391	\N	\N	2024-07-11	391	391
26821	Pessoa392	Sobrenome392	2023-06-15	Local de Nascimento 392	\N	\N	2024-07-11	392	392
26823	Pessoa393	Sobrenome393	2023-06-14	Local de Nascimento 393	\N	\N	2024-07-11	393	393
26825	Pessoa394	Sobrenome394	2023-06-13	Local de Nascimento 394	\N	\N	2024-07-11	394	394
26827	Pessoa395	Sobrenome395	2023-06-12	Local de Nascimento 395	\N	\N	2024-07-11	395	395
26829	Pessoa396	Sobrenome396	2023-06-11	Local de Nascimento 396	\N	\N	2024-07-11	396	396
26831	Pessoa397	Sobrenome397	2023-06-10	Local de Nascimento 397	\N	\N	2024-07-11	397	397
26833	Pessoa398	Sobrenome398	2023-06-09	Local de Nascimento 398	\N	\N	2024-07-11	398	398
26835	Pessoa399	Sobrenome399	2023-06-08	Local de Nascimento 399	\N	\N	2024-07-11	399	399
26837	Pessoa400	Sobrenome400	2023-06-07	Local de Nascimento 400	\N	\N	2024-07-11	400	400
26839	Pessoa401	Sobrenome401	2023-06-06	Local de Nascimento 401	\N	\N	2024-07-11	401	401
26841	Pessoa402	Sobrenome402	2023-06-05	Local de Nascimento 402	\N	\N	2024-07-11	402	402
26843	Pessoa403	Sobrenome403	2023-06-04	Local de Nascimento 403	\N	\N	2024-07-11	403	403
26845	Pessoa404	Sobrenome404	2023-06-03	Local de Nascimento 404	\N	\N	2024-07-11	404	404
26847	Pessoa405	Sobrenome405	2023-06-02	Local de Nascimento 405	\N	\N	2024-07-11	405	405
26849	Pessoa406	Sobrenome406	2023-06-01	Local de Nascimento 406	\N	\N	2024-07-11	406	406
26851	Pessoa407	Sobrenome407	2023-05-31	Local de Nascimento 407	\N	\N	2024-07-11	407	407
26853	Pessoa408	Sobrenome408	2023-05-30	Local de Nascimento 408	\N	\N	2024-07-11	408	408
26855	Pessoa409	Sobrenome409	2023-05-29	Local de Nascimento 409	\N	\N	2024-07-11	409	409
26857	Pessoa410	Sobrenome410	2023-05-28	Local de Nascimento 410	\N	\N	2024-07-11	410	410
26859	Pessoa411	Sobrenome411	2023-05-27	Local de Nascimento 411	\N	\N	2024-07-11	411	411
26861	Pessoa412	Sobrenome412	2023-05-26	Local de Nascimento 412	\N	\N	2024-07-11	412	412
26863	Pessoa413	Sobrenome413	2023-05-25	Local de Nascimento 413	\N	\N	2024-07-11	413	413
26865	Pessoa414	Sobrenome414	2023-05-24	Local de Nascimento 414	\N	\N	2024-07-11	414	414
26867	Pessoa415	Sobrenome415	2023-05-23	Local de Nascimento 415	\N	\N	2024-07-11	415	415
26869	Pessoa416	Sobrenome416	2023-05-22	Local de Nascimento 416	\N	\N	2024-07-11	416	416
26871	Pessoa417	Sobrenome417	2023-05-21	Local de Nascimento 417	\N	\N	2024-07-11	417	417
26873	Pessoa418	Sobrenome418	2023-05-20	Local de Nascimento 418	\N	\N	2024-07-11	418	418
26875	Pessoa419	Sobrenome419	2023-05-19	Local de Nascimento 419	\N	\N	2024-07-11	419	419
26877	Pessoa420	Sobrenome420	2023-05-18	Local de Nascimento 420	\N	\N	2024-07-11	420	420
26879	Pessoa421	Sobrenome421	2023-05-17	Local de Nascimento 421	\N	\N	2024-07-11	421	421
26881	Pessoa422	Sobrenome422	2023-05-16	Local de Nascimento 422	\N	\N	2024-07-11	422	422
26883	Pessoa423	Sobrenome423	2023-05-15	Local de Nascimento 423	\N	\N	2024-07-11	423	423
26885	Pessoa424	Sobrenome424	2023-05-14	Local de Nascimento 424	\N	\N	2024-07-11	424	424
26887	Pessoa425	Sobrenome425	2023-05-13	Local de Nascimento 425	\N	\N	2024-07-11	425	425
26889	Pessoa426	Sobrenome426	2023-05-12	Local de Nascimento 426	\N	\N	2024-07-11	426	426
26891	Pessoa427	Sobrenome427	2023-05-11	Local de Nascimento 427	\N	\N	2024-07-11	427	427
26893	Pessoa428	Sobrenome428	2023-05-10	Local de Nascimento 428	\N	\N	2024-07-11	428	428
26895	Pessoa429	Sobrenome429	2023-05-09	Local de Nascimento 429	\N	\N	2024-07-11	429	429
26897	Pessoa430	Sobrenome430	2023-05-08	Local de Nascimento 430	\N	\N	2024-07-11	430	430
26899	Pessoa431	Sobrenome431	2023-05-07	Local de Nascimento 431	\N	\N	2024-07-11	431	431
26901	Pessoa432	Sobrenome432	2023-05-06	Local de Nascimento 432	\N	\N	2024-07-11	432	432
26903	Pessoa433	Sobrenome433	2023-05-05	Local de Nascimento 433	\N	\N	2024-07-11	433	433
26905	Pessoa434	Sobrenome434	2023-05-04	Local de Nascimento 434	\N	\N	2024-07-11	434	434
26907	Pessoa435	Sobrenome435	2023-05-03	Local de Nascimento 435	\N	\N	2024-07-11	435	435
26909	Pessoa436	Sobrenome436	2023-05-02	Local de Nascimento 436	\N	\N	2024-07-11	436	436
26911	Pessoa437	Sobrenome437	2023-05-01	Local de Nascimento 437	\N	\N	2024-07-11	437	437
26913	Pessoa438	Sobrenome438	2023-04-30	Local de Nascimento 438	\N	\N	2024-07-11	438	438
26915	Pessoa439	Sobrenome439	2023-04-29	Local de Nascimento 439	\N	\N	2024-07-11	439	439
26917	Pessoa440	Sobrenome440	2023-04-28	Local de Nascimento 440	\N	\N	2024-07-11	440	440
26919	Pessoa441	Sobrenome441	2023-04-27	Local de Nascimento 441	\N	\N	2024-07-11	441	441
26921	Pessoa442	Sobrenome442	2023-04-26	Local de Nascimento 442	\N	\N	2024-07-11	442	442
26923	Pessoa443	Sobrenome443	2023-04-25	Local de Nascimento 443	\N	\N	2024-07-11	443	443
26925	Pessoa444	Sobrenome444	2023-04-24	Local de Nascimento 444	\N	\N	2024-07-11	444	444
26927	Pessoa445	Sobrenome445	2023-04-23	Local de Nascimento 445	\N	\N	2024-07-11	445	445
26929	Pessoa446	Sobrenome446	2023-04-22	Local de Nascimento 446	\N	\N	2024-07-11	446	446
26931	Pessoa447	Sobrenome447	2023-04-21	Local de Nascimento 447	\N	\N	2024-07-11	447	447
26933	Pessoa448	Sobrenome448	2023-04-20	Local de Nascimento 448	\N	\N	2024-07-11	448	448
26935	Pessoa449	Sobrenome449	2023-04-19	Local de Nascimento 449	\N	\N	2024-07-11	449	449
26937	Pessoa450	Sobrenome450	2023-04-18	Local de Nascimento 450	\N	\N	2024-07-11	450	450
26939	Pessoa451	Sobrenome451	2023-04-17	Local de Nascimento 451	\N	\N	2024-07-11	451	451
26941	Pessoa452	Sobrenome452	2023-04-16	Local de Nascimento 452	\N	\N	2024-07-11	452	452
26943	Pessoa453	Sobrenome453	2023-04-15	Local de Nascimento 453	\N	\N	2024-07-11	453	453
26945	Pessoa454	Sobrenome454	2023-04-14	Local de Nascimento 454	\N	\N	2024-07-11	454	454
26947	Pessoa455	Sobrenome455	2023-04-13	Local de Nascimento 455	\N	\N	2024-07-11	455	455
26949	Pessoa456	Sobrenome456	2023-04-12	Local de Nascimento 456	\N	\N	2024-07-11	456	456
26951	Pessoa457	Sobrenome457	2023-04-11	Local de Nascimento 457	\N	\N	2024-07-11	457	457
26953	Pessoa458	Sobrenome458	2023-04-10	Local de Nascimento 458	\N	\N	2024-07-11	458	458
26955	Pessoa459	Sobrenome459	2023-04-09	Local de Nascimento 459	\N	\N	2024-07-11	459	459
26957	Pessoa460	Sobrenome460	2023-04-08	Local de Nascimento 460	\N	\N	2024-07-11	460	460
26959	Pessoa461	Sobrenome461	2023-04-07	Local de Nascimento 461	\N	\N	2024-07-11	461	461
26961	Pessoa462	Sobrenome462	2023-04-06	Local de Nascimento 462	\N	\N	2024-07-11	462	462
26963	Pessoa463	Sobrenome463	2023-04-05	Local de Nascimento 463	\N	\N	2024-07-11	463	463
26965	Pessoa464	Sobrenome464	2023-04-04	Local de Nascimento 464	\N	\N	2024-07-11	464	464
26967	Pessoa465	Sobrenome465	2023-04-03	Local de Nascimento 465	\N	\N	2024-07-11	465	465
26969	Pessoa466	Sobrenome466	2023-04-02	Local de Nascimento 466	\N	\N	2024-07-11	466	466
26971	Pessoa467	Sobrenome467	2023-04-01	Local de Nascimento 467	\N	\N	2024-07-11	467	467
26973	Pessoa468	Sobrenome468	2023-03-31	Local de Nascimento 468	\N	\N	2024-07-11	468	468
26975	Pessoa469	Sobrenome469	2023-03-30	Local de Nascimento 469	\N	\N	2024-07-11	469	469
26977	Pessoa470	Sobrenome470	2023-03-29	Local de Nascimento 470	\N	\N	2024-07-11	470	470
26979	Pessoa471	Sobrenome471	2023-03-28	Local de Nascimento 471	\N	\N	2024-07-11	471	471
26981	Pessoa472	Sobrenome472	2023-03-27	Local de Nascimento 472	\N	\N	2024-07-11	472	472
26983	Pessoa473	Sobrenome473	2023-03-26	Local de Nascimento 473	\N	\N	2024-07-11	473	473
26985	Pessoa474	Sobrenome474	2023-03-25	Local de Nascimento 474	\N	\N	2024-07-11	474	474
26987	Pessoa475	Sobrenome475	2023-03-24	Local de Nascimento 475	\N	\N	2024-07-11	475	475
26989	Pessoa476	Sobrenome476	2023-03-23	Local de Nascimento 476	\N	\N	2024-07-11	476	476
26991	Pessoa477	Sobrenome477	2023-03-22	Local de Nascimento 477	\N	\N	2024-07-11	477	477
26993	Pessoa478	Sobrenome478	2023-03-21	Local de Nascimento 478	\N	\N	2024-07-11	478	478
26995	Pessoa479	Sobrenome479	2023-03-20	Local de Nascimento 479	\N	\N	2024-07-11	479	479
26997	Pessoa480	Sobrenome480	2023-03-19	Local de Nascimento 480	\N	\N	2024-07-11	480	480
26999	Pessoa481	Sobrenome481	2023-03-18	Local de Nascimento 481	\N	\N	2024-07-11	481	481
27001	Pessoa482	Sobrenome482	2023-03-17	Local de Nascimento 482	\N	\N	2024-07-11	482	482
27003	Pessoa483	Sobrenome483	2023-03-16	Local de Nascimento 483	\N	\N	2024-07-11	483	483
27005	Pessoa484	Sobrenome484	2023-03-15	Local de Nascimento 484	\N	\N	2024-07-11	484	484
27007	Pessoa485	Sobrenome485	2023-03-14	Local de Nascimento 485	\N	\N	2024-07-11	485	485
27009	Pessoa486	Sobrenome486	2023-03-13	Local de Nascimento 486	\N	\N	2024-07-11	486	486
27011	Pessoa487	Sobrenome487	2023-03-12	Local de Nascimento 487	\N	\N	2024-07-11	487	487
27013	Pessoa488	Sobrenome488	2023-03-11	Local de Nascimento 488	\N	\N	2024-07-11	488	488
27015	Pessoa489	Sobrenome489	2023-03-10	Local de Nascimento 489	\N	\N	2024-07-11	489	489
27017	Pessoa490	Sobrenome490	2023-03-09	Local de Nascimento 490	\N	\N	2024-07-11	490	490
27019	Pessoa491	Sobrenome491	2023-03-08	Local de Nascimento 491	\N	\N	2024-07-11	491	491
27021	Pessoa492	Sobrenome492	2023-03-07	Local de Nascimento 492	\N	\N	2024-07-11	492	492
27023	Pessoa493	Sobrenome493	2023-03-06	Local de Nascimento 493	\N	\N	2024-07-11	493	493
27025	Pessoa494	Sobrenome494	2023-03-05	Local de Nascimento 494	\N	\N	2024-07-11	494	494
27027	Pessoa495	Sobrenome495	2023-03-04	Local de Nascimento 495	\N	\N	2024-07-11	495	495
27029	Pessoa496	Sobrenome496	2023-03-03	Local de Nascimento 496	\N	\N	2024-07-11	496	496
27031	Pessoa497	Sobrenome497	2023-03-02	Local de Nascimento 497	\N	\N	2024-07-11	497	497
27033	Pessoa498	Sobrenome498	2023-03-01	Local de Nascimento 498	\N	\N	2024-07-11	498	498
27035	Pessoa499	Sobrenome499	2023-02-28	Local de Nascimento 499	\N	\N	2024-07-11	499	499
27037	Pessoa500	Sobrenome500	2023-02-27	Local de Nascimento 500	\N	\N	2024-07-11	500	500
\.


--
-- Data for Name: relacionamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.relacionamento (id_relacionamento, id_pessoa_1, id_pessoa_2, dt_inicio, dt_fim, tipo_relacionamento) FROM stdin;
40	19	18	2060-01-01	\N	Filho(a)
45	21	22	2075-01-01	\N	Pai
46	22	21	2075-01-01	\N	Filho(a)
47	22	23	2080-01-01	\N	Pai
48	23	22	2080-01-01	\N	Filho(a)
49	23	24	2085-01-01	\N	Pai
50	24	23	2085-01-01	\N	Filho(a)
51	24	25	2090-01-01	\N	Pai
52	25	24	2090-01-01	\N	Filho(a)
55	8	11	2020-01-01	\N	Mãe
56	11	8	2020-01-01	\N	Filho(a)
61	14	17	2050-01-01	\N	Mãe
62	17	14	2050-01-01	\N	Filho(a)
63	15	18	2055-01-01	\N	Mãe
64	18	15	2055-01-01	\N	Filho(a)
65	19	22	2075-01-01	\N	Mãe
66	22	19	2075-01-01	\N	Filho(a)
69	21	24	2085-01-01	\N	Mãe
70	24	21	2085-01-01	\N	Filho(a)
75	14	15	2040-01-01	\N	Irmã(o)
76	15	14	2040-01-01	\N	Irmã(o)
77	16	17	2050-01-01	\N	Irmã(o)
78	17	16	2050-01-01	\N	Irmã(o)
79	18	19	2060-01-01	\N	Irmã(o)
80	19	18	2060-01-01	\N	Irmã(o)
83	22	23	2080-01-01	\N	Irmã(o)
84	23	22	2080-01-01	\N	Irmã(o)
85	24	25	2090-01-01	\N	Irmã(o)
86	25	24	2090-01-01	\N	Irmã(o)
96	27341	31	2024-07-11	2024-07-11	Casado(a)
97	31	27341	2024-07-11	2024-07-11	Casado(a)
102	29	31	2024-07-11	2024-07-26	Casado(a)
103	31	29	2024-07-11	2024-07-26	Casado(a)
104	29	27365	2024-07-11	2024-07-26	Casado(a)
105	27365	29	2024-07-11	2024-07-26	Casado(a)
23	29	11	\N	\N	Pai
31	34	15	\N	\N	Pai
118	27067	26039	\N	\N	Casado(a)
119	26039	27067	\N	\N	Casado(a)
37	17	18	\N	\N	Irmã(o)
39	18	26233	\N	\N	Pai
120	30	27039	\N	\N	Irmã(o)
121	27039	30	\N	\N	Irmã(o)
\.


--
-- Name: tbl_transacoesregistradas_id_log_seq; Type: SEQUENCE SET; Schema: log_transacoes; Owner: postgres
--

SELECT pg_catalog.setval('log_transacoes.tbl_transacoesregistradas_id_log_seq', 27291, true);


--
-- Name: pessoa_id_pessoa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pessoa_id_pessoa_seq', 28045, true);


--
-- Name: relacionamento_id_relacionamento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.relacionamento_id_relacionamento_seq', 121, true);


--
-- Name: tbl_transacoesregistradas tbl_transacoesregistradas_pkey; Type: CONSTRAINT; Schema: log_transacoes; Owner: postgres
--

ALTER TABLE ONLY log_transacoes.tbl_transacoesregistradas
    ADD CONSTRAINT tbl_transacoesregistradas_pkey PRIMARY KEY (id_log);


--
-- Name: pessoa pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (id_pessoa);


--
-- Name: relacionamento relacionamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento
    ADD CONSTRAINT relacionamento_pkey PRIMARY KEY (id_relacionamento);


--
-- Name: pessoa trg_pessoa; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_pessoa AFTER INSERT OR DELETE OR UPDATE ON public.pessoa FOR EACH ROW EXECUTE FUNCTION log_transacoes.registrar_operacao_log();


--
-- Name: relacionamento trg_relacionamento; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_relacionamento AFTER INSERT OR DELETE OR UPDATE ON public.relacionamento FOR EACH ROW EXECUTE FUNCTION log_transacoes.registrar_operacao_log();


--
-- Name: relacionamento fk_id_pessoa_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento
    ADD CONSTRAINT fk_id_pessoa_1 FOREIGN KEY (id_pessoa_1) REFERENCES public.pessoa(id_pessoa);


--
-- Name: relacionamento fk_id_pessoa_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento
    ADD CONSTRAINT fk_id_pessoa_2 FOREIGN KEY (id_pessoa_2) REFERENCES public.pessoa(id_pessoa);


--
-- PostgreSQL database dump complete
--

