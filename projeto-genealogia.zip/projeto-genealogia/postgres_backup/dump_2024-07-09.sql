--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: log_transacoes; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA log_transacoes;


ALTER SCHEMA log_transacoes OWNER TO postgres;

--
-- Name: registrar_operacao_log(); Type: FUNCTION; Schema: log_transacoes; Owner: postgres
--

CREATE FUNCTION log_transacoes.registrar_operacao_log() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO LOG_TRANSACOES.tbl_TransacoesRegistradas (
            nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_novos
        ) VALUES (
            TG_TABLE_SCHEMA, TG_TABLE_NAME, 'INSERT', current_user, current_timestamp, row_to_json(NEW)
        );
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO LOG_TRANSACOES.tbl_TransacoesRegistradas (
            nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_antigos, dados_novos
        ) VALUES (
            TG_TABLE_SCHEMA, TG_TABLE_NAME, 'UPDATE', current_user, current_timestamp, row_to_json(OLD), row_to_json(NEW)
        );
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO LOG_TRANSACOES.tbl_TransacoesRegistradas (
            nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_antigos
        ) VALUES (
            TG_TABLE_SCHEMA, TG_TABLE_NAME, 'DELETE', current_user, current_timestamp, row_to_json(OLD)
        );
        RETURN OLD;
    END IF;
END;
$$;


ALTER FUNCTION log_transacoes.registrar_operacao_log() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_transacoesregistradas; Type: TABLE; Schema: log_transacoes; Owner: postgres
--

CREATE TABLE log_transacoes.tbl_transacoesregistradas (
    id_log integer NOT NULL,
    nome_esquema text NOT NULL,
    nome_tabela text NOT NULL,
    operacao text NOT NULL,
    nome_usuario text NOT NULL,
    hora_transacao timestamp without time zone NOT NULL,
    dados_antigos jsonb,
    dados_novos jsonb
);


ALTER TABLE log_transacoes.tbl_transacoesregistradas OWNER TO postgres;

--
-- Name: tbl_transacoesregistradas_id_log_seq; Type: SEQUENCE; Schema: log_transacoes; Owner: postgres
--

CREATE SEQUENCE log_transacoes.tbl_transacoesregistradas_id_log_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE log_transacoes.tbl_transacoesregistradas_id_log_seq OWNER TO postgres;

--
-- Name: tbl_transacoesregistradas_id_log_seq; Type: SEQUENCE OWNED BY; Schema: log_transacoes; Owner: postgres
--

ALTER SEQUENCE log_transacoes.tbl_transacoesregistradas_id_log_seq OWNED BY log_transacoes.tbl_transacoesregistradas.id_log;


--
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa (
    id_pessoa integer NOT NULL,
    nome character varying(100) NOT NULL,
    sobrenome character varying(100) NOT NULL,
    dt_nasc date NOT NULL,
    local_nasc character varying(255) NOT NULL,
    dt_obito date,
    dt_migracao date,
    dt_registro date,
    num_pagina integer,
    num_livro integer
);


ALTER TABLE public.pessoa OWNER TO postgres;

--
-- Name: pessoa_id_pessoa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pessoa_id_pessoa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pessoa_id_pessoa_seq OWNER TO postgres;

--
-- Name: pessoa_id_pessoa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pessoa_id_pessoa_seq OWNED BY public.pessoa.id_pessoa;


--
-- Name: relacionamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.relacionamento (
    id_relacionamento integer NOT NULL,
    id_pessoa_1 integer NOT NULL,
    id_pessoa_2 integer NOT NULL,
    dt_inicio date,
    dt_fim date,
    tipo_relacionamento character varying(20) DEFAULT 'Pai'::character varying NOT NULL,
    CONSTRAINT relacionamento_tipo_relacionamento_check CHECK (((tipo_relacionamento)::text = ANY ((ARRAY['Pai'::character varying, 'Mãe'::character varying, 'Filho(a)'::character varying, 'Irmã(o)'::character varying])::text[])))
);


ALTER TABLE public.relacionamento OWNER TO postgres;

--
-- Name: relacionamento_id_relacionamento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.relacionamento_id_relacionamento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.relacionamento_id_relacionamento_seq OWNER TO postgres;

--
-- Name: relacionamento_id_relacionamento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.relacionamento_id_relacionamento_seq OWNED BY public.relacionamento.id_relacionamento;


--
-- Name: tbl_transacoesregistradas id_log; Type: DEFAULT; Schema: log_transacoes; Owner: postgres
--

ALTER TABLE ONLY log_transacoes.tbl_transacoesregistradas ALTER COLUMN id_log SET DEFAULT nextval('log_transacoes.tbl_transacoesregistradas_id_log_seq'::regclass);


--
-- Name: pessoa id_pessoa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa ALTER COLUMN id_pessoa SET DEFAULT nextval('public.pessoa_id_pessoa_seq'::regclass);


--
-- Name: relacionamento id_relacionamento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento ALTER COLUMN id_relacionamento SET DEFAULT nextval('public.relacionamento_id_relacionamento_seq'::regclass);


--
-- Data for Name: tbl_transacoesregistradas; Type: TABLE DATA; Schema: log_transacoes; Owner: postgres
--

COPY log_transacoes.tbl_transacoesregistradas (id_log, nome_esquema, nome_tabela, operacao, nome_usuario, hora_transacao, dados_antigos, dados_novos) FROM stdin;
1	public	livro	DELETE	postgres	2024-06-14 17:10:21.239553	{"id_livro": 5, "num_livro": 1}	\N
2	public	livro	INSERT	postgres	2024-06-14 17:12:28.708917	\N	{"id_livro": 10, "num_livro": 10}
3	public	livro	UPDATE	postgres	2024-06-14 17:12:59.303775	{"id_livro": 10, "num_livro": 10}	{"id_livro": 10, "num_livro": 11}
4	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Relação de paternidade", "cod_tabela": 1, "item_tabela": "1", "id_tab_estruturada": 2}	\N
5	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Relação de maternidade", "cod_tabela": 1, "item_tabela": "2", "id_tab_estruturada": 3}	\N
6	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Relação de filiação", "cod_tabela": 1, "item_tabela": "3", "id_tab_estruturada": 4}	\N
7	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Relação de irmandade", "cod_tabela": 1, "item_tabela": "4", "id_tab_estruturada": 5}	\N
8	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Descrição 1", "cod_tabela": 1, "item_tabela": "2", "id_tab_estruturada": 6}	\N
9	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Descrição 1", "cod_tabela": 1, "item_tabela": "2", "id_tab_estruturada": 7}	\N
10	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Descrição 1", "cod_tabela": 1, "item_tabela": "2", "id_tab_estruturada": 8}	\N
11	public	tab_estruturada	DELETE	postgres	2024-06-17 09:10:15.062689	{"descricao": "Descrição 1", "cod_tabela": 1, "item_tabela": "2", "id_tab_estruturada": 9}	\N
12	public	tab_estruturada	INSERT	postgres	2024-06-17 09:10:40.674331	\N	{"descricao": "Casamento", "cod_tabela": 1, "item_tabela": "1", "id_tab_estruturada": 10}
13	public	tab_estruturada	INSERT	postgres	2024-06-17 09:10:55.118987	\N	{"descricao": "Mãe", "cod_tabela": 1, "item_tabela": "1", "id_tab_estruturada": 11}
14	public	tab_estruturada	DELETE	postgres	2024-06-17 09:11:24.03	{"descricao": "Mãe", "cod_tabela": 1, "item_tabela": "1", "id_tab_estruturada": 11}	\N
15	public	tab_estruturada	INSERT	postgres	2024-06-17 09:11:29.845392	\N	{"descricao": "Mãe", "cod_tabela": 1, "item_tabela": "2", "id_tab_estruturada": 12}
16	public	tab_estruturada	INSERT	postgres	2024-06-17 09:11:36.40775	\N	{"descricao": "Pai", "cod_tabela": 1, "item_tabela": "3", "id_tab_estruturada": 13}
17	public	tab_estruturada	INSERT	postgres	2024-06-17 09:12:17.777537	\N	{"descricao": "Irmão", "cod_tabela": 1, "item_tabela": "4", "id_tab_estruturada": 14}
18	public	tab_estruturada	INSERT	postgres	2024-06-17 09:12:23.660528	\N	{"descricao": "Irmã", "cod_tabela": 1, "item_tabela": "5", "id_tab_estruturada": 15}
19	public	tab_estruturada	INSERT	postgres	2024-06-17 09:12:32.570801	\N	{"descricao": "Avó", "cod_tabela": 1, "item_tabela": "6", "id_tab_estruturada": 16}
20	public	tab_estruturada	INSERT	postgres	2024-06-17 09:12:38.058727	\N	{"descricao": "Avô", "cod_tabela": 1, "item_tabela": "7", "id_tab_estruturada": 17}
21	public	tab_estruturada	INSERT	postgres	2024-06-17 09:12:44.450842	\N	{"descricao": "Tio", "cod_tabela": 1, "item_tabela": "8", "id_tab_estruturada": 18}
22	public	tab_estruturada	INSERT	postgres	2024-06-17 09:12:49.906131	\N	{"descricao": "Tia", "cod_tabela": 1, "item_tabela": "9", "id_tab_estruturada": 19}
23	public	pessoa	INSERT	postgres	2024-06-17 09:16:29.54338	\N	{"nome": "João", "dt_nasc": "1980-05-15", "dt_obito": null, "id_pessoa": 2, "num_livro": 3, "sobrenome": "Silva", "local_nasc": "São Paulo", "num_pagina": 1, "dt_migracao": "2000-01-01", "dt_registro": "2000-01-10"}
24	public	pessoa	INSERT	postgres	2024-06-17 09:16:29.54338	\N	{"nome": "Maria", "dt_nasc": "1985-08-25", "dt_obito": null, "id_pessoa": 3, "num_livro": 3, "sobrenome": "Oliveira", "local_nasc": "Rio de Janeiro", "num_pagina": 1, "dt_migracao": "2005-02-01", "dt_registro": "2005-02-15"}
25	public	relacionamento	INSERT	postgres	2024-06-17 09:17:16.463015	\N	{"dt_fim": "2023-12-31", "dt_inicio": "2023-01-01", "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 1, "tipo_relacionamento_tab": "1", "tipo_relacionamento_item": "1"}
26	public	relacionamento	DELETE	postgres	2024-06-17 09:22:50.633286	{"dt_fim": "2023-12-31", "dt_inicio": "2023-01-01", "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 1}	\N
27	public	relacionamento	INSERT	postgres	2024-06-17 09:23:34.472647	\N	{"dt_fim": "2023-12-31", "dt_inicio": "2023-01-01", "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 3, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
28	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:25:36.676835	{"descricao": "Tipos de relacionamentos", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 1}	{"descricao": "Tipos de relacionamentos", "cod_tabela": 1, "item_tabela": 0, "id_tab_estruturada": 1}
29	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:26:34.459936	{"descricao": "Casamento", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 10}	{"descricao": "Casamento", "cod_tabela": 1, "item_tabela": 9, "id_tab_estruturada": 10}
30	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:27:04.33849	{"descricao": "Tipos de relacionamentos", "cod_tabela": 1, "item_tabela": 0, "id_tab_estruturada": 1}	{"descricao": "Tipos de relacionamentos", "cod_tabela": 1, "item_tabela": 10, "id_tab_estruturada": 1}
31	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:27:27.667108	{"descricao": "Tipos de relacionamentos", "cod_tabela": 1, "item_tabela": 10, "id_tab_estruturada": 1}	{"descricao": "Tipos de relacionamentos", "cod_tabela": 1, "item_tabela": 0, "id_tab_estruturada": 1}
32	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:27:40.95194	{"descricao": "Casamento", "cod_tabela": 1, "item_tabela": 9, "id_tab_estruturada": 10}	{"descricao": "Casamento", "cod_tabela": 1, "item_tabela": 1, "id_tab_estruturada": 10}
33	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:27:52.438877	{"descricao": "Mãe", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 12}	{"descricao": "Mãe", "cod_tabela": 1, "item_tabela": 2, "id_tab_estruturada": 12}
34	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:28:04.500815	{"descricao": "Pai", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 13}	{"descricao": "Pai", "cod_tabela": 1, "item_tabela": 3, "id_tab_estruturada": 13}
35	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:28:12.277489	{"descricao": "Irmão", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 14}	{"descricao": "Irmão", "cod_tabela": 1, "item_tabela": 4, "id_tab_estruturada": 14}
36	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:28:24.06399	{"descricao": "Irmã", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 15}	{"descricao": "Irmã", "cod_tabela": 1, "item_tabela": 5, "id_tab_estruturada": 15}
37	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:28:36.403954	{"descricao": "Avó", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 16}	{"descricao": "Avó", "cod_tabela": 1, "item_tabela": 6, "id_tab_estruturada": 16}
38	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:28:44.584577	{"descricao": "Avô", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 17}	{"descricao": "Avô", "cod_tabela": 1, "item_tabela": 7, "id_tab_estruturada": 17}
39	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:28:52.436107	{"descricao": "Tio", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 18}	{"descricao": "Tio", "cod_tabela": 1, "item_tabela": 8, "id_tab_estruturada": 18}
40	public	tab_estruturada	UPDATE	postgres	2024-06-17 09:28:57.035081	{"descricao": "Tia", "cod_tabela": 1, "item_tabela": null, "id_tab_estruturada": 19}	{"descricao": "Tia", "cod_tabela": 1, "item_tabela": 9, "id_tab_estruturada": 19}
41	public	pessoa	INSERT	postgres	2024-06-17 10:55:42.513097	\N	{"nome": "Carlos", "dt_nasc": "1985-03-12", "dt_obito": null, "id_pessoa": 4, "num_livro": 1, "sobrenome": "Pereira", "local_nasc": "Belo Horizonte", "num_pagina": 10, "dt_migracao": null, "dt_registro": "2024-06-17"}
42	public	pessoa	INSERT	postgres	2024-06-17 10:55:53.706582	\N	{"nome": "Ana", "dt_nasc": "1990-09-25", "dt_obito": null, "id_pessoa": 5, "num_livro": 1, "sobrenome": "Souza", "local_nasc": "Curitiba", "num_pagina": 20, "dt_migracao": null, "dt_registro": "2024-06-17"}
43	public	relacionamento	INSERT	postgres	2024-06-17 10:57:12.749225	\N	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 4, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
44	public	relacionamento	INSERT	postgres	2024-06-17 10:57:12.767534	\N	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 5, "id_pessoa_2": 4, "id_relacionamento": 5, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
45	public	relacionamento	INSERT	postgres	2024-06-17 11:08:16.302952	\N	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 6, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
46	public	relacionamento	DELETE	postgres	2024-06-17 11:08:54.106509	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 6, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}	\N
47	public	relacionamento	DELETE	postgres	2024-06-17 11:14:33.319225	{"dt_fim": "2023-12-31", "dt_inicio": "2023-01-01", "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 3, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}	\N
48	public	relacionamento	DELETE	postgres	2024-06-17 11:14:33.319225	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 4, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}	\N
49	public	relacionamento	DELETE	postgres	2024-06-17 11:14:33.319225	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 5, "id_pessoa_2": 4, "id_relacionamento": 5, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}	\N
50	public	relacionamento	INSERT	postgres	2024-06-17 11:14:48.318565	\N	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 7, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
51	public	relacionamento	INSERT	postgres	2024-06-17 11:14:48.325306	\N	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 5, "id_pessoa_2": 4, "id_relacionamento": 8, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
52	public	relacionamento	INSERT	postgres	2024-06-17 11:35:48.76888	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 9, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 3}
53	public	relacionamento	INSERT	postgres	2024-06-17 11:35:48.775738	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 3, "id_pessoa_2": 2, "id_relacionamento": 10, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 3}
54	public	relacionamento	DELETE	postgres	2024-06-17 11:37:31.533352	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 9, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 3}	\N
55	public	relacionamento	DELETE	postgres	2024-06-17 11:37:31.533352	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 3, "id_pessoa_2": 2, "id_relacionamento": 10, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 3}	\N
56	public	relacionamento	INSERT	postgres	2024-06-17 11:37:44.047618	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 11, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 3}
57	public	relacionamento	DELETE	postgres	2024-06-17 11:37:56.782164	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 11, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 3}	\N
58	public	relacionamento	INSERT	postgres	2024-06-17 11:38:17.373734	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 12, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
59	public	relacionamento	INSERT	postgres	2024-06-17 11:38:17.380303	\N	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 3, "id_pessoa_2": 2, "id_relacionamento": 13, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
60	public	relacionamento	DELETE	postgres	2024-06-17 13:10:27.504882	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 12, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}	\N
61	public	relacionamento	DELETE	postgres	2024-06-17 13:10:27.53228	{"dt_fim": null, "dt_inicio": null, "id_pessoa_1": 3, "id_pessoa_2": 2, "id_relacionamento": 13, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}	\N
62	public	relacionamento	INSERT	postgres	2024-06-25 15:33:11.984716	\N	{"dt_fim": "2024-06-25", "dt_inicio": "2024-06-25", "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 14, "tipo_relacionamento_tab": 1, "tipo_relacionamento_item": 1}
63	public	pessoa	UPDATE	postgres	2024-07-04 11:02:17.868964	{"nome": "João", "dt_nasc": "1980-05-15", "dt_obito": null, "id_pessoa": 2, "num_livro": 3, "sobrenome": "Silva", "local_nasc": "São Paulo", "num_pagina": 1, "dt_migracao": "2000-01-01", "dt_registro": "2000-01-10"}	{"nome": "João", "dt_nasc": "1980-05-15", "dt_obito": null, "id_pessoa": 2, "num_livro": 3, "sobrenome": "Marques", "local_nasc": "São Paulo", "num_pagina": 1, "dt_migracao": "2000-01-01", "dt_registro": "2000-01-10"}
64	public	relacionamento	UPDATE	postgres	2024-07-04 11:03:12.332639	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 7, "tipo_relacionamento": "Pai"}	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 7, "tipo_relacionamento": "Mãe"}
65	public	relacionamento	UPDATE	postgres	2024-07-09 10:34:53.902738	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 7, "tipo_relacionamento": "Mãe"}	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 7, "tipo_relacionamento": "Filho(a)"}
66	public	relacionamento	DELETE	postgres	2024-07-09 10:44:06.30254	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 5, "id_pessoa_2": 4, "id_relacionamento": 8, "tipo_relacionamento": "Pai"}	\N
67	public	relacionamento	DELETE	postgres	2024-07-09 10:44:06.345765	{"dt_fim": "2024-01-01", "dt_inicio": "2023-01-01", "id_pessoa_1": 4, "id_pessoa_2": 5, "id_relacionamento": 7, "tipo_relacionamento": "Filho(a)"}	\N
68	public	pessoa	DELETE	postgres	2024-07-09 10:44:06.349725	{"nome": "Ana", "dt_nasc": "1990-09-25", "dt_obito": null, "id_pessoa": 5, "num_livro": 1, "sobrenome": "Souza", "local_nasc": "Curitiba", "num_pagina": 20, "dt_migracao": null, "dt_registro": "2024-06-17"}	\N
69	public	relacionamento	DELETE	postgres	2024-07-09 10:44:47.032582	{"dt_fim": "2024-06-25", "dt_inicio": "2024-06-25", "id_pessoa_1": 2, "id_pessoa_2": 3, "id_relacionamento": 14, "tipo_relacionamento": "Pai"}	\N
70	public	pessoa	DELETE	postgres	2024-07-09 10:44:47.073452	{"nome": "João", "dt_nasc": "1980-05-15", "dt_obito": null, "id_pessoa": 2, "num_livro": 3, "sobrenome": "Marques", "local_nasc": "São Paulo", "num_pagina": 1, "dt_migracao": "2000-01-01", "dt_registro": "2000-01-10"}	\N
71	public	pessoa	DELETE	postgres	2024-07-09 10:46:33.297344	{"nome": "Carlos", "dt_nasc": "1985-03-12", "dt_obito": null, "id_pessoa": 4, "num_livro": 1, "sobrenome": "Pereira", "local_nasc": "Belo Horizonte", "num_pagina": 10, "dt_migracao": null, "dt_registro": "2024-06-17"}	\N
72	public	pessoa	DELETE	postgres	2024-07-09 10:52:01.822287	{"nome": "Maria", "dt_nasc": "1985-08-25", "dt_obito": null, "id_pessoa": 3, "num_livro": 3, "sobrenome": "Oliveira", "local_nasc": "Rio de Janeiro", "num_pagina": 1, "dt_migracao": "2005-02-01", "dt_registro": "2005-02-15"}	\N
73	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "João", "dt_nasc": "1990-05-15", "dt_obito": null, "id_pessoa": 6, "num_livro": 1, "sobrenome": "Silva", "local_nasc": "São Paulo", "num_pagina": 1, "dt_migracao": "2023-01-01", "dt_registro": "2023-01-02"}
74	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Maria", "dt_nasc": "1985-08-20", "dt_obito": null, "id_pessoa": 7, "num_livro": 1, "sobrenome": "Santos", "local_nasc": "Rio de Janeiro", "num_pagina": 1, "dt_migracao": "2023-02-01", "dt_registro": "2023-02-02"}
75	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Pedro", "dt_nasc": "1978-03-10", "dt_obito": null, "id_pessoa": 8, "num_livro": 1, "sobrenome": "Souza", "local_nasc": "Brasília", "num_pagina": 1, "dt_migracao": "2023-03-01", "dt_registro": "2023-03-02"}
76	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Ana", "dt_nasc": "1995-12-25", "dt_obito": null, "id_pessoa": 9, "num_livro": 1, "sobrenome": "Oliveira", "local_nasc": "Salvador", "num_pagina": 1, "dt_migracao": "2023-04-01", "dt_registro": "2023-04-02"}
77	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Carlos", "dt_nasc": "1982-07-08", "dt_obito": null, "id_pessoa": 10, "num_livro": 1, "sobrenome": "Ferreira", "local_nasc": "Porto Alegre", "num_pagina": 1, "dt_migracao": "2023-05-01", "dt_registro": "2023-05-02"}
78	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Mariana", "dt_nasc": "1992-01-30", "dt_obito": null, "id_pessoa": 11, "num_livro": 1, "sobrenome": "Costa", "local_nasc": "Curitiba", "num_pagina": 1, "dt_migracao": "2023-06-01", "dt_registro": "2023-06-02"}
79	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "José", "dt_nasc": "1987-09-18", "dt_obito": null, "id_pessoa": 12, "num_livro": 1, "sobrenome": "Rodrigues", "local_nasc": "Recife", "num_pagina": 1, "dt_migracao": "2023-07-01", "dt_registro": "2023-07-02"}
80	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Aline", "dt_nasc": "1980-06-12", "dt_obito": null, "id_pessoa": 13, "num_livro": 1, "sobrenome": "Almeida", "local_nasc": "Manaus", "num_pagina": 1, "dt_migracao": "2023-08-01", "dt_registro": "2023-08-02"}
81	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Fernando", "dt_nasc": "1975-04-05", "dt_obito": null, "id_pessoa": 14, "num_livro": 1, "sobrenome": "Gomes", "local_nasc": "Belém", "num_pagina": 1, "dt_migracao": "2023-09-01", "dt_registro": "2023-09-02"}
82	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Isabela", "dt_nasc": "1998-11-03", "dt_obito": null, "id_pessoa": 15, "num_livro": 1, "sobrenome": "Martins", "local_nasc": "Florianópolis", "num_pagina": 1, "dt_migracao": "2023-10-01", "dt_registro": "2023-10-02"}
83	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Rafael", "dt_nasc": "1989-02-28", "dt_obito": null, "id_pessoa": 16, "num_livro": 1, "sobrenome": "Rocha", "local_nasc": "Natal", "num_pagina": 1, "dt_migracao": "2023-11-01", "dt_registro": "2023-11-02"}
84	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Luciana", "dt_nasc": "1983-10-17", "dt_obito": null, "id_pessoa": 17, "num_livro": 1, "sobrenome": "Pereira", "local_nasc": "Fortaleza", "num_pagina": 1, "dt_migracao": "2023-12-01", "dt_registro": "2023-12-02"}
85	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Marcos", "dt_nasc": "1993-07-07", "dt_obito": null, "id_pessoa": 18, "num_livro": 1, "sobrenome": "Lima", "local_nasc": "Vitória", "num_pagina": 1, "dt_migracao": "2024-01-01", "dt_registro": "2024-01-02"}
86	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Sandra", "dt_nasc": "1979-09-22", "dt_obito": null, "id_pessoa": 19, "num_livro": 1, "sobrenome": "Ramos", "local_nasc": "João Pessoa", "num_pagina": 1, "dt_migracao": "2024-02-01", "dt_registro": "2024-02-02"}
87	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Antônio", "dt_nasc": "1986-04-14", "dt_obito": null, "id_pessoa": 20, "num_livro": 1, "sobrenome": "Barbosa", "local_nasc": "Campo Grande", "num_pagina": 1, "dt_migracao": "2024-03-01", "dt_registro": "2024-03-02"}
88	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Patrícia", "dt_nasc": "1991-08-08", "dt_obito": null, "id_pessoa": 21, "num_livro": 1, "sobrenome": "Cavalcanti", "local_nasc": "Teresina", "num_pagina": 1, "dt_migracao": "2024-04-01", "dt_registro": "2024-04-02"}
89	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Paulo", "dt_nasc": "1977-12-01", "dt_obito": null, "id_pessoa": 22, "num_livro": 1, "sobrenome": "Freitas", "local_nasc": "Cuiabá", "num_pagina": 1, "dt_migracao": "2024-05-01", "dt_registro": "2024-05-02"}
90	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Juliana", "dt_nasc": "1984-05-19", "dt_obito": null, "id_pessoa": 23, "num_livro": 1, "sobrenome": "Nunes", "local_nasc": "Porto Velho", "num_pagina": 1, "dt_migracao": "2024-06-01", "dt_registro": "2024-06-02"}
91	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Gustavo", "dt_nasc": "1996-03-09", "dt_obito": null, "id_pessoa": 24, "num_livro": 1, "sobrenome": "Mendes", "local_nasc": "Macapá", "num_pagina": 1, "dt_migracao": "2024-07-01", "dt_registro": "2024-07-02"}
92	public	pessoa	INSERT	postgres	2024-07-09 11:01:59.294715	\N	{"nome": "Cristina", "dt_nasc": "1981-11-11", "dt_obito": null, "id_pessoa": 25, "num_livro": 1, "sobrenome": "Dias", "local_nasc": "Boa Vista", "num_pagina": 1, "dt_migracao": "2024-08-01", "dt_registro": "2024-08-02"}
93	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2000-01-01", "id_pessoa_1": 6, "id_pessoa_2": 7, "id_relacionamento": 15, "tipo_relacionamento": "Pai"}
94	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2000-01-01", "id_pessoa_1": 7, "id_pessoa_2": 6, "id_relacionamento": 16, "tipo_relacionamento": "Filho(a)"}
95	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2005-01-01", "id_pessoa_1": 7, "id_pessoa_2": 8, "id_relacionamento": 17, "tipo_relacionamento": "Pai"}
96	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2005-01-01", "id_pessoa_1": 8, "id_pessoa_2": 7, "id_relacionamento": 18, "tipo_relacionamento": "Filho(a)"}
97	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2010-01-01", "id_pessoa_1": 8, "id_pessoa_2": 9, "id_relacionamento": 19, "tipo_relacionamento": "Pai"}
98	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2010-01-01", "id_pessoa_1": 9, "id_pessoa_2": 8, "id_relacionamento": 20, "tipo_relacionamento": "Filho(a)"}
99	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2015-01-01", "id_pessoa_1": 9, "id_pessoa_2": 10, "id_relacionamento": 21, "tipo_relacionamento": "Pai"}
100	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2015-01-01", "id_pessoa_1": 10, "id_pessoa_2": 9, "id_relacionamento": 22, "tipo_relacionamento": "Filho(a)"}
101	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 10, "id_pessoa_2": 11, "id_relacionamento": 23, "tipo_relacionamento": "Pai"}
102	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 11, "id_pessoa_2": 10, "id_relacionamento": 24, "tipo_relacionamento": "Filho(a)"}
103	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 11, "id_pessoa_2": 12, "id_relacionamento": 25, "tipo_relacionamento": "Pai"}
104	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 12, "id_pessoa_2": 11, "id_relacionamento": 26, "tipo_relacionamento": "Filho(a)"}
105	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2030-01-01", "id_pessoa_1": 12, "id_pessoa_2": 13, "id_relacionamento": 27, "tipo_relacionamento": "Pai"}
106	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2030-01-01", "id_pessoa_1": 13, "id_pessoa_2": 12, "id_relacionamento": 28, "tipo_relacionamento": "Filho(a)"}
107	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2035-01-01", "id_pessoa_1": 13, "id_pessoa_2": 14, "id_relacionamento": 29, "tipo_relacionamento": "Pai"}
108	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2035-01-01", "id_pessoa_1": 14, "id_pessoa_2": 13, "id_relacionamento": 30, "tipo_relacionamento": "Filho(a)"}
109	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2040-01-01", "id_pessoa_1": 14, "id_pessoa_2": 15, "id_relacionamento": 31, "tipo_relacionamento": "Pai"}
110	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2040-01-01", "id_pessoa_1": 15, "id_pessoa_2": 14, "id_relacionamento": 32, "tipo_relacionamento": "Filho(a)"}
111	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2045-01-01", "id_pessoa_1": 15, "id_pessoa_2": 16, "id_relacionamento": 33, "tipo_relacionamento": "Pai"}
112	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2045-01-01", "id_pessoa_1": 16, "id_pessoa_2": 15, "id_relacionamento": 34, "tipo_relacionamento": "Filho(a)"}
113	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 16, "id_pessoa_2": 17, "id_relacionamento": 35, "tipo_relacionamento": "Pai"}
114	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 17, "id_pessoa_2": 16, "id_relacionamento": 36, "tipo_relacionamento": "Filho(a)"}
115	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2055-01-01", "id_pessoa_1": 17, "id_pessoa_2": 18, "id_relacionamento": 37, "tipo_relacionamento": "Pai"}
116	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2055-01-01", "id_pessoa_1": 18, "id_pessoa_2": 17, "id_relacionamento": 38, "tipo_relacionamento": "Filho(a)"}
117	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2060-01-01", "id_pessoa_1": 18, "id_pessoa_2": 19, "id_relacionamento": 39, "tipo_relacionamento": "Pai"}
118	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2060-01-01", "id_pessoa_1": 19, "id_pessoa_2": 18, "id_relacionamento": 40, "tipo_relacionamento": "Filho(a)"}
119	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2065-01-01", "id_pessoa_1": 19, "id_pessoa_2": 20, "id_relacionamento": 41, "tipo_relacionamento": "Pai"}
120	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2065-01-01", "id_pessoa_1": 20, "id_pessoa_2": 19, "id_relacionamento": 42, "tipo_relacionamento": "Filho(a)"}
121	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 20, "id_pessoa_2": 21, "id_relacionamento": 43, "tipo_relacionamento": "Pai"}
122	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 21, "id_pessoa_2": 20, "id_relacionamento": 44, "tipo_relacionamento": "Filho(a)"}
123	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2075-01-01", "id_pessoa_1": 21, "id_pessoa_2": 22, "id_relacionamento": 45, "tipo_relacionamento": "Pai"}
124	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2075-01-01", "id_pessoa_1": 22, "id_pessoa_2": 21, "id_relacionamento": 46, "tipo_relacionamento": "Filho(a)"}
125	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 22, "id_pessoa_2": 23, "id_relacionamento": 47, "tipo_relacionamento": "Pai"}
126	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 23, "id_pessoa_2": 22, "id_relacionamento": 48, "tipo_relacionamento": "Filho(a)"}
127	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2085-01-01", "id_pessoa_1": 23, "id_pessoa_2": 24, "id_relacionamento": 49, "tipo_relacionamento": "Pai"}
128	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2085-01-01", "id_pessoa_1": 24, "id_pessoa_2": 23, "id_relacionamento": 50, "tipo_relacionamento": "Filho(a)"}
129	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2090-01-01", "id_pessoa_1": 24, "id_pessoa_2": 25, "id_relacionamento": 51, "tipo_relacionamento": "Pai"}
130	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2090-01-01", "id_pessoa_1": 25, "id_pessoa_2": 24, "id_relacionamento": 52, "tipo_relacionamento": "Filho(a)"}
131	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2005-01-01", "id_pessoa_1": 7, "id_pessoa_2": 10, "id_relacionamento": 53, "tipo_relacionamento": "Mãe"}
132	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2005-01-01", "id_pessoa_1": 10, "id_pessoa_2": 7, "id_relacionamento": 54, "tipo_relacionamento": "Filho(a)"}
133	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 8, "id_pessoa_2": 11, "id_relacionamento": 55, "tipo_relacionamento": "Mãe"}
134	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 11, "id_pessoa_2": 8, "id_relacionamento": 56, "tipo_relacionamento": "Filho(a)"}
135	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 9, "id_pessoa_2": 12, "id_relacionamento": 57, "tipo_relacionamento": "Mãe"}
136	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2025-01-01", "id_pessoa_1": 12, "id_pessoa_2": 9, "id_relacionamento": 58, "tipo_relacionamento": "Filho(a)"}
137	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2045-01-01", "id_pessoa_1": 13, "id_pessoa_2": 16, "id_relacionamento": 59, "tipo_relacionamento": "Mãe"}
138	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2045-01-01", "id_pessoa_1": 16, "id_pessoa_2": 13, "id_relacionamento": 60, "tipo_relacionamento": "Filho(a)"}
139	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 14, "id_pessoa_2": 17, "id_relacionamento": 61, "tipo_relacionamento": "Mãe"}
140	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 17, "id_pessoa_2": 14, "id_relacionamento": 62, "tipo_relacionamento": "Filho(a)"}
141	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2055-01-01", "id_pessoa_1": 15, "id_pessoa_2": 18, "id_relacionamento": 63, "tipo_relacionamento": "Mãe"}
142	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2055-01-01", "id_pessoa_1": 18, "id_pessoa_2": 15, "id_relacionamento": 64, "tipo_relacionamento": "Filho(a)"}
143	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2075-01-01", "id_pessoa_1": 19, "id_pessoa_2": 22, "id_relacionamento": 65, "tipo_relacionamento": "Mãe"}
144	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2075-01-01", "id_pessoa_1": 22, "id_pessoa_2": 19, "id_relacionamento": 66, "tipo_relacionamento": "Filho(a)"}
145	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 20, "id_pessoa_2": 23, "id_relacionamento": 67, "tipo_relacionamento": "Mãe"}
146	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 23, "id_pessoa_2": 20, "id_relacionamento": 68, "tipo_relacionamento": "Filho(a)"}
147	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2085-01-01", "id_pessoa_1": 21, "id_pessoa_2": 24, "id_relacionamento": 69, "tipo_relacionamento": "Mãe"}
148	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2085-01-01", "id_pessoa_1": 24, "id_pessoa_2": 21, "id_relacionamento": 70, "tipo_relacionamento": "Filho(a)"}
149	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 10, "id_pessoa_2": 11, "id_relacionamento": 71, "tipo_relacionamento": "Irmã(o)"}
150	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2020-01-01", "id_pessoa_1": 11, "id_pessoa_2": 10, "id_relacionamento": 72, "tipo_relacionamento": "Irmã(o)"}
151	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2030-01-01", "id_pessoa_1": 12, "id_pessoa_2": 13, "id_relacionamento": 73, "tipo_relacionamento": "Irmã(o)"}
152	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2030-01-01", "id_pessoa_1": 13, "id_pessoa_2": 12, "id_relacionamento": 74, "tipo_relacionamento": "Irmã(o)"}
153	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2040-01-01", "id_pessoa_1": 14, "id_pessoa_2": 15, "id_relacionamento": 75, "tipo_relacionamento": "Irmã(o)"}
154	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2040-01-01", "id_pessoa_1": 15, "id_pessoa_2": 14, "id_relacionamento": 76, "tipo_relacionamento": "Irmã(o)"}
155	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 16, "id_pessoa_2": 17, "id_relacionamento": 77, "tipo_relacionamento": "Irmã(o)"}
156	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2050-01-01", "id_pessoa_1": 17, "id_pessoa_2": 16, "id_relacionamento": 78, "tipo_relacionamento": "Irmã(o)"}
157	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2060-01-01", "id_pessoa_1": 18, "id_pessoa_2": 19, "id_relacionamento": 79, "tipo_relacionamento": "Irmã(o)"}
158	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2060-01-01", "id_pessoa_1": 19, "id_pessoa_2": 18, "id_relacionamento": 80, "tipo_relacionamento": "Irmã(o)"}
159	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 20, "id_pessoa_2": 21, "id_relacionamento": 81, "tipo_relacionamento": "Irmã(o)"}
160	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2070-01-01", "id_pessoa_1": 21, "id_pessoa_2": 20, "id_relacionamento": 82, "tipo_relacionamento": "Irmã(o)"}
161	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 22, "id_pessoa_2": 23, "id_relacionamento": 83, "tipo_relacionamento": "Irmã(o)"}
162	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2080-01-01", "id_pessoa_1": 23, "id_pessoa_2": 22, "id_relacionamento": 84, "tipo_relacionamento": "Irmã(o)"}
163	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2090-01-01", "id_pessoa_1": 24, "id_pessoa_2": 25, "id_relacionamento": 85, "tipo_relacionamento": "Irmã(o)"}
164	public	relacionamento	INSERT	postgres	2024-07-09 11:10:12.031025	\N	{"dt_fim": null, "dt_inicio": "2090-01-01", "id_pessoa_1": 25, "id_pessoa_2": 24, "id_relacionamento": 86, "tipo_relacionamento": "Irmã(o)"}
165	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Ricardo", "dt_nasc": "1980-05-15", "dt_obito": null, "id_pessoa": 26, "num_livro": 1, "sobrenome": "Silva", "local_nasc": "São Paulo", "num_pagina": 10, "dt_migracao": null, "dt_registro": "2024-07-10"}
166	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Amanda", "dt_nasc": "1982-09-20", "dt_obito": null, "id_pessoa": 27, "num_livro": 1, "sobrenome": "Santos", "local_nasc": "Rio de Janeiro", "num_pagina": 11, "dt_migracao": null, "dt_registro": "2024-07-10"}
167	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Felipe", "dt_nasc": "1975-03-10", "dt_obito": null, "id_pessoa": 28, "num_livro": 1, "sobrenome": "Oliveira", "local_nasc": "Belo Horizonte", "num_pagina": 12, "dt_migracao": null, "dt_registro": "2024-07-10"}
168	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Carolina", "dt_nasc": "1990-07-28", "dt_obito": null, "id_pessoa": 29, "num_livro": 1, "sobrenome": "Martins", "local_nasc": "Porto Alegre", "num_pagina": 13, "dt_migracao": null, "dt_registro": "2024-07-10"}
169	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Gustavo", "dt_nasc": "1987-01-12", "dt_obito": null, "id_pessoa": 30, "num_livro": 1, "sobrenome": "Pereira", "local_nasc": "Curitiba", "num_pagina": 14, "dt_migracao": null, "dt_registro": "2024-07-10"}
170	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Mariana", "dt_nasc": "1984-06-30", "dt_obito": null, "id_pessoa": 31, "num_livro": 1, "sobrenome": "Gomes", "local_nasc": "Salvador", "num_pagina": 15, "dt_migracao": null, "dt_registro": "2024-07-10"}
171	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Rodrigo", "dt_nasc": "1978-11-05", "dt_obito": null, "id_pessoa": 32, "num_livro": 1, "sobrenome": "Almeida", "local_nasc": "Fortaleza", "num_pagina": 16, "dt_migracao": null, "dt_registro": "2024-07-10"}
172	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Vanessa", "dt_nasc": "1983-04-17", "dt_obito": null, "id_pessoa": 33, "num_livro": 1, "sobrenome": "Ferreira", "local_nasc": "Recife", "num_pagina": 17, "dt_migracao": null, "dt_registro": "2024-07-10"}
173	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Fernando", "dt_nasc": "1995-08-25", "dt_obito": null, "id_pessoa": 34, "num_livro": 1, "sobrenome": "Mendes", "local_nasc": "Brasília", "num_pagina": 18, "dt_migracao": null, "dt_registro": "2024-07-10"}
174	public	pessoa	INSERT	postgres	2024-07-09 11:16:19.20452	\N	{"nome": "Patrícia", "dt_nasc": "1989-12-03", "dt_obito": null, "id_pessoa": 35, "num_livro": 1, "sobrenome": "Lima", "local_nasc": "Manaus", "num_pagina": 19, "dt_migracao": null, "dt_registro": "2024-07-10"}
175	public	relacionamento	DELETE	postgres	2024-07-09 11:34:37.621563	{"dt_fim": null, "dt_inicio": "2000-01-01", "id_pessoa_1": 6, "id_pessoa_2": 7, "id_relacionamento": 15, "tipo_relacionamento": "Pai"}	\N
176	public	relacionamento	DELETE	postgres	2024-07-09 11:34:37.663678	{"dt_fim": null, "dt_inicio": "2000-01-01", "id_pessoa_1": 7, "id_pessoa_2": 6, "id_relacionamento": 16, "tipo_relacionamento": "Filho(a)"}	\N
177	public	pessoa	DELETE	postgres	2024-07-09 11:34:37.668429	{"nome": "João", "dt_nasc": "1990-05-15", "dt_obito": null, "id_pessoa": 6, "num_livro": 1, "sobrenome": "Silva", "local_nasc": "São Paulo", "num_pagina": 1, "dt_migracao": "2023-01-01", "dt_registro": "2023-01-02"}	\N
\.


--
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pessoa (id_pessoa, nome, sobrenome, dt_nasc, local_nasc, dt_obito, dt_migracao, dt_registro, num_pagina, num_livro) FROM stdin;
7	Maria	Santos	1985-08-20	Rio de Janeiro	\N	2023-02-01	2023-02-02	1	1
8	Pedro	Souza	1978-03-10	Brasília	\N	2023-03-01	2023-03-02	1	1
9	Ana	Oliveira	1995-12-25	Salvador	\N	2023-04-01	2023-04-02	1	1
10	Carlos	Ferreira	1982-07-08	Porto Alegre	\N	2023-05-01	2023-05-02	1	1
11	Mariana	Costa	1992-01-30	Curitiba	\N	2023-06-01	2023-06-02	1	1
12	José	Rodrigues	1987-09-18	Recife	\N	2023-07-01	2023-07-02	1	1
13	Aline	Almeida	1980-06-12	Manaus	\N	2023-08-01	2023-08-02	1	1
14	Fernando	Gomes	1975-04-05	Belém	\N	2023-09-01	2023-09-02	1	1
15	Isabela	Martins	1998-11-03	Florianópolis	\N	2023-10-01	2023-10-02	1	1
16	Rafael	Rocha	1989-02-28	Natal	\N	2023-11-01	2023-11-02	1	1
17	Luciana	Pereira	1983-10-17	Fortaleza	\N	2023-12-01	2023-12-02	1	1
18	Marcos	Lima	1993-07-07	Vitória	\N	2024-01-01	2024-01-02	1	1
19	Sandra	Ramos	1979-09-22	João Pessoa	\N	2024-02-01	2024-02-02	1	1
20	Antônio	Barbosa	1986-04-14	Campo Grande	\N	2024-03-01	2024-03-02	1	1
21	Patrícia	Cavalcanti	1991-08-08	Teresina	\N	2024-04-01	2024-04-02	1	1
22	Paulo	Freitas	1977-12-01	Cuiabá	\N	2024-05-01	2024-05-02	1	1
23	Juliana	Nunes	1984-05-19	Porto Velho	\N	2024-06-01	2024-06-02	1	1
24	Gustavo	Mendes	1996-03-09	Macapá	\N	2024-07-01	2024-07-02	1	1
25	Cristina	Dias	1981-11-11	Boa Vista	\N	2024-08-01	2024-08-02	1	1
26	Ricardo	Silva	1980-05-15	São Paulo	\N	\N	2024-07-10	10	1
27	Amanda	Santos	1982-09-20	Rio de Janeiro	\N	\N	2024-07-10	11	1
28	Felipe	Oliveira	1975-03-10	Belo Horizonte	\N	\N	2024-07-10	12	1
29	Carolina	Martins	1990-07-28	Porto Alegre	\N	\N	2024-07-10	13	1
30	Gustavo	Pereira	1987-01-12	Curitiba	\N	\N	2024-07-10	14	1
31	Mariana	Gomes	1984-06-30	Salvador	\N	\N	2024-07-10	15	1
32	Rodrigo	Almeida	1978-11-05	Fortaleza	\N	\N	2024-07-10	16	1
33	Vanessa	Ferreira	1983-04-17	Recife	\N	\N	2024-07-10	17	1
34	Fernando	Mendes	1995-08-25	Brasília	\N	\N	2024-07-10	18	1
35	Patrícia	Lima	1989-12-03	Manaus	\N	\N	2024-07-10	19	1
\.


--
-- Data for Name: relacionamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.relacionamento (id_relacionamento, id_pessoa_1, id_pessoa_2, dt_inicio, dt_fim, tipo_relacionamento) FROM stdin;
17	7	8	2005-01-01	\N	Pai
18	8	7	2005-01-01	\N	Filho(a)
19	8	9	2010-01-01	\N	Pai
20	9	8	2010-01-01	\N	Filho(a)
21	9	10	2015-01-01	\N	Pai
22	10	9	2015-01-01	\N	Filho(a)
23	10	11	2020-01-01	\N	Pai
24	11	10	2020-01-01	\N	Filho(a)
25	11	12	2025-01-01	\N	Pai
26	12	11	2025-01-01	\N	Filho(a)
27	12	13	2030-01-01	\N	Pai
28	13	12	2030-01-01	\N	Filho(a)
29	13	14	2035-01-01	\N	Pai
30	14	13	2035-01-01	\N	Filho(a)
31	14	15	2040-01-01	\N	Pai
32	15	14	2040-01-01	\N	Filho(a)
33	15	16	2045-01-01	\N	Pai
34	16	15	2045-01-01	\N	Filho(a)
35	16	17	2050-01-01	\N	Pai
36	17	16	2050-01-01	\N	Filho(a)
37	17	18	2055-01-01	\N	Pai
38	18	17	2055-01-01	\N	Filho(a)
39	18	19	2060-01-01	\N	Pai
40	19	18	2060-01-01	\N	Filho(a)
41	19	20	2065-01-01	\N	Pai
42	20	19	2065-01-01	\N	Filho(a)
43	20	21	2070-01-01	\N	Pai
44	21	20	2070-01-01	\N	Filho(a)
45	21	22	2075-01-01	\N	Pai
46	22	21	2075-01-01	\N	Filho(a)
47	22	23	2080-01-01	\N	Pai
48	23	22	2080-01-01	\N	Filho(a)
49	23	24	2085-01-01	\N	Pai
50	24	23	2085-01-01	\N	Filho(a)
51	24	25	2090-01-01	\N	Pai
52	25	24	2090-01-01	\N	Filho(a)
53	7	10	2005-01-01	\N	Mãe
54	10	7	2005-01-01	\N	Filho(a)
55	8	11	2020-01-01	\N	Mãe
56	11	8	2020-01-01	\N	Filho(a)
57	9	12	2025-01-01	\N	Mãe
58	12	9	2025-01-01	\N	Filho(a)
59	13	16	2045-01-01	\N	Mãe
60	16	13	2045-01-01	\N	Filho(a)
61	14	17	2050-01-01	\N	Mãe
62	17	14	2050-01-01	\N	Filho(a)
63	15	18	2055-01-01	\N	Mãe
64	18	15	2055-01-01	\N	Filho(a)
65	19	22	2075-01-01	\N	Mãe
66	22	19	2075-01-01	\N	Filho(a)
67	20	23	2080-01-01	\N	Mãe
68	23	20	2080-01-01	\N	Filho(a)
69	21	24	2085-01-01	\N	Mãe
70	24	21	2085-01-01	\N	Filho(a)
71	10	11	2020-01-01	\N	Irmã(o)
72	11	10	2020-01-01	\N	Irmã(o)
73	12	13	2030-01-01	\N	Irmã(o)
74	13	12	2030-01-01	\N	Irmã(o)
75	14	15	2040-01-01	\N	Irmã(o)
76	15	14	2040-01-01	\N	Irmã(o)
77	16	17	2050-01-01	\N	Irmã(o)
78	17	16	2050-01-01	\N	Irmã(o)
79	18	19	2060-01-01	\N	Irmã(o)
80	19	18	2060-01-01	\N	Irmã(o)
81	20	21	2070-01-01	\N	Irmã(o)
82	21	20	2070-01-01	\N	Irmã(o)
83	22	23	2080-01-01	\N	Irmã(o)
84	23	22	2080-01-01	\N	Irmã(o)
85	24	25	2090-01-01	\N	Irmã(o)
86	25	24	2090-01-01	\N	Irmã(o)
\.


--
-- Name: tbl_transacoesregistradas_id_log_seq; Type: SEQUENCE SET; Schema: log_transacoes; Owner: postgres
--

SELECT pg_catalog.setval('log_transacoes.tbl_transacoesregistradas_id_log_seq', 177, true);


--
-- Name: pessoa_id_pessoa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pessoa_id_pessoa_seq', 25, true);


--
-- Name: relacionamento_id_relacionamento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.relacionamento_id_relacionamento_seq', 86, true);


--
-- Name: tbl_transacoesregistradas tbl_transacoesregistradas_pkey; Type: CONSTRAINT; Schema: log_transacoes; Owner: postgres
--

ALTER TABLE ONLY log_transacoes.tbl_transacoesregistradas
    ADD CONSTRAINT tbl_transacoesregistradas_pkey PRIMARY KEY (id_log);


--
-- Name: pessoa pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (id_pessoa);


--
-- Name: relacionamento relacionamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento
    ADD CONSTRAINT relacionamento_pkey PRIMARY KEY (id_relacionamento);


--
-- Name: pessoa trg_pessoa; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_pessoa AFTER INSERT OR DELETE OR UPDATE ON public.pessoa FOR EACH ROW EXECUTE FUNCTION log_transacoes.registrar_operacao_log();


--
-- Name: relacionamento trg_relacionamento; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_relacionamento AFTER INSERT OR DELETE OR UPDATE ON public.relacionamento FOR EACH ROW EXECUTE FUNCTION log_transacoes.registrar_operacao_log();


--
-- Name: relacionamento fk_id_pessoa_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento
    ADD CONSTRAINT fk_id_pessoa_1 FOREIGN KEY (id_pessoa_1) REFERENCES public.pessoa(id_pessoa);


--
-- Name: relacionamento fk_id_pessoa_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relacionamento
    ADD CONSTRAINT fk_id_pessoa_2 FOREIGN KEY (id_pessoa_2) REFERENCES public.pessoa(id_pessoa);


--
-- PostgreSQL database dump complete
--

