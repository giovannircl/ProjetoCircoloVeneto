const express = require('express');
const path = require('path');
require('dotenv').config();
const { inserirPessoa, alterarPessoa, removerPessoa, listarPessoas, buscarPessoa, getPessoaPorNomeSobrenome } = require('./src/pessoa');
const { inserirRelacionamento, alterarRelacionamento, removerRelacionamento, listarRelacionamentos, buscarRelacionamento, getRelacionamentosPorNomeSobrenome } = require('./src/relacionamento');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.use(express.json());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/pessoa', async (req, res) => {
  const result = await listarPessoas();
  res.json(result);
});

app.get('/api/pessoa/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  try {
    const result = await buscarPessoa(id);
    if (result) {
      res.json(result);
    } else {
      res.status(404).json({ message: 'Registro não encontrado.' });
    }
  } catch (error) {
    console.error('Erro ao buscar pessoa:', error);
    res.status(500).json({ message: 'Erro interno do servidor.' });
  }
});

app.post('/api/pessoa', async (req, res) => {
  const registro = req.body;
  const success = await inserirPessoa(registro);
  if (success) {
    res.status(201).json({ message: 'Registro inserido com sucesso' });
  } else {
    res.status(500).json({ message: 'Erro ao inserir registro' });
  }
});

app.put('/api/pessoa/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const updatedRecord = req.body;
  updatedRecord.id_pessoa = id; 
  try {
    const success = await alterarPessoa(updatedRecord);

    if (success) {
      res.json({ message: 'Registro alterado com sucesso', success: true });
    } else {
      res.status(500).json({ message: 'Erro ao alterar registro', success: false });
    }

  } catch (error) {
    console.error('Erro ao alterar pessoa:', error);
    res.status(500).json({ message: 'Erro interno ao processar a alteração', success: false });
  }
});

app.delete('/api/pessoa/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const success = await removerPessoa(id);
  if (success) {
    res.json({ message: 'Registro excluído com sucesso' });
  } else {
    res.status(500).json({ message: 'Erro ao excluir registro' });
  }
});

app.get('/api/pessoa/nome/:nome/sobrenome/:sobrenome', async (req, res) => {
  const { nome, sobrenome } = req.params;
  const result = await getPessoaPorNomeSobrenome(nome, sobrenome);
  res.json(result);
});

app.get('/api/relacionamento', async (req, res) => {
  const result = await listarRelacionamentos();
  res.json(result);
});

app.get('/api/relacionamento/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const result = await buscarRelacionamento(id);
  if (result) {
    res.json(result);
  } else {
    res.status(404).json({ message: 'Registro não encontrado.' });
  }
});

app.post('/api/relacionamento', async (req, res) => {
  const newRecord = req.body;
  const success = await inserirRelacionamento(newRecord);
  if (success) {
    res.status(201).json({ message: 'Registro inserido com sucesso' });
  } else {
    res.status(500).json({ message: 'Erro ao inserir registro' });
  }
});

app.put('/api/relacionamento/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const updatedRecord = req.body;
  updatedRecord.idRelacionamento = id;
  const success = await alterarRelacionamento(updatedRecord);
  if (success) {
    res.json({ message: 'Registro alterado com sucesso' });
  } else {
    res.status(500).json({ message: 'Erro ao alterar registro' });
  }
});

app.delete('/api/relacionamento/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const success = await removerRelacionamento(id);
  if (success) {
    res.json({ message: 'Registro excluído com sucesso' });
  } else {
    res.status(500).json({ message: 'Erro ao excluir registro' });
  }
});

app.get('/api/relacionamento/nome/:nome/sobrenome/:sobrenome', async (req, res) => {
  const { nome, sobrenome } = req.params;
  const result = await getRelacionamentosPorNomeSobrenome(nome, sobrenome);
  res.json(result);
});

app.listen(PORT, () => {
  console.log(`Servidor está rodando na porta ${PORT}`);
});
