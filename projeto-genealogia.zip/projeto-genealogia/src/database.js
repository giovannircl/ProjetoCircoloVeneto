const { Client } = require('pg');
require('dotenv').config();

const client = new Client({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  port: process.env.DB_PORT,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE
});

client.connect()
  .then(() => console.log('Conexão realizada com sucesso'))
  .catch(err => console.error('Erro ao conectar com o banco', err.stack));

module.exports = client;
