const client = require('./database');

const inserirRelacionamento = async (relacionamento) => {
  const sqlInsert = `
      INSERT INTO relacionamento (id_pessoa_1, id_pessoa_2, tipo_relacionamento, dt_inicio, dt_fim)
      VALUES ($1, $2, $3, $4, $5)
  `;
  const sqlJaExiste = `
      SELECT COUNT(*) FROM relacionamento
      WHERE id_pessoa_1 = $1 AND id_pessoa_2 = $2 AND tipo_relacionamento = $3
  `;
  
  try {
      const checkRes = await client.query(sqlJaExiste, [relacionamento.idPessoa1, relacionamento.idPessoa2, relacionamento.tipoRelacionamento]);
      if (checkRes.rows[0].count > 0) {
          console.log('O relacionamento em questão já existe!');
          return false;
      }
      
      await client.query(sqlInsert, [relacionamento.idPessoa1, relacionamento.idPessoa2, relacionamento.tipoRelacionamento, relacionamento.dtInicio, relacionamento.dtFim]);

      // Inserir relacionamento inverso
      if (relacionamento.tipoRelacionamento === 'Pai') {
          await client.query(sqlInsert, [relacionamento.idPessoa2, relacionamento.idPessoa1, 'Filho(a)', relacionamento.dtInicio, relacionamento.dtFim]);
      } else if (relacionamento.tipoRelacionamento === 'Mãe') {
          await client.query(sqlInsert, [relacionamento.idPessoa2, relacionamento.idPessoa1, 'Filho(a)', relacionamento.dtInicio, relacionamento.dtFim]);
      } else if (relacionamento.tipoRelacionamento === 'Filho(a)') {
          await client.query(sqlInsert, [relacionamento.idPessoa2, relacionamento.idPessoa1, 'Pai', relacionamento.dtInicio, relacionamento.dtFim]);
      } else if (relacionamento.tipoRelacionamento === 'Irmã(o)') {
          await client.query(sqlInsert, [relacionamento.idPessoa2, relacionamento.idPessoa1, 'Irmã(o)', relacionamento.dtInicio, relacionamento.dtFim]);
      } else if (relacionamento.tipoRelacionamento === 'Casado(a)') {
            await client.query(sqlInsert, [relacionamento.idPessoa2, relacionamento.idPessoa1, 'Casado(a)', relacionamento.dtInicio, relacionamento.dtFim]);
      }
      
      return true;
  } catch (err) {
      console.error('Erro ao inserir dados em RELACIONAMENTO', err.message);
      return false;
  }
};

const alterarRelacionamento = async (relacionamento) => {
  const sql = `
      UPDATE relacionamento
      SET id_pessoa_1 = $1, id_pessoa_2 = $2, tipo_relacionamento = $3, dt_inicio = $4, dt_fim = $5
      WHERE id_relacionamento = $6
  `;
  
  try {
      await client.query(sql, [relacionamento.idPessoa1, relacionamento.idPessoa2, relacionamento.tipoRelacionamento, relacionamento.dtInicio, relacionamento.dtFim, relacionamento.idRelacionamento]);
      return true;
  } catch (err) {
      console.error('Erro ao alterar dados em RELACIONAMENTO', err.message);
      return false;
  }
};

const removerRelacionamento = async (idRelacionamento) => {
    const sqlDelete = `
      DELETE FROM relacionamento
      WHERE id_relacionamento = $1
    `;
    try {
        await client.query(sqlDelete, [idRelacionamento]);
        return true;
    } catch (err) {
        console.error('Erro ao remover dados em RELACIONAMENTO', err.message);
        return false;
  }
};

const listarRelacionamentos = async () => {
  const sql = 'SELECT * FROM relacionamento';
  try {
      const res = await client.query(sql);
      return res.rows;
  } catch (err) {
      console.error('Erro ao listar dados de RELACIONAMENTO', err.message);
      throw err;
  }
};

const buscarRelacionamento = async (idPessoa) => {
  const sql = 'SELECT * FROM relacionamento WHERE id_pessoa_1 = $1';
  
  try {
      const res = await client.query(sql, [idPessoa]);
      return res.rows;
  } catch (err) {
      console.error('Erro ao buscar dados em RELACIONAMENTO', err.message);
      throw err;
  }
};

const getRelacionamentosPorNomeSobrenome = async (nome, sobrenome) => {
  const sql = `
      SELECT 
          PE1.nome AS nomePessoa,
          PE1.sobrenome AS sobrenomePessoa, 
          RE.tipo_relacionamento, 
          PE2.nome AS nomeRelacionado, 
          PE2.sobrenome AS sobrenomeRelacionado, 
          RE.dt_inicio as dtInicio, 
          RE.dt_fim as dtFim 
      FROM 
          pessoa PE1, 
          relacionamento RE, 
          pessoa PE2 
      WHERE 
          PE1.id_pessoa = RE.id_pessoa_1 
          AND PE1.nome ILIKE $1 
          AND PE1.sobrenome ILIKE $2 
          AND PE2.id_pessoa = RE.id_pessoa_2
  `;

  const values = [`%${nome}%`, `%${sobrenome}%`];

  try {
      const res = await client.query(sql, values);
      return res.rows.map(row => ({
          tipoRelacionamento: row.tiporelacionamento,
          nomePessoa: row.nomepessoa,
          sobrenomePessoa: row.sobrenomepessoa,
          nomeRelacionado: row.nomelacionado,
          sobrenomeRelacionado: row.sobrenomerelacionado,
          dtInicio: row.dtinicio,
          dtFim: row.dtfim
      }));
  } catch (err) {
      console.error('Erro ao buscar dados por nome e sobrenome em RELACIONAMENTO', err.message);
      throw err;
  }
};

module.exports = {
  inserirRelacionamento,
  alterarRelacionamento,
  removerRelacionamento,
  listarRelacionamentos,
  buscarRelacionamento,
  getRelacionamentosPorNomeSobrenome
};