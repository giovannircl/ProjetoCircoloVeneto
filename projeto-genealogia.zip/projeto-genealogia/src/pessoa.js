const client = require('./database');
const { removerRelacionamento } = require('./relacionamento');

const inserirPessoa = async (pessoa) => {
  const dt_nasc = pessoa.dt_nasc ? new Date(pessoa.dt_nasc).toISOString().split('T')[0] : null;
  const dt_obito = pessoa.dt_obito ? new Date(pessoa.dt_obito).toISOString().split('T')[0] : null;
  const dt_migracao = pessoa.dt_migracao ? new Date(pessoa.dt_migracao).toISOString().split('T')[0] : null;
  const dt_registro = pessoa.dt_registro ? new Date(pessoa.dt_registro).toISOString().split('T')[0] : null;
  const num_pagina = pessoa.num_pagina ? parseInt(pessoa.num_pagina, 10) : null;
  const num_livro = pessoa.num_livro ? parseInt(pessoa.num_livro, 10) : null;

  const sql = `
    INSERT INTO pessoa(nome, sobrenome, dt_nasc, local_nasc, dt_obito, dt_migracao, dt_registro, num_pagina, num_livro) 
    VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9)
  `;
  const values = [
    pessoa.nome,
    pessoa.sobrenome,
    dt_nasc,
    pessoa.local_nasc,
    dt_obito,
    dt_migracao,
    dt_registro,
    num_pagina,
    num_livro
  ];

  try {
    await client.query(sql, values);
    return true; 
  } catch (err) {
    console.error('Erro ao inserir dados em PESSOA:', err.message);
    return false;
  }
};

const alterarPessoa = async (pessoa) => {
  const formatarData = (valor) => {
    if (!valor) return null; 
    const data = new Date(valor);
    return isNaN(data.getTime()) ? null : data.toISOString().split('T')[0];
  };

  const dt_nasc = formatarData(pessoa.dt_nasc);
  const dt_obito = formatarData(pessoa.dt_obito);
  const dt_migracao = formatarData(pessoa.dt_migracao);
  const dt_registro = formatarData(pessoa.dt_registro);

  const sql = `
    UPDATE pessoa 
    SET nome = $1, sobrenome = $2, dt_nasc = $3, local_nasc = $4, 
        dt_obito = $5, dt_migracao = $6, dt_registro = $7, 
        num_pagina = $8, num_livro = $9 
    WHERE id_pessoa = $10
  `;
  const values = [
    pessoa.nome,
    pessoa.sobrenome,
    dt_nasc,
    pessoa.local_nasc,
    dt_obito,
    dt_migracao,
    dt_registro,
    pessoa.num_pagina,
    pessoa.num_livro,
    pessoa.id_pessoa
  ];

  try {
    await client.query(sql, values);
    return true; 
  } catch (err) {
    console.error('Erro ao alterar dados em PESSOA:', err.message);
    return false; 
  }
};

const removerPessoa = async (id) => {
  const sqlBuscarRelacionamentos = `
    SELECT id_relacionamento, id_pessoa_1, id_pessoa_2, tipo_relacionamento
    FROM relacionamento
    WHERE id_pessoa_1 = $1 OR id_pessoa_2 = $1
  `;

  const sqlRemoverPessoa = 'DELETE FROM pessoa WHERE id_pessoa = $1';

  try {
    const { rows } = await client.query(sqlBuscarRelacionamentos, [id]);

    for (let i = 0; i < rows.length; i++) {
      const { id_relacionamento, id_pessoa_1, id_pessoa_2, tipo_relacionamento } = rows[i];
      await removerRelacionamento(id_relacionamento, id_pessoa_1, id_pessoa_2, tipo_relacionamento);
    }

    await client.query(sqlRemoverPessoa, [id]);
    return true;
  } catch (err) {
    console.error('Erro ao remover dados em PESSOA', err.message);
    return false;
  }
};

const listarPessoas = async () => {
  const sql = 'SELECT * FROM pessoa ORDER BY NOME';
  
  try {
    const res = await client.query(sql);
    return res.rows;
  } catch (err) {
    console.error('Erro ao listar dados de PESSOA', err.message);
    throw err;
  }
};

const buscarPessoa = async (id) => {
  const sql = 'SELECT * FROM pessoa WHERE id_pessoa = $1';
  try {
    const res = await client.query(sql, [id]);
    return res.rows[0];
  } catch (err) {
    console.error('Erro ao buscar dados em PESSOA', err.message);
    throw err;
  }
};

const getPessoaPorNomeSobrenome = async (nome, sobrenome) => {
  const sql = 'SELECT * FROM pessoa WHERE nome ILIKE $1 AND sobrenome ILIKE $2';
  const values = [`%${nome}%`, `%${sobrenome}%`];
  
  try {
    const res = await client.query(sql, values);
    return res.rows[0];
  } catch (err) {
    console.error('Erro ao buscar dados por nome e sobrenome em PESSOA', err.message);
    throw err;
  }
};

module.exports = {
  inserirPessoa,
  alterarPessoa,
  removerPessoa,
  listarPessoas,
  buscarPessoa,
  getPessoaPorNomeSobrenome
};
